# Launch plan: from empty server to a server people talk about

No plan guarantees a server goes viral. What you can do is make it easy for people to clip, share and come back. This plan is built around that.

## The hook (say it in one sentence)

Pick the one idea you will lead every post with. Candidates from this kit, each with a built-in clip moment:

| Hook | Clip moment |
|---|---|
| "One book of each enchant, and used books explode." | Someone opens a barrel, grabs a book, and the whole base blows up. |
| "Everyone has a power gem." | A Blink or Chain Lightning fight. |
| "Lifesteal with a revival economy." | A last-heart elimination and the revive. |
| "Rising Lava with 16 players." | The final two climbing a tower while lava closes in. |

Lead with **Enchant SMP** for the first month. It is the most unusual idea and the easiest to clip.

## Phase 0: before anyone joins (week 1 to 2)

- [ ] All servers run stable for 3 days on a private test
- [ ] Hand-built or polished spawn (see `docs/SPAWN.md`)
- [ ] Rules posted, staff chosen, moderation tested (see below)
- [ ] Anti-cheat tuned on the test: have a friend try a hacked client
- [ ] Backups tested by restoring one
- [ ] Website and Discord live (templates below), IP easy to remember
- [ ] 3 to 5 trailer clips recorded on the test server (30 to 60 seconds, vertical for Shorts/TikTok, with captions)

## Phase 1: soft launch (week 3)

- Invite 20 to 50 people: friends, Discord members, small creators
- Watch for lag (`/tps` and `/mspt`), confusing menus, exploits, and where new players quit
- Fix, then fix again. A smooth first 5 minutes beats any feature

## Phase 2: public launch (week 4)

- Announce a date and time, **start with a launch event** (for example the first 24 hours of a fresh season with a countdown)
- List on server-list sites (Minecraft-Server-List type sites, `r/mcservers`), with a good banner and the trailer
- Post clips on TikTok, YouTube Shorts and Reels: 3 per week, each under 60 seconds, one moment per clip, caption the first 2 seconds
- **Creator program**: give small creators (500 to 10,000 followers) a free rank, early access and a creator join address (`forced-hosts` in `velocity.toml`) so you can see which creator brings players. Do not pay for fake views or ask for promises. Honest collaboration lasts.

## Phase 3: retention (every week after)

| Cadence | What |
|---|---|
| Daily | Daily reward, active staff in chat and Discord |
| Weekly | A tournament or event (Minigame night with prizes, build contest, Enchant book hunt) |
| Monthly | A content update with a changelog post |
| Every 4 to 6 weeks | **Season reset** with a theme and a finale event; new clips every season |

Referral ideas: reward both the inviter and the new player with a cosmetic or a Gem Reroll Token for 3 successful invites.

## Monetisation that keeps players

- Cosmetics: hats, particle trails, kill effects, pets, chat colours
- Convenience: more homes, extra claim blocks, a name colour
- **Never** sell hearts, gems, books or kits. Pay to win kills servers and breaks Mojang's rules
- Use Tebex and follow the current Mojang commercial usage guidelines
- Be transparent about where money goes (hosting, staff, events)

## Rules template (short is better)

1. Be respectful. No harassment, hate speech or threats.
2. No cheating: hacked clients, x-ray, duplication, exploiting bugs (report them instead).
3. No griefing or stealing inside protected claims and the spawn.
4. No advertising other servers.
5. Do not abuse AFK tools, alt accounts or ban evasion.
6. Staff decisions can be appealed in the Discord.

Mode notes: Enchant SMP: duplicating books is an exploit and is moderated. Lifesteal: combat logging kills you. Newbie shield can be turned off with `/shield off`.

## Moderation checklist

- Network-wide bans (LiteBans or similar) and mute system
- Chat filter and anti-spam
- 2 to 4 trusted moderators before launch, with clear permissions in LuckPerms (not op)
- An appeal channel and a written punishment ladder
- Log retention for evidence. Check local privacy law for how long you may keep logs.

## Discord layout

```
INFO        #welcome  #rules  #announcements  #server-status
COMMUNITY   #general  #suggestions  #clips-and-screenshots  #memes
PLAY        #smp-chat  #lifesteal-chat  #minigames-chat  #trading
SUPPORT     #help  #bug-reports  #ban-appeals  #store-support
STAFF       #staff-chat  #mod-log  (hidden)
VOICE       General  Gaming 1  Gaming 2  Events
```

Bots worth adding: a Minecraft chat/status bridge (DiscordSRV), a ticket bot, a reaction-roles bot, and a giveaway bot.

## Metrics to watch

- **Day-1 and day-7 return rate** (the only numbers that matter early)
- Where players quit (hub, first 10 minutes in a mode, first death)
- Peak concurrent players and TPS during peaks
- Which mode gets the clips and which gets the retention. They are often different, and both matter

## Do this today

1. `cp .env.example .env`, fill secrets, `./scripts/assemble.sh`, `docker compose up -d proxy hub enchant mariadb redis`
2. Join, op yourself, run through the hub, the Enchant SMP spawn and an anvil test with `/enchantsmp give`
3. Record a first clip of the explosion trap. Put it on a Short with the line from "The hook"
