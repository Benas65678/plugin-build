# Quick test on your existing Windows Paper server (no Docker)

The fastest way to see the plugins working is to put them on a normal Paper server like the one you already run. This tests the spawn builder, Gems, Enchant and Lifesteal. It does **not** test the proxy, so menu items that connect to other servers do nothing yet. That comes later with the full network.

## 0. Use a COPY, not your real world

`NetworkCore` flattens an area of about 16 blocks around the world spawn to build the spawn plaza. On a world with builds, that can destroy them.

1. Make a new folder, for example `my_mc_server_test`.
2. Copy only `server.jar`, `run.bat` and `eula.txt` into it.
3. Do **not** copy the `world` folder. A new test world is created on first start.

## 1. Find your Paper version

Start the server once. The first lines of the console say `This server is running Paper version 1.21.x-NNN`. You can also type `/version` in game. Your server.properties suggests 1.21.9 or newer. The plugins must be built for that version (step 2).

## 2. Build the plugin jars (pick one way)

**A. No installs: GitHub builds them for you**
1. Create a free GitHub account and a new empty repository.
2. Upload the contents of the `minecraft-network` folder (drag and drop in the browser).
3. Open the **Actions** tab, wait for "Build plugins" to finish, open the run, and download the `plugins` artifact. It contains the jars.

**B. On your PC**
1. You already have Java 21 (Paper 1.21 needs it). Install **Maven** (download the zip from maven.apache.org, unzip, add its `bin` folder to PATH).
2. In a terminal inside the `minecraft-network` folder: `mvn -f plugins\pom.xml package`
3. The jars appear in `plugins\<name>\target\`.

If the build prints errors, copy them to me. Before that, check `paper.version` in each `plugins\*\pom.xml` and set it to your Paper version, for example `1.21.11-R0.1-SNAPSHOT`.

## 3. Install

Copy into your test server's `plugins` folder:

- `network-core.jar` (spawn and menus)
- **one** of `gems-smp.jar`, `enchant-smp.jar`, `lifesteal.jar` (try one at a time first)

Start the server with `run.bat`.

## 4. Set the spawn theme

On first start NetworkCore builds a spawn with the default `classic` theme. In `plugins\NetworkCore\config.yml` set `theme:` to `gems`, `enchant` or `lifesteal`, save, then in game: `/spawnbuild smp gems`

To keep it from building by itself, set `auto-build: false` before the first start.

## 5. What to try

**Spawn**: `/spawnbuild smp lifesteal`, then `/spawn`. Walk around it.

**Gems**: join and you receive a gem. `/gems info`. Right-click to use ability 1. `/gems energy YourName 3` unlocks ability 2 (sneak + right-click). Keep the gem in your off hand and press F to use it without holding it.

**Enchant SMP**
- `/enchantsmp status` shows 0 hidden at first; the plugin hides the books in barrels ~100 ticks after the first start.
- `/enchantsmp give sharpness` gives you the book. Put a stick and the book in an anvil: the stick gets Sharpness V. Run `/enchantsmp list` to see it marked used.
- Explosion test: run `/enchantsmp give mending` **twice**. The first book is now counterfeit and explodes you within a second. Stand in a safe place.

**Lifesteal**: `/hearts`, `/withdraw 2` gives Heart items you can right-click. `/lifesteal set YourName 3`. Kills need two players. Ask a friend or use a second account.

## 6. Your server.properties

- `white-list=true`: only people in `whitelist.json` can join. Friends need `whitelist add Name` in the console.
- It contains `management-server-secret`. That feature is disabled, but do not post this file publicly.

## 7. Then the full network

When one plugin works, follow `docs/SETUP.md` (Docker) to run the proxy and all modes together.
