# The spawn

Every server gets a proper spawn automatically the first time it starts. Nothing to build by hand, but everything can be changed.

## What you get

### Hub (a floating island)

- Round plaza (radius 24) with a sunburst pattern, a gravel-free rock underside, a grass fringe with flowers
- **Beacon fountain** in the centre with a water ring: the beam is visible from everywhere
- **One arch per gate**, facing the plaza, with glowing floor tiles, coloured particles, a big title, a subtitle and a **live player count** that updates every few seconds
- **Spawn dais** south of the fountain; players spawn there facing the beacon
- 4 **launch pads** (gold block + pressure plate) that throw players across the plaza
- Lantern posts around the rim, holograms, fixed daytime, no weather, no mobs
- Join experience: title, sound, scoreboard with network player count, tab header/footer, **compass** (right-click for the mode menu)
- Void safety: anyone falling below `hub.void-y` is returned to spawn
- Full protection: no building, damage, hunger, drops or item pickup (permission `netcore.build` bypasses)

### SMP spawns (themed)

A flat plaza (radius 14) is carved into the world spawn: trees and hills are removed, holes are filled. Each theme has a centrepiece:

| Theme | Look |
|---|---|
| `gems` | Deepslate and amethyst. Amethyst altar with budding amethyst, clusters, an end-rod beam, four obelisks |
| `enchant` | Blackstone and lapis. Enchanting table ringed by bookshelves, four quartz pillars |
| `lifesteal` | Nether brick. A giant pixel heart on the floor, crying obsidian pillars, a floating heart |
| `classic` | Stone brick and spruce. A fountain with a lantern post |

Plus lamp pillars, a hologram title and a tips board (editable in `smp.themes.<theme>.tips`). The world spawn is moved onto the plaza and `spawnRadius` is set to 0, so everyone lands in the same place.
Protection inside the radius: no building, no explosion damage, no mob spawns, no PvP.

## Rebuilding and changing

```text
/spawnbuild hub                 rebuild the hub island (on the hub server)
/spawnbuild smp gems            rebuild an SMP spawn with a theme
/netcore reload                 reload config and menus
```

Rebuilding the hub overwrites the island area, so it will **erase your own additions** there. Build custom extras outside radius 32, or turn off `auto-build` and `/spawnbuild` once you have a hand-made spawn.

Change the look in `backends/hub/plugins/NetworkCore/config.yml`:

```yaml
hub:
  palette:
    primary: QUARTZ_BRICKS
    secondary: SMOOTH_QUARTZ
    accent: GOLD_BLOCK
    accent2: DEEPSLATE_TILES
```

Any block name works. Add or edit gates under `hub.gates`. Titles and text are MiniMessage, so gradients work: `<gradient:#ff5555:#ffaa00>`.

## Replacing it with a hand-built spawn (recommended before launch)

The generated spawn is a strong starting point. A hand-built, themed spawn is one of the biggest differences between a server that looks professional and one that does not. Options:

1. **Build it yourself or hire a builder** in a creative world. Save it with WorldEdit (`//copy`, `//schem save hub`).
2. Set `auto-build: false` in the server's NetworkCore config, delete `data/<server>/world`, start, and paste the schematic (`//schem load hub`, `//paste`).
3. Set the spawn point with `/setworldspawn` at the schematic's spawn dais. Keep `role: hub` so the compass, menus, scoreboard and protection still work.
4. Keep the generated gate positions or recreate the gates as your own builds: players trigger a gate by standing within about 2 blocks of the gate centre at `hub.center + 18 blocks` along the gate's `angle` (see `Gate.java`). Or skip gates entirely and rely on the compass and NPCs.

Tips that make spawns look good: strong silhouette visible from the spawn point, one clear focal point (the beacon beam), consistent palette, lighting everywhere (no dark corners), and a clear arrow-like path to the most important thing.

## NPCs and extras

- Install **FancyNpcs** or **Citizens** and make NPCs run `/smp` or `/modes` on click.
- **Leaderboard holograms**: use `/hearts top` output via a hologram plugin (DecentHolograms) with PlaceholderAPI.
- **Parkour**, **crates** and **daily rewards** are easy extras that raise retention.
