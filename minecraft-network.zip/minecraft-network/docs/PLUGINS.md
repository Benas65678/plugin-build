# Plugin reference

All plugins read MiniMessage text (colours and gradients): https://docs.advntr.dev/minimessage/format.html
Config files live in `data/<server>/plugins/<PluginName>/config.yml` after first start. Defaults that you want to ship to every container go in `backends/<server>/plugins/<PluginName>/config.yml`.

---

## NetworkCore (all servers)

**Roles**: `role: hub` builds a floating island; `role: smp` builds a themed spawn plaza. The minigames server uses `role: hub` with different gates.

| Command | Permission | What it does |
|---|---|---|
| `/hub`, `/lobby`, `/l` | none | Back to the hub (connects to `hub-server` on other servers) |
| `/spawn` | none | Teleport to this server's spawn |
| `/modes`, `/smp`, `/minigames`, `/menu <id>` | none | Open a menu |
| `/spawnbuild [hub\|smp] [theme]` | `netcore.admin` | Rebuild the spawn (themes: gems, enchant, lifesteal, classic) |
| `/netcore reload\|rebuild\|info` | `netcore.admin` | Reload config and menus |

Permission `netcore.build` bypasses spawn protection (op by default).

**Menus** are defined in config under `menus:`. Item actions: `open:<menu>`, `connect:<server>`, `command:<cmd>`, `close`. Lore supports `{count:server1,server2}` (live players) and `{online}`.

**Gates** (hub): each has `label`, `subtitle`, `server` or `command`, `block`, `glow`, `color`, `angle` (0 east, 90 south, 180 west, 270 north; spawn is south; multiples of 45 build cleanest). Gates need a restart after changes, then `/spawnbuild hub` to rebuild the arches.

**SMP spawn**: protected radius `smp.protect-radius` (default 16). Inside it: no building, no explosion damage to blocks, no mob spawns, no PvP (`smp.spawn-pvp`).

---

## GemsSMP

Each player gets a random gem on first join. The gem is a soulbound item: it cannot be dropped, stored in chests, used in crafting, or lost on death.

**Using abilities**: right-click with the gem = ability 1; sneak + right-click = ability 2. Or keep the gem in your off hand and press **F** (ability 1) or **Shift+F** (ability 2) without holding it.

**Energy** (1 to 5): +1 for killing a player, -1 for dying. Ability 2 unlocks at energy 3 (config `unlock`). Potency, durations and cooldowns scale with energy.

| Gem | Passive | Ability 1 | Ability 2 |
|---|---|---|---|
| Ember | Fire resistance | Fire Bolt (fireballs) | Inferno Ring |
| Tide | Water breathing, dolphin's grace | Tidal Surge (push) | Riptide (launch) |
| Gale | No fall damage, jump boost | Dash | Cyclone |
| Terra | Haste | Quake (damage + slow) | Bulwark (absorption) |
| Volt | Speed | Smite (lightning) | Chain Lightning |
| Shade | Night vision | Vanish | Blink (teleport) |
| Vital | Regeneration when hurt | Mend (heal) | Siphon (drain) |
| Frost | Freeze + slowness immunity | Frost Nova | Glacial Prison |

| Command | Permission | |
|---|---|---|
| `/gems` or `/gems info` | none | Your gem and abilities |
| `/gems list` | none | All gems |
| `/gems give <player> [gem]`, `/gems reroll <player>`, `/gems energy <player> <1-5>`, `/gems token <player>` | `gems.admin` | Admin tools. The reroll token is a right-click item. |

Config: `max-energy`, `start-energy`, `potency-per-tier`, `unlock.*`, `pvp-abilities`, `grief`.

---

## EnchantSMP

- Every enchantment in the game has **one** book (level = max level, optional boost in config).
- At an anvil, a book can be applied to **any item**, ignoring enchantment compatibility and level limits. Cost: `xp-cost` levels.
- Applying the book **burns** it. That enchantment can never be applied again.
- **Used or counterfeit books explode** the player who picks them up or holds them (checked every second, so chests, trades and dupes are covered).
- Books are hidden in barrels inside rock. Optional extra: inject into structure loot (`loot.enabled`). Hints broadcast on a timer.

| Command | Permission | |
|---|---|---|
| `/enchantsmp status`, `/esmp list` | none | Counts / list with who found and used what |
| `/enchantsmp hint` | `enchantsmp.admin` | Broadcast a hint now |
| `/enchantsmp where <enchant>` | admin | Exact location of a book |
| `/enchantsmp scatter` | admin | Hide all unplaced books (async) |
| `/enchantsmp give <enchant> [player]` | admin | Re-issue a fresh book (old copies become counterfeit) |
| `/enchantsmp reset <enchant\|all>` | admin | Reset the registry |

Data: `plugins/EnchantSMP/registry.yml`. Back it up with the world.

Balance notes: the xp cost and exclusion list (`exclude`) are the main dials. Curses are included by default (a Book of Curse of Binding is a funny trap). Mending, Protection IV and Sharpness V on a single item is intentionally unrestricted, since that is the design.

---

## LifestealSMP

| Mechanic | Default |
|---|---|
| Start / max hearts | 10 / 20 |
| Death | -1 heart (also from mobs, configurable) |
| Player kill | +1 heart for the killer. At max hearts a Heart item drops. |
| 0 hearts | Eliminated: cannot log in until revived |
| Newbie shield | 30 min of playtime, `/shield off` to opt out |
| Combat tag | 15 s. Logging out while tagged kills you. |
| Heart item | Right-click to gain a heart. Craft it (recipe in config) or `/withdraw [n]`. |
| Revival Compass | Hold it and `/revive <name>`. Craftable. Revived players return with 4 hearts. |

| Command | Permission | |
|---|---|---|
| `/hearts [player\|top]` | none | Hearts and leaderboard |
| `/withdraw [n]` | none | Turn hearts into items (keep at least 1) |
| `/revive <name>` | none (needs the item) | Revive an eliminated player |
| `/shield [off]` | none | Newbie protection |
| `/lifesteal reload\|set\|give\|eliminate\|revive` | `lifesteal.admin` | Admin tools |

Data: `plugins/LifestealSMP/data.yml`. Recipes are editable in config (`recipes.*`, ingredient `HEART` means the custom item).

---

## MinigamesCore

Rounds run in a separate void world (`mg_arenas`) on the minigames server. Each game has a bossbar, a countdown, spectator mode for eliminated players, fireworks for the winner, and an automatic arena reset.

| Game | How it works |
|---|---|
| TNT Run | 3 floors; the block under you vanishes shortly after you step on it |
| Spleef | Snow floor over the void; everyone gets an instant-dig shovel |
| Sumo | Small platform that shrinks; hits do knockback only |
| Rising Lava | Random terrain in a barrier box; lava rises every 10 s; you get blocks to build up |

| Command | |
|---|---|
| `/mg join <tntrun\|spleef\|sumo\|lava>` | Join or create a round |
| `/mg leave`, `/mg list`, `/mg stats [player]` | |
| `/mg forcestart` (`minigames.admin`) | Skip the countdown |

Rewards: `rewards.win-commands` and `rewards.play-commands` run console commands with `{player}` and `{game}`, e.g. `eco give {player} 100`.

Bedwars and Skywars are a lot of work to build well. Use a proven plugin on the minigames server (for example BedWars2023 or a Skywars plugin from Modrinth/Spigot), then add a gate for it in `backends/minigames/plugins/NetworkCore/config.yml`.

---

## Third-party plugins

Auto-installed from Modrinth: **LuckPerms** (ranks), **BlueMap** (live map), **GrimAC** (anti-cheat on SMPs), **Chunky** (pre-generation).

Recommended additions (download the jar and drop it into `plugins-extra/common/` or `plugins-extra/<server>/`, then run `./scripts/assemble.sh`):

- **EssentialsX** (homes, warps, economy) on the SMPs
- **WorldGuard + WorldEdit** (regions, schematics)
- **GriefPrevention** or **Towny** for claims on the Classic SMP
- **LiteBans** or **AdvancedBan** for network-wide bans (add to the proxy and backends)
- **FancyNpcs** or **Citizens** for clickable NPCs in the hub
- **Tebex** for a store (cosmetics and convenience only)
