# Setup guide

## 0. What you need

- A Linux server (Ubuntu 22.04 or 24.04). **RAM matters**: the compose file allocates about 26 GB if every server runs. Start small, see "Run fewer servers" below.
- A fast CPU (Minecraft is mostly single-threaded). Hetzner, OVH and similar providers work well.
- Docker with the Compose plugin: `curl -fsSL https://get.docker.com | sh`
- A domain name (optional but needed for the website and live maps).

## 1. Get the files onto the server

Copy the `minecraft-network` folder to the server (scp, rsync or git), then:

```bash
cd minecraft-network
cp .env.example .env
nano .env
```

Fill every secret with a long random value: `openssl rand -hex 24`. Set `DOMAIN` if you have one.

## 2. Build the plugins

```bash
./scripts/assemble.sh
```

This uses Maven if installed, otherwise Docker. It builds the five plugins and prepares `./build/config/<server>` and `./build/plugins/<server>`.

If the build fails with errors about Paper classes or methods, the Paper API version in the poms does not match. Set the version to the one your servers use, in each `plugins/*/pom.xml`:

```xml
<paper.version>1.21.11-R0.1-SNAPSHOT</paper.version>
```

You can see your server version in the console on first start. If you push the folder to GitHub, `.github/workflows/build.yml` builds the jars in the cloud and shows compiler errors.

## 3. Start it

```bash
docker compose up -d
docker compose logs -f hub        # watch the hub start; Ctrl+C to stop watching
```

The first start takes a few minutes (downloads, world generation, spawn building). When `hub` says `Done`, the proxy is ready.

### Run fewer servers

You do not have to run everything. Start only what you want:

```bash
docker compose up -d proxy hub gems mariadb redis
```

Menu items for servers that are not running just fail to connect. Add the others when you have the RAM. Lower `MEMORY` per server in `docker-compose.yml` if needed (a quiet SMP runs on 3 to 4 GB).

## 4. Firewall

```bash
ufw allow 22/tcp
ufw allow 25565/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

Only the proxy and the website are published. The Minecraft backends can only be reached through the proxy.

## 5. Join and become admin

1. Add `your-server-ip` in Minecraft (Java, 1.21+). You land on the hub island.
2. Make yourself operator on each server (you must be online on that server for the UUID to match):

```bash
docker compose exec hub rcon-cli op YourName
```

Join each mode once from the menu and run the same command with `gems`, `enchant`, `lifesteal`, `classic`, `minigames` instead of `hub`. Better: set up LuckPerms ranks (next section) so you do not rely on op.

## 6. Ranks (LuckPerms, shared by every server)

LuckPerms stores everything in the shared database, so a rank set once works everywhere. Run these on the hub (via rcon, or in-game as op):

```bash
docker compose exec hub rcon-cli "lp creategroup admin"
docker compose exec hub rcon-cli "lp creategroup mod"
docker compose exec hub rcon-cli "lp creategroup vip"
docker compose exec hub rcon-cli "lp group admin permission set * true"
docker compose exec hub rcon-cli "lp group admin meta setprefix 100 \"&c[Admin] \""
docker compose exec hub rcon-cli "lp group vip meta setprefix 10 \"&6[VIP] \""
docker compose exec hub rcon-cli "lp user YourName parent add admin"
```

Useful permission nodes from the kit: `netcore.admin`, `netcore.build`, `gems.admin`, `enchantsmp.admin`, `lifesteal.admin`, `minigames.admin`.

## 7. Per-mode first steps

**Enchant SMP**
1. Set a world border so the books are not scattered too far: `docker compose exec enchant rcon-cli "worldborder set 8000"`. The scatter radius (config `scatter.radius`, default 4000) must be at most half the border.
2. On first start the plugin hides every book in barrels inside solid rock. Check with `/enchantsmp status`.
3. Hints are broadcast every 30 minutes. `/enchantsmp where <enchant>` (admin) shows exact positions.

**Lifesteal**: nothing needed. Tweak `plugins/Lifesteal*/config.yml` in `data/lifesteal` after first start (hearts, recipes, newbie shield).

**Gems**: nothing needed. Players receive a random gem on first join. `/gems token <player>` gives a reroll token (good store item or event prize).

**Minigames**: walk into a gate or use `/minigames`. Rounds start when 2 or more players are in the queue. Add rewards in `data/minigames/plugins/MinigamesCore/config.yml` under `rewards`.

**Pre-generate the SMP worlds** (prevents lag when players explore). Chunky is installed on the SMPs:

```bash
docker compose exec gems rcon-cli "chunky radius 3000"
docker compose exec gems rcon-cli "chunky start"
```

## 8. Website and maps

Create DNS records pointing to your server for: `yourdomain`, `gems-map`, `enchant-map`, `lifesteal-map`, `classic-map`. Caddy gets HTTPS certificates automatically.

Edit `web/site/index.html` (IP, domain, Discord link). BlueMap renders each SMP automatically after the first start; large worlds take a while. To avoid hours of rendering at once, pre-generate with Chunky first.

## 9. Backups

The `backup` container archives `./data` every 6 hours into `./backups` and keeps about a week. **Copy them off the server too** (rclone to cloud storage, or rsync to another machine) and **test a restore** once:

```bash
docker compose down
tar -xzf backups/network-YYYYMMDD-HHMMSS.tar.gz -C data
docker compose up -d
```

## 10. Updating

- **Minecraft/Paper**: set `MC_VERSION` in `.env` (or leave `LATEST`) and `docker compose pull && docker compose up -d`. Update `paper.version` in the poms to match and re-run `./scripts/assemble.sh`.
- **Plugins you changed**: `./scripts/assemble.sh && docker compose restart <server>`.
- **Configs**: files in `backends/` are copied into `data/<server>` at container start. If you edited the same file inside `data/`, your newer copy is kept. To re-apply a file from `backends/`, delete the copy in `data/<server>/...` and restart that server.

## Troubleshooting

| Problem | Fix |
|---|---|
| "Unable to connect to world server" or players kicked on connect | `VELOCITY_SECRET` mismatch. It must be identical in `.env` for every service. Restart everything after changing it. |
| "If you wish to use IP forwarding, please enable it in your BungeeCord config" | Paper did not apply `paper-global.yml`. Open `data/<server>/config/paper-global.yml` and make sure `proxies.velocity` has `enabled: true`, `online-mode: true` and your real secret (not the text `${CFG_VELOCITY_SECRET}`). If Paper rewrote the file, set those three values by hand and restart. |
| Modrinth download fails at start | A plugin has no release for your Minecraft version yet. Remove it from `MODRINTH_PROJECTS` for that server, or drop a jar in `plugins-extra/<server>/` and re-run assemble. Make sure the slug is right (`luckperms`, `bluemap`, `grimac`, `chunky`). |
| Hub island not built | `docker compose exec hub rcon-cli "spawnbuild hub"` or join as op and run `/spawnbuild hub`. |
| Menu counts show 0 | The proxy must have `bungee-plugin-message-channel = true` (default in the provided `velocity.toml`). Counts appear a second after opening a menu. |
| Players spawn in the void in the hub | The hub world must be void. Delete `data/hub/world*` and restart, then the island rebuilds. |
| Out of memory | Lower `MEMORY` values, or run fewer servers. |

## Legal and money

- Accept the Minecraft EULA (set in compose) and follow Mojang's commercial usage guidelines. Selling cosmetics and convenience items is generally fine. Selling gameplay advantages is not.
- You may not call the server "official" or use Mojang assets in your branding.
