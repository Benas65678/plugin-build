#!/bin/sh
# Runs every 6h inside the backup container. Keeps the newest 28 archives (~7 days).
set -e
ts=$(date +%Y%m%d-%H%M%S)
tar -czf "/backups/network-$ts.tar.gz" -C /data . --exclude='*/logs' --exclude='*/cache' || true
ls -1t /backups/network-*.tar.gz | tail -n +29 | xargs -r rm -f
echo "backup $ts done"
