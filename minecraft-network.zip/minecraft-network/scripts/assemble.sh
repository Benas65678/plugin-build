#!/usr/bin/env bash
# Builds the plugins and prepares ./build/{config,plugins}/<server> for docker compose.
# Re-run this whenever you change a plugin or a file under ./backends.
set -euo pipefail
cd "$(dirname "$0")/.."

SERVERS=(hub gems enchant lifesteal classic minigames)

echo "==> Building plugins"
if command -v mvn >/dev/null 2>&1; then
  mvn -B -q -f plugins/pom.xml package
else
  echo "    mvn not found, using Docker (maven:3.9-eclipse-temurin-21)"
  docker run --rm -v "$PWD/plugins":/w -v "$HOME/.m2":/root/.m2 -w /w \
    maven:3.9-eclipse-temurin-21 mvn -B -q package
fi

jar() { echo "plugins/$1/target/$1.jar"; }

# which of our own plugins each server gets
declare -A OWN=(
  [hub]="network-core"
  [gems]="network-core gems-smp"
  [enchant]="network-core enchant-smp"
  [lifesteal]="network-core lifesteal"
  [classic]="network-core"
  [minigames]="network-core minigames"
)

echo "==> Assembling ./build"
rm -rf build
for s in "${SERVERS[@]}"; do
  mkdir -p "build/config/$s" "build/plugins/$s"
  cp -r backends/common/. "build/config/$s/"
  [ -d "backends/$s" ] && cp -r "backends/$s/." "build/config/$s/"
  for p in ${OWN[$s]}; do
    [ -f "$(jar "$p")" ] || { echo "missing $(jar "$p")"; exit 1; }
    cp "$(jar "$p")" "build/plugins/$s/"
  done
  # third-party jars you downloaded by hand (see docs/PLUGINS.md)
  for dir in plugins-extra/common "plugins-extra/$s"; do
    [ -d "$dir" ] && cp "$dir"/*.jar "build/plugins/$s/" 2>/dev/null || true
  done
done

mkdir -p data backups
echo "==> Done. Next: docker compose up -d"
