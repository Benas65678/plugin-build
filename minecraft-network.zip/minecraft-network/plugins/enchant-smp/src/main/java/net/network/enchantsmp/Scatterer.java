package net.network.enchantsmp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Barrel;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Hides each unplaced book in a barrel buried inside solid rock somewhere in the world. */
public final class Scatterer {

    private final EnchantSMP plugin;
    private boolean running;

    public Scatterer(EnchantSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isRunning() {
        return running;
    }

    public void scatter(CommandSender notify) {
        if (running) return;
        List<BookRegistry.Entry> todo = new ArrayList<>(plugin.registry().inState(BookRegistry.State.UNPLACED));
        Collections.shuffle(todo);
        int percent = Math.max(0, Math.min(100, plugin.getConfig().getInt("scatter.percent", 100)));
        int count = (int) Math.ceil(todo.size() * percent / 100.0);
        todo = new ArrayList<>(todo.subList(0, count));
        if (todo.isEmpty()) {
            if (notify != null) notify.sendMessage("Nothing to place.");
            return;
        }
        running = true;
        plugin.getLogger().info("Scattering " + todo.size() + " books...");
        step(todo.iterator(), 0, todo.size(), notify);
    }

    private void step(Iterator<BookRegistry.Entry> it, int done, int total, CommandSender notify) {
        if (!it.hasNext()) {
            running = false;
            plugin.registry().save();
            plugin.getLogger().info("Scatter finished: " + done + " books hidden.");
            if (notify != null) notify.sendMessage("Scatter finished: " + done + " books hidden.");
            return;
        }
        BookRegistry.Entry en = it.next();
        tryPlace(en, 0, () -> {
            if (done % 10 == 9 && notify != null) notify.sendMessage("Placed " + (done + 1) + "/" + total);
            step(it, done + 1, total, notify);
        });
    }

    private void tryPlace(BookRegistry.Entry en, int attempt, Runnable next) {
        if (attempt > 60) {
            plugin.getLogger().warning("Could not place the book of " + en.key + "; it stays UNPLACED.");
            next.run();
            return;
        }
        World w = plugin.world();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int min = plugin.getConfig().getInt("scatter.min-radius", 300);
        int max = Math.max(min + 1, plugin.getConfig().getInt("scatter.radius", 4000));
        double angle = r.nextDouble(0, Math.PI * 2);
        double dist = r.nextDouble(min, max);
        int x = w.getSpawnLocation().getBlockX() + (int) Math.round(Math.cos(angle) * dist);
        int z = w.getSpawnLocation().getBlockZ() + (int) Math.round(Math.sin(angle) * dist);

        w.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk -> Bukkit.getScheduler().runTask(plugin, () -> {
            int minY = Math.max(w.getMinHeight() + 2, plugin.getConfig().getInt("scatter.min-y", -55));
            int maxY = plugin.getConfig().getInt("scatter.max-y", 20);
            for (int i = 0; i < 25; i++) {
                int y = ThreadLocalRandom.current().nextInt(minY, maxY + 1);
                Block b = w.getBlockAt(x, y, z);
                if (!isRock(b.getType()) || !surroundedByRock(b)) continue;
                b.setType(Material.BARREL, false);
                if (b.getState() instanceof Barrel barrel) {
                    barrel.getInventory().addItem(plugin.items().create(en));
                    barrel.update(true, false);
                    plugin.registry().markPlaced(en, w.getName(), x, y, z);
                    next.run();
                    return;
                }
            }
            tryPlace(en, attempt + 1, next);
        }));
    }

    private static boolean isRock(Material m) {
        return m == Material.STONE || m == Material.DEEPSLATE || m == Material.ANDESITE || m == Material.DIORITE
                || m == Material.GRANITE || m == Material.TUFF || m == Material.COBBLED_DEEPSLATE;
    }

    private static boolean surroundedByRock(Block b) {
        for (BlockFace f : new BlockFace[]{BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH,
                BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Material m = b.getRelative(f).getType();
            if (!isRock(m) && m != Material.DIRT && m != Material.COAL_ORE && m != Material.IRON_ORE
                    && m != Material.DEEPSLATE_COAL_ORE && m != Material.DEEPSLATE_IRON_ORE) return false;
        }
        return true;
    }
}
