package net.network.enchantsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class EnchantCommand implements CommandExecutor, TabCompleter {

    private final EnchantSMP plugin;

    public EnchantCommand(EnchantSMP plugin) {
        this.plugin = plugin;
    }

    private boolean admin(CommandSender s) {
        return s.hasPermission("enchantsmp.admin");
    }

    private static void say(CommandSender s, String text, NamedTextColor c) {
        s.sendMessage(Component.text(text, c));
    }

    private BookRegistry.Entry find(String arg) {
        String key = arg.contains(":") ? arg.toLowerCase(Locale.ROOT) : "minecraft:" + arg.toLowerCase(Locale.ROOT);
        return plugin.registry().get(key).orElse(null);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "status" -> {
                var reg = plugin.registry();
                say(sender, "Enchant SMP book registry", NamedTextColor.AQUA);
                say(sender, "  Unplaced: " + reg.inState(BookRegistry.State.UNPLACED).size(), NamedTextColor.GRAY);
                say(sender, "  Hidden:   " + reg.inState(BookRegistry.State.PLACED).size(), NamedTextColor.GRAY);
                say(sender, "  Found:    " + reg.inState(BookRegistry.State.FOUND).size(), NamedTextColor.YELLOW);
                say(sender, "  Used:     " + reg.inState(BookRegistry.State.USED).size(), NamedTextColor.RED);
            }
            case "list" -> {
                say(sender, "Books (green = hidden, yellow = found, red = used):", NamedTextColor.AQUA);
                for (BookRegistry.Entry en : plugin.registry().all()) {
                    NamedTextColor c = switch (en.state) {
                        case USED -> NamedTextColor.RED;
                        case FOUND -> NamedTextColor.YELLOW;
                        case PLACED -> NamedTextColor.GREEN;
                        case UNPLACED -> NamedTextColor.DARK_GRAY;
                    };
                    String extra = en.state == BookRegistry.State.USED ? "  used by " + en.user
                            : en.state == BookRegistry.State.FOUND ? "  found by " + en.finder : "";
                    say(sender, "  " + BookRegistry.pretty(en.key) + extra, c);
                }
            }
            case "hint" -> {
                if (!admin(sender)) return deny(sender);
                if (!plugin.hints().broadcastHint()) say(sender, "No hidden books to hint at.", NamedTextColor.RED);
            }
            case "where" -> {
                if (!admin(sender)) return deny(sender);
                if (args.length < 2) { say(sender, "/enchantsmp where <enchantment>", NamedTextColor.RED); return true; }
                BookRegistry.Entry en = find(args[1]);
                if (en == null) { say(sender, "Unknown enchantment.", NamedTextColor.RED); return true; }
                say(sender, BookRegistry.pretty(en.key) + ": " + en.state
                        + (en.hasLocation() ? " at " + en.world + " " + en.x + " " + en.y + " " + en.z : ""), NamedTextColor.AQUA);
            }
            case "scatter" -> {
                if (!admin(sender)) return deny(sender);
                say(sender, "Scattering books (this runs in the background)...", NamedTextColor.YELLOW);
                plugin.scatterer().scatter(sender);
            }
            case "give" -> {
                if (!admin(sender)) return deny(sender);
                if (args.length < 2) { say(sender, "/enchantsmp give <enchantment> [player]", NamedTextColor.RED); return true; }
                BookRegistry.Entry en = find(args[1]);
                if (en == null) { say(sender, "Unknown enchantment.", NamedTextColor.RED); return true; }
                Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2]) : sender instanceof Player p ? p : null;
                if (target == null) { say(sender, "Player not found.", NamedTextColor.RED); return true; }
                plugin.registry().reissue(en);              // old copies become counterfeit
                plugin.give(target, plugin.items().create(en));
                plugin.registry().markFound(en, target.getName());
                say(sender, "Gave a fresh Book of " + BookRegistry.pretty(en.key) + " to " + target.getName()
                        + ". Older copies are now counterfeit.", NamedTextColor.GREEN);
            }
            case "reset" -> {
                if (!admin(sender)) return deny(sender);
                if (args.length < 2) { say(sender, "/enchantsmp reset <enchantment|all>", NamedTextColor.RED); return true; }
                if (args[1].equalsIgnoreCase("all")) {
                    plugin.registry().all().forEach(plugin.registry()::reissue);
                } else {
                    BookRegistry.Entry en = find(args[1]);
                    if (en == null) { say(sender, "Unknown enchantment.", NamedTextColor.RED); return true; }
                    plugin.registry().reissue(en);
                }
                say(sender, "Reset. Run /enchantsmp scatter to hide the books again.", NamedTextColor.GREEN);
            }
            case "reload" -> {
                if (!admin(sender)) return deny(sender);
                plugin.reloadConfig();
                plugin.registry().load();
                say(sender, "Reloaded.", NamedTextColor.GREEN);
            }
            default -> say(sender, "/enchantsmp <status|list|hint|where|scatter|give|reset|reload>", NamedTextColor.GRAY);
        }
        return true;
    }

    private boolean deny(CommandSender s) {
        say(s, "You do not have permission.", NamedTextColor.RED);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(List.of("status", "list"));
            if (admin(sender)) out.addAll(List.of("hint", "where", "scatter", "give", "reset", "reload"));
        } else if (args.length == 2 && admin(sender)
                && List.of("where", "give", "reset").contains(args[0].toLowerCase(Locale.ROOT))) {
            for (BookRegistry.Entry en : plugin.registry().all()) out.add(en.key.replace("minecraft:", ""));
            if (args[0].equalsIgnoreCase("reset")) out.add("all");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }
}
