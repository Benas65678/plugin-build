package net.network.enchantsmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.Map;

/**
 * Enforces the curse: a book whose enchantment was already used (or a counterfeit serial) explodes
 * the moment a player picks it up. A periodic scan catches every other way of getting one
 * (chests, trades, dupes). First pickup of a real book announces the find.
 */
public final class BookGuard implements Listener {

    private final EnchantSMP plugin;

    public BookGuard(EnchantSMP plugin) {
        this.plugin = plugin;
        Bukkit.getScheduler().runTaskTimer(plugin, this::scan, 40L, 20L);
    }

    /** True if the book is retired/counterfeit and was handled (exploded). */
    private boolean handle(Player p, ItemStack stack) {
        String key = plugin.items().keyOf(stack);
        if (key == null) return false;
        BookRegistry.Entry en = plugin.registry().get(key).orElse(null);
        if (en == null) return false;
        boolean retired = en.state == BookRegistry.State.USED
                || !en.serial.equals(plugin.items().serialOf(stack));
        if (retired) {
            plugin.explodeAt(p, en);
            return true;
        }
        if (plugin.registry().markFound(en, p.getName())) {
            plugin.broadcast("found", Map.of("player", p.getName(), "name", BookRegistry.pretty(en.key)));
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        ItemStack stack = e.getItem().getItemStack();
        if (plugin.items().keyOf(stack) == null) return;
        if (handle(p, stack)) {
            e.setCancelled(true);
            e.getItem().remove();
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> scanPlayer(e.getPlayer()), 20L);
    }

    private void scan() {
        for (Player p : Bukkit.getOnlinePlayers()) scanPlayer(p);
    }

    private void scanPlayer(Player p) {
        if (!p.isOnline() || p.isDead()) return;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || plugin.items().keyOf(s) == null) continue;
            if (handle(p, s)) {
                inv.setItem(i, null);
                return;                      // one explosion per scan is plenty
            }
        }
    }
}
