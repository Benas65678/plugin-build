package net.network.enchantsmp;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Tracks the single book of every enchantment: where it is, who found it, whether it was used. */
public final class BookRegistry {

    public enum State { UNPLACED, PLACED, FOUND, USED }

    public static final class Entry {
        public final String key;          // e.g. minecraft:sharpness
        public int level;
        public State state = State.UNPLACED;
        public String serial = UUID.randomUUID().toString();
        public String world;
        public int x, y, z;
        public String finder;
        public String user;
        public long usedAt;

        Entry(String key, int level) {
            this.key = key;
            this.level = level;
        }

        public boolean hasLocation() {
            return world != null && (state == State.PLACED || state == State.FOUND);
        }
    }

    private final EnchantSMP plugin;
    private final File file;
    private final Map<String, Entry> entries = new LinkedHashMap<>();

    public BookRegistry(EnchantSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "registry.yml");
    }

    // ------------------------------------------------------------------ enchantment helpers

    public static Enchantment enchant(String key) {
        NamespacedKey nk = NamespacedKey.fromString(key.toLowerCase(Locale.ROOT));
        return nk == null ? null : Registry.ENCHANTMENT.get(nk);
    }

    public static String pretty(String key) {
        String path = key.contains(":") ? key.substring(key.indexOf(':') + 1) : key;
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    private int levelFor(Enchantment e) {
        int max = e.getMaxLevel();
        String mode = plugin.getConfig().getString("level-mode", "max");
        if (mode.equalsIgnoreCase("boosted") && max > 1) return max + plugin.getConfig().getInt("level-boost", 0);
        return max;
    }

    // ------------------------------------------------------------------ lifecycle

    public void load() {
        entries.clear();
        YamlConfiguration yml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
        ConfigurationSection sec = yml.getConfigurationSection("books");
        List<String> exclude = plugin.getConfig().getStringList("exclude");

        List<Enchantment> all = new ArrayList<>();
        for (Enchantment e : Registry.ENCHANTMENT) all.add(e);
        all.sort((a, b) -> a.getKey().toString().compareTo(b.getKey().toString()));

        for (Enchantment e : all) {
            String key = e.getKey().toString();
            if (exclude.contains(key)) continue;
            Entry en = new Entry(key, levelFor(e));
            if (sec != null && sec.isConfigurationSection(key.replace('.', '_'))) {
                ConfigurationSection s = sec.getConfigurationSection(key.replace('.', '_'));
                en.level = s.getInt("level", en.level);
                try {
                    en.state = State.valueOf(s.getString("state", "UNPLACED"));
                } catch (IllegalArgumentException ex) {
                    en.state = State.UNPLACED;
                }
                en.serial = s.getString("serial", en.serial);
                en.world = s.getString("world");
                en.x = s.getInt("x");
                en.y = s.getInt("y");
                en.z = s.getInt("z");
                en.finder = s.getString("finder");
                en.user = s.getString("user");
                en.usedAt = s.getLong("used-at");
            }
            entries.put(key, en);
        }
        save();
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Entry en : entries.values()) {
            String p = "books." + en.key.replace('.', '_') + ".";
            yml.set(p + "level", en.level);
            yml.set(p + "state", en.state.name());
            yml.set(p + "serial", en.serial);
            yml.set(p + "world", en.world);
            yml.set(p + "x", en.x);
            yml.set(p + "y", en.y);
            yml.set(p + "z", en.z);
            yml.set(p + "finder", en.finder);
            yml.set(p + "user", en.user);
            yml.set(p + "used-at", en.usedAt);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save registry.yml: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ queries

    public Optional<Entry> get(String key) {
        return Optional.ofNullable(entries.get(key));
    }

    public List<Entry> all() {
        return new ArrayList<>(entries.values());
    }

    public List<Entry> inState(State s) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : entries.values()) if (e.state == s) out.add(e);
        return out;
    }

    // ------------------------------------------------------------------ mutations

    public void markPlaced(Entry en, String world, int x, int y, int z) {
        en.state = State.PLACED;
        en.world = world;
        en.x = x;
        en.y = y;
        en.z = z;
        save();
    }

    /** Returns true if this was the first time the book was found. */
    public boolean markFound(Entry en, String finder) {
        if (en.state == State.USED || en.state == State.FOUND) return false;
        en.state = State.FOUND;
        en.finder = finder;
        save();
        return true;
    }

    public void markUsed(Entry en, String user) {
        en.state = State.USED;
        en.user = user;
        en.usedAt = System.currentTimeMillis();
        save();
    }

    /** Re-issues a book: fresh serial, back to UNPLACED. Old copies become counterfeit. */
    public void reissue(Entry en) {
        en.serial = UUID.randomUUID().toString();
        en.state = State.UNPLACED;
        en.finder = null;
        en.user = null;
        en.usedAt = 0;
        en.world = null;
        save();
    }
}
