package net.network.enchantsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** Creates and reads the one-of-a-kind enchantment books. */
public final class BookItems {

    private final NamespacedKey keyEnchant;
    private final NamespacedKey keySerial;

    public BookItems(EnchantSMP plugin) {
        this.keyEnchant = new NamespacedKey(plugin, "registry_book");
        this.keySerial = new NamespacedKey(plugin, "registry_serial");
    }

    public ItemStack create(BookRegistry.Entry en) {
        Enchantment e = BookRegistry.enchant(en.key);
        ItemStack it = new ItemStack(Material.ENCHANTED_BOOK);
        EnchantmentStorageMeta m = (EnchantmentStorageMeta) it.getItemMeta();
        if (e != null) m.addStoredEnchant(e, en.level, true);
        m.displayName(Component.text("Book of " + BookRegistry.pretty(en.key), NamedTextColor.AQUA, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("One of one. It exists only once.", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Apply it to any item at an anvil.", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.text("Once used, copies are cursed.", NamedTextColor.RED).decoration(TextDecoration.ITALIC, false)));
        PersistentDataContainer pdc = m.getPersistentDataContainer();
        pdc.set(keyEnchant, PersistentDataType.STRING, en.key);
        pdc.set(keySerial, PersistentDataType.STRING, en.serial);
        it.setItemMeta(m);
        return it;
    }

    /** The enchantment key of a registry book, or null if this is not one. */
    public String keyOf(ItemStack it) {
        if (it == null || it.getType() != Material.ENCHANTED_BOOK || !it.hasItemMeta()) return null;
        ItemMeta m = it.getItemMeta();
        return m.getPersistentDataContainer().get(keyEnchant, PersistentDataType.STRING);
    }

    public String serialOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(keySerial, PersistentDataType.STRING);
    }
}
