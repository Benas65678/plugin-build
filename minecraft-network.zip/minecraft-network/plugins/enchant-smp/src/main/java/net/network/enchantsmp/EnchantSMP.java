package net.network.enchantsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public final class EnchantSMP extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private BookRegistry registry;
    private BookItems items;
    private Scatterer scatterer;
    private HintTask hints;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        registry = new BookRegistry(this);
        registry.load();
        items = new BookItems(this);
        scatterer = new Scatterer(this);
        hints = new HintTask(this);

        getServer().getPluginManager().registerEvents(new AnvilListener(this), this);
        getServer().getPluginManager().registerEvents(new BookGuard(this), this);
        getServer().getPluginManager().registerEvents(new LootListener(this), this);

        EnchantCommand cmd = new EnchantCommand(this);
        PluginCommand pc = getCommand("enchantsmp");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        hints.start();

        if (getConfig().getBoolean("scatter.enabled-on-first-start", true)
                && registry.inState(BookRegistry.State.PLACED).isEmpty()
                && registry.inState(BookRegistry.State.FOUND).isEmpty()
                && registry.inState(BookRegistry.State.USED).isEmpty()) {
            getServer().getScheduler().runTaskLater(this, () -> scatterer.scatter(null), 100L);
        }
    }

    @Override
    public void onDisable() {
        if (registry != null) registry.save();
    }

    public BookRegistry registry() { return registry; }
    public BookItems items() { return items; }
    public Scatterer scatterer() { return scatterer; }
    public HintTask hints() { return hints; }

    public World world() {
        World w = Bukkit.getWorld(getConfig().getString("world", "world"));
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    /** Builds a message from config.yml. Placeholders are {name}-style keys. */
    public Component msg(String key, Map<String, String> placeholders) {
        String s = getConfig().getString("messages." + key, key);
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
            s = s.replace("{" + e.getKey() + "}", e.getValue());
        }
        return MM.deserialize(getConfig().getString("messages.prefix", "") + s);
    }

    public void broadcast(String key, Map<String, String> placeholders) {
        Bukkit.broadcast(msg(key, placeholders));
    }

    public void explodeAt(Player p, BookRegistry.Entry en) {
        Location loc = p.getLocation();
        float power = (float) getConfig().getDouble("explosion.power", 4.0);
        boolean fire = getConfig().getBoolean("explosion.set-fire", false);
        boolean blocks = getConfig().getBoolean("explosion.break-blocks", true);
        loc.getWorld().createExplosion(loc, power, fire, blocks);
        broadcast("boom", Map.of("player", p.getName(), "name", BookRegistry.pretty(en.key)));
    }

    /** Gives the item or drops it at the player's feet. */
    public void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
    }
}
