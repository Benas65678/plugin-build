package net.network.enchantsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.view.AnvilView;

import java.util.Map;

/** Applies a registry book to any item, with unsafe levels and conflicting enchantments allowed. */
public final class AnvilListener implements Listener {

    private final EnchantSMP plugin;

    public AnvilListener(EnchantSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepare(PrepareAnvilEvent e) {
        AnvilInventory inv = e.getInventory();
        ItemStack left = inv.getItem(0);
        ItemStack right = inv.getItem(1);
        if (left == null || left.getType().isAir() || right == null) return;

        String key = plugin.items().keyOf(right);
        if (key == null) return;
        if (plugin.items().keyOf(left) != null) {            // book + book is not allowed
            e.setResult(null);
            return;
        }
        BookRegistry.Entry en = plugin.registry().get(key).orElse(null);
        Enchantment ench = BookRegistry.enchant(key);
        if (en == null || ench == null || en.state == BookRegistry.State.USED
                || !en.serial.equals(plugin.items().serialOf(right))) {
            e.setResult(null);                                // used or counterfeit books do nothing
            return;
        }
        if (left.getAmount() != 1) {
            e.setResult(null);
            return;
        }

        ItemStack result = left.clone();
        ItemMeta meta = result.getItemMeta();
        if (meta instanceof EnchantmentStorageMeta esm) {
            esm.addStoredEnchant(ench, en.level, true);
        } else {
            meta.addEnchant(ench, en.level, true);
        }
        result.setItemMeta(meta);
        e.setResult(result);

        int cost = Math.max(1, plugin.getConfig().getInt("xp-cost", 5));
        AnvilView view = e.getView();
        view.setMaximumRepairCost(Math.max(view.getMaximumRepairCost(), cost + 1));
        view.setRepairCost(cost);
    }

    /** Detects that the result was actually taken, then burns the book for good. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory() instanceof AnvilInventory inv)) return;
        if (e.getRawSlot() != 2) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack right = inv.getItem(1);
        String key = plugin.items().keyOf(right);
        if (key == null || inv.getItem(2) == null) return;
        if (p.getGameMode() != GameMode.CREATIVE && p.getLevel() < inv.getRepairCost()) return;

        BookRegistry.Entry en = plugin.registry().get(key).orElse(null);
        if (en == null || en.state == BookRegistry.State.USED) return;

        Bukkit.getScheduler().runTask(plugin, () -> {
            ItemStack leftNow = inv.getItem(0);
            if (leftNow != null && !leftNow.getType().isAir()) return; // result was not taken
            inv.setItem(1, null);                                       // make sure the book is consumed
            plugin.registry().markUsed(en, p.getName());
            plugin.broadcast("used", Map.of("player", p.getName(), "name", BookRegistry.pretty(en.key)));
        });
    }
}
