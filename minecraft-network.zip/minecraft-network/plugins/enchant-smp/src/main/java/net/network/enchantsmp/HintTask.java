package net.network.enchantsmp;

import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** Periodically leaks a vague location of a hidden book to the whole server. */
public final class HintTask {

    private final EnchantSMP plugin;

    public HintTask(EnchantSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (!plugin.getConfig().getBoolean("hints.enabled", true)) return;
        long period = Math.max(1, plugin.getConfig().getLong("hints.interval-minutes", 30)) * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, this::broadcastHint, period, period);
    }

    /** Broadcasts a hint. Returns false if there is no hidden book to hint at. */
    public boolean broadcastHint() {
        List<BookRegistry.Entry> hidden = new ArrayList<>(plugin.registry().inState(BookRegistry.State.PLACED));
        hidden.removeIf(e -> e.world == null);
        if (hidden.isEmpty()) return false;
        BookRegistry.Entry en = hidden.get(ThreadLocalRandom.current().nextInt(hidden.size()));
        int radius = Math.max(50, plugin.getConfig().getInt("hints.radius", 400));
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double angle = r.nextDouble(0, Math.PI * 2);
        double dist = r.nextDouble(0, radius * 0.8);
        int hx = (int) Math.round(en.x + Math.cos(angle) * dist);
        int hz = (int) Math.round(en.z + Math.sin(angle) * dist);
        plugin.broadcast("hint", Map.of(
                "name", BookRegistry.pretty(en.key),
                "radius", String.valueOf(radius),
                "x", String.valueOf(hx),
                "z", String.valueOf(hz)));
        return true;
    }
}
