package net.network.enchantsmp;

import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.LootGenerateEvent;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Optional: unplaced books can also turn up in generated structure loot (config: loot.enabled). */
public final class LootListener implements Listener {

    private final EnchantSMP plugin;

    public LootListener(EnchantSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onLoot(LootGenerateEvent e) {
        if (!plugin.getConfig().getBoolean("loot.enabled", false)) return;
        String table = e.getLootTable().getKey().getKey();
        boolean match = false;
        for (String t : plugin.getConfig().getStringList("loot.tables")) {
            if (table.contains(t)) {
                match = true;
                break;
            }
        }
        if (!match) return;
        if (ThreadLocalRandom.current().nextDouble() > plugin.getConfig().getDouble("loot.chance", 0.02)) return;

        List<BookRegistry.Entry> free = plugin.registry().inState(BookRegistry.State.UNPLACED);
        if (free.isEmpty()) return;
        BookRegistry.Entry en = free.get(ThreadLocalRandom.current().nextInt(free.size()));
        e.getLoot().add(plugin.items().create(en));
        Location l = e.getLootContext().getLocation();
        plugin.registry().markPlaced(en, l.getWorld().getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ());
    }
}
