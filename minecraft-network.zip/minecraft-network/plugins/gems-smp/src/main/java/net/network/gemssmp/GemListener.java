package net.network.gemssmp;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public final class GemListener implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final GemsSMP plugin;
    private final GemManager gems;

    public GemListener(GemsSMP plugin) {
        this.plugin = plugin;
        this.gems = plugin.gems();
    }

    // ------------------------------------------------------------------ join / death

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (gems.gemOf(p) == null) {
            GemType g = gems.randomGem();
            gems.setGem(p, g);
            gems.setEnergy(p, plugin.getConfig().getInt("start-energy", 1));
            p.sendMessage(plugin.msg("assigned", Map.of("gem", g.display)));
        }
        gems.syncItem(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        gems.clearCooldowns(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getPlayer();
        e.getDrops().removeIf(gems::isGemItem);               // gems are soulbound
        e.getItemsToKeep().removeIf(gems::isGemItem);

        if (gems.gemOf(victim) != null) {
            gems.setEnergy(victim, gems.energyOf(victim) - 1);
            victim.sendMessage(plugin.msg("energy-down", Map.of("energy", String.valueOf(gems.energyOf(victim)))));
        }
        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim) && gems.gemOf(killer) != null) {
            gems.setEnergy(killer, gems.energyOf(killer) + 1);
            gems.syncItem(killer);
            killer.sendMessage(plugin.msg("energy-up", Map.of("energy", String.valueOf(gems.energyOf(killer)))));
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> gems.syncItem(p), 2L);
    }

    // ------------------------------------------------------------------ using abilities

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack item = e.getItem();

        if (gems.isToken(item)) {
            e.setCancelled(true);
            reroll(p, item);
            return;
        }
        if (!gems.isGemItem(item)) return;
        e.setCancelled(true);
        if (!p.getUniqueId().equals(gems.ownerOf(item))) return;
        use(p, p.isSneaking() ? GemManager.Slot.ABILITY2 : GemManager.Slot.ABILITY1);
    }

    /** F key: with the gem in the off hand, F = ability 1 and Shift+F = ability 2 (no need to hold the gem). */
    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        ItemStack nowOffhand = e.getMainHandItem();           // the item that is in the off hand right now
        if (!gems.isGemItem(nowOffhand)) return;               // F with the gem in the main hand just swaps as usual
        e.setCancelled(true);
        if (p.getUniqueId().equals(gems.ownerOf(nowOffhand))) {
            use(p, p.isSneaking() ? GemManager.Slot.ABILITY2 : GemManager.Slot.ABILITY1);
        }
    }

    private void use(Player p, GemManager.Slot slot) {
        GemType g = gems.gemOf(p);
        if (g == null) return;
        if (!gems.holdsOwnGem(p)) {
            p.sendActionBar(plugin.msg("no-gem", Map.of()));
            return;
        }
        boolean first = slot == GemManager.Slot.ABILITY1;
        int need = plugin.getConfig().getInt(first ? "unlock.ability1" : "unlock.ability2", first ? 1 : 3);
        if (gems.energyOf(p) < need) {
            p.sendActionBar(plugin.msg("locked", Map.of("need", String.valueOf(need))));
            return;
        }
        long remaining = gems.remainingMs(p, slot);
        String abilityName = first ? g.a1Name : g.a2Name;
        if (remaining > 0) {
            p.sendActionBar(plugin.msg("cooldown", Map.of("ability", abilityName,
                    "seconds", String.valueOf((remaining + 999) / 1000))));
            return;
        }
        double pot = gems.potency(p);
        if (plugin.abilities().use(p, g, slot, pot)) {
            int base = first ? g.a1Cooldown : g.a2Cooldown;
            int cd = (int) Math.max(3, Math.round(base / (1 + (pot - 1) * 0.4)));
            gems.startCooldown(p, slot, cd);
            p.sendActionBar(MM.deserialize("<" + g.hex + ">" + abilityName + "!"));
        }
    }

    private void reroll(Player p, ItemStack token) {
        GemType old = gems.gemOf(p);
        GemType next;
        do {
            next = gems.randomGem();
        } while (next == old && GemType.values().length > 1);
        gems.setGem(p, next);
        gems.syncItem(p);
        token.setAmount(token.getAmount() - 1);
        p.sendMessage(plugin.msg("assigned", Map.of("gem", next.display)));
    }

    // ------------------------------------------------------------------ passives that need events

    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        if (gems.gemOf(p) == GemType.GALE && gems.holdsOwnGem(p)) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ soulbound rules

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (gems.isGemItem(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryType top = e.getView().getTopInventory().getType();
        if (top == InventoryType.CRAFTING) return;             // only the player's own inventory is open
        boolean gem = gems.isGemItem(e.getCurrentItem()) || gems.isGemItem(e.getCursor());
        if (!gem && e.getClick() == ClickType.NUMBER_KEY) {
            gem = gems.isGemItem(p.getInventory().getItem(e.getHotbarButton()));
        }
        if (!gem && e.getClick() == ClickType.SWAP_OFFHAND) {
            gem = gems.isGemItem(p.getInventory().getItemInOffHand());
        }
        if (gem) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getType() == InventoryType.CRAFTING) return;
        if (!gems.isGemItem(e.getOldCursor())) return;
        int topSize = e.getView().getTopInventory().getSize();
        for (int slot : e.getRawSlots()) {
            if (slot < topSize) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        ItemStack inHand = e.getPlayer().getInventory().getItem(e.getHand());
        if (gems.isGemItem(inHand) || gems.isToken(inHand)) e.setCancelled(true);
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (gems.isGemItem(it) || gems.isToken(it)) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCraft(CraftItemEvent e) {
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (gems.isGemItem(it) || gems.isToken(it)) {
                e.setCancelled(true);
                return;
            }
        }
    }
}
