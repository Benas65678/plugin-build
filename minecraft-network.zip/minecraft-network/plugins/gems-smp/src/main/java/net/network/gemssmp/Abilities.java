package net.network.gemssmp;

import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** The actual powers. Every method returns true when the ability fired (so the cooldown starts). */
public final class Abilities {

    private final GemsSMP plugin;

    public Abilities(GemsSMP plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ helpers

    private boolean valid(Player caster, Entity e) {
        if (!(e instanceof LivingEntity) || e.equals(caster) || e instanceof ArmorStand) return false;
        if (e instanceof Player p) {
            if (!plugin.getConfig().getBoolean("pvp-abilities", true)) return false;
            return p.getGameMode() == org.bukkit.GameMode.SURVIVAL || p.getGameMode() == org.bukkit.GameMode.ADVENTURE;
        }
        return true;
    }

    private LivingEntity target(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.7, e -> valid(p, e));
        return r == null ? null : (LivingEntity) r.getHitEntity();
    }

    private List<LivingEntity> nearby(Player p, double radius) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : p.getNearbyEntities(radius, radius, radius)) {
            if (valid(p, e)) out.add((LivingEntity) e);
        }
        return out;
    }

    private static void effect(Player p, PotionEffectType t, int ticks, int amp) {
        p.addPotionEffect(new PotionEffect(t, ticks, amp, true, false, true));
    }

    private static void effect(LivingEntity e, PotionEffectType t, int ticks, int amp) {
        e.addPotionEffect(new PotionEffect(t, ticks, amp, true, true, true));
    }

    private static void ring(Location c, double radius, Particle particle, int points) {
        World w = c.getWorld();
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            w.spawnParticle(particle, c.getX() + Math.cos(a) * radius, c.getY() + 0.2, c.getZ() + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
    }

    private static void ring(Location c, double radius, Color color, int points) {
        World w = c.getWorld();
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            w.spawnParticle(Particle.DUST, c.getX() + Math.cos(a) * radius, c.getY() + 0.2, c.getZ() + Math.sin(a) * radius,
                    1, 0, 0, 0, 0, new Particle.DustOptions(color, 1.6f));
        }
    }

    private static void trail(Location from, Location to, Particle particle) {
        Vector v = to.toVector().subtract(from.toVector());
        double len = v.length();
        if (len < 0.1) return;
        v.normalize();
        for (double d = 0; d < len; d += 0.6) {
            Location l = from.clone().add(v.clone().multiply(d));
            l.getWorld().spawnParticle(particle, l, 2, 0.05, 0.05, 0.05, 0.01);
        }
    }

    private static Vector away(Location from, Location to) {
        Vector v = to.toVector().subtract(from.toVector()).setY(0);
        if (v.lengthSquared() < 0.0001) v = new Vector(0, 0, 1);
        return v.normalize();
    }

    private static Color color(GemType g) {
        return Color.fromRGB(Integer.parseInt(g.hex.substring(1), 16));
    }

    // ------------------------------------------------------------------ passives

    public void passive(Player p, GemType g) {
        switch (g) {
            case EMBER -> effect(p, PotionEffectType.FIRE_RESISTANCE, 100, 0);
            case TIDE -> {
                effect(p, PotionEffectType.WATER_BREATHING, 100, 0);
                if (p.isInWater()) effect(p, PotionEffectType.DOLPHINS_GRACE, 100, 0);
            }
            case GALE -> effect(p, PotionEffectType.JUMP_BOOST, 100, 1);
            case TERRA -> effect(p, PotionEffectType.HASTE, 100, 0);
            case VOLT -> effect(p, PotionEffectType.SPEED, 100, 0);
            case SHADE -> effect(p, PotionEffectType.NIGHT_VISION, 400, 0);
            case VITAL -> {
                if (p.getHealth() < p.getMaxHealth() * 0.5) effect(p, PotionEffectType.REGENERATION, 100, 0);
            }
            case FROST -> {
                p.setFreezeTicks(0);
                p.removePotionEffect(PotionEffectType.SLOWNESS);
            }
        }
    }

    // ------------------------------------------------------------------ abilities

    public boolean use(Player p, GemType g, GemManager.Slot slot, double pot) {
        boolean first = slot == GemManager.Slot.ABILITY1;
        return switch (g) {
            case EMBER -> first ? fireBolt(p, pot) : infernoRing(p, pot);
            case TIDE -> first ? tidalSurge(p, pot) : riptide(p, pot);
            case GALE -> first ? dash(p, pot) : cyclone(p, pot);
            case TERRA -> first ? quake(p, pot) : bulwark(p, pot);
            case VOLT -> first ? smite(p, pot) : chainLightning(p, pot);
            case SHADE -> first ? vanish(p, pot) : blink(p, pot);
            case VITAL -> first ? mend(p, pot) : siphon(p, pot);
            case FROST -> first ? frostNova(p, pot) : glacialPrison(p, pot);
        };
    }

    // Ember
    private boolean fireBolt(Player p, double pot) {
        int n = Math.min(5, 1 + (int) ((pot - 1) / 0.5));
        Vector base = p.getEyeLocation().getDirection();
        boolean grief = plugin.getConfig().getBoolean("grief", false);
        for (int i = 0; i < n; i++) {
            double spread = (i - (n - 1) / 2.0) * 0.12;
            Vector dir = base.clone().rotateAroundY(spread).multiply(1.6);
            SmallFireball fb = p.launchProjectile(SmallFireball.class, dir);
            fb.setIsIncendiary(grief);
            fb.setYield(0f);
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
        return true;
    }

    private boolean infernoRing(Player p, double pot) {
        double r = 6 * (0.85 + 0.15 * pot);
        for (LivingEntity e : nearby(p, r)) {
            e.setFireTicks((int) (80 * pot));
            e.damage(4 * pot, p);
            e.setVelocity(away(p.getLocation(), e.getLocation()).multiply(0.9 * pot).setY(0.4));
        }
        ring(p.getLocation(), r, Particle.FLAME, 48);
        ring(p.getLocation(), r * 0.6, Particle.FLAME, 32);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        return true;
    }

    // Tide
    private boolean tidalSurge(Player p, double pot) {
        LivingEntity t = target(p, 20);
        if (t == null) return false;
        Vector v = p.getEyeLocation().getDirection().multiply(1.6 * pot).setY(0.5);
        t.setVelocity(v);
        t.damage(3 * pot, p);
        trail(p.getEyeLocation(), t.getLocation().add(0, 1, 0), Particle.SPLASH);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 1f);
        return true;
    }

    private boolean riptide(Player p, double pot) {
        Vector dir = p.getEyeLocation().getDirection();
        Vector v = dir.multiply(1.9 + 0.2 * pot);
        v.setY(Math.max(v.getY(), 0.35));
        p.setVelocity(v);
        effect(p, PotionEffectType.SLOW_FALLING, 100, 0);
        p.getWorld().spawnParticle(Particle.SPLASH, p.getLocation(), 60, 0.6, 0.6, 0.6, 0.2);
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_3, 1f, 1f);
        return true;
    }

    // Gale
    private boolean dash(Player p, double pot) {
        Vector dir = p.getEyeLocation().getDirection();
        Vector v = dir.multiply(1.5 * pot);
        v.setY(Math.max(v.getY(), 0.2));
        p.setVelocity(v);
        p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 25, 0.3, 0.2, 0.3, 0.05);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1f, 1.3f);
        return true;
    }

    private boolean cyclone(Player p, double pot) {
        double r = 7;
        for (LivingEntity e : nearby(p, r)) {
            e.setVelocity(away(p.getLocation(), e.getLocation()).multiply(1.2 * pot).setY(0.9));
            e.damage(2, p);
        }
        effect(p, PotionEffectType.SLOW_FALLING, 160, 0);
        p.setVelocity(new Vector(0, 0.9, 0));
        ring(p.getLocation(), r, Particle.CLOUD, 48);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1f, 1f);
        return true;
    }

    // Terra
    private boolean quake(Player p, double pot) {
        double r = 5 + pot;
        for (LivingEntity e : nearby(p, r)) {
            e.damage(4 * pot, p);
            effect(e, PotionEffectType.SLOWNESS, 60, 1);
        }
        p.getWorld().spawnParticle(Particle.BLOCK, p.getLocation(), 80, r / 2, 0.2, r / 2, 0.1,
                Material.DIRT.createBlockData());
        ring(p.getLocation(), r, color(GemType.TERRA), 48);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.6f);
        return true;
    }

    private boolean bulwark(Player p, double pot) {
        effect(p, PotionEffectType.ABSORPTION, (int) (200 * pot), 1);
        effect(p, PotionEffectType.RESISTANCE, 120, 1);
        p.getWorld().spawnParticle(Particle.BLOCK, p.getLocation().add(0, 1, 0), 60, 0.5, 0.8, 0.5, 0.1,
                Material.STONE.createBlockData());
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.8f, 0.7f);
        return true;
    }

    // Volt
    private boolean smite(Player p, double pot) {
        LivingEntity t = target(p, 25);
        Location at;
        if (t != null) {
            at = t.getLocation();
            t.damage(6 * pot, p);
        } else {
            Location eye = p.getEyeLocation();
            RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), 25, FluidCollisionMode.NEVER, true);
            if (r == null) return false;
            at = r.getHitPosition().toLocation(p.getWorld());
        }
        p.getWorld().strikeLightningEffect(at);
        return true;
    }

    private boolean chainLightning(Player p, double pot) {
        LivingEntity current = target(p, 22);
        if (current == null) return false;
        Set<LivingEntity> hit = new HashSet<>();
        int jumps = 3 + plugin.gems().energyOf(p);
        while (current != null && jumps-- > 0) {
            hit.add(current);
            current.damage(4 * pot, p);
            p.getWorld().strikeLightningEffect(current.getLocation());
            LivingEntity next = null;
            double best = 7 * 7;
            for (Entity e : current.getNearbyEntities(7, 7, 7)) {
                if (!valid(p, e) || hit.contains(e)) continue;
                double d = e.getLocation().distanceSquared(current.getLocation());
                if (d < best) {
                    best = d;
                    next = (LivingEntity) e;
                }
            }
            if (next != null) trail(current.getLocation().add(0, 1, 0), next.getLocation().add(0, 1, 0), Particle.ELECTRIC_SPARK);
            current = next;
        }
        return true;
    }

    // Shade
    private boolean vanish(Player p, double pot) {
        effect(p, PotionEffectType.INVISIBILITY, (int) (120 * pot), 0);
        effect(p, PotionEffectType.SPEED, 120, 1);
        p.getWorld().spawnParticle(Particle.SMOKE, p.getLocation().add(0, 1, 0), 40, 0.4, 0.8, 0.4, 0.02);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.7f, 0.6f);
        return true;
    }

    private boolean blink(Player p, double pot) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        double max = 10 + 2 * pot;
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, dir, max, FluidCollisionMode.NEVER, true);
        double d = r == null ? max : Math.max(0, r.getHitPosition().distance(eye.toVector()) - 1.0);
        Location dest = null;
        while (d > 0.5) {
            Location feet = eye.clone().add(dir.clone().multiply(d)).subtract(0, 1.62, 0);
            if (feet.getBlock().isPassable() && feet.clone().add(0, 1, 0).getBlock().isPassable()) {
                dest = feet;
                break;
            }
            d -= 0.5;
        }
        if (dest == null) return false;
        dest.setYaw(p.getLocation().getYaw());
        dest.setPitch(p.getLocation().getPitch());
        Location from = p.getLocation();
        p.getWorld().spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.3);
        p.teleport(dest);
        p.getWorld().spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.3);
        p.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        return true;
    }

    // Vital
    private boolean mend(Player p, double pot) {
        p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + 6 * pot));
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.5, 0), 10, 0.4, 0.4, 0.4, 0);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        return true;
    }

    private boolean siphon(Player p, double pot) {
        double total = 0;
        List<LivingEntity> targets = nearby(p, 6);
        if (targets.isEmpty()) return false;
        for (LivingEntity e : targets) {
            e.damage(3 * pot, p);
            total += 3 * pot;
            trail(e.getLocation().add(0, 1, 0), p.getLocation().add(0, 1, 0), Particle.HEART);
        }
        p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + total * 0.8));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.5f, 1.8f);
        return true;
    }

    // Frost
    private boolean frostNova(Player p, double pot) {
        double r = 6;
        for (LivingEntity e : nearby(p, r)) {
            effect(e, PotionEffectType.SLOWNESS, (int) (80 * pot), 2);
            e.setFreezeTicks(140);
            e.damage(2, p);
        }
        ring(p.getLocation(), r, Particle.SNOWFLAKE, 60);
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.6f);
        return true;
    }

    private boolean glacialPrison(Player p, double pot) {
        LivingEntity t = target(p, 18);
        if (t == null) return false;
        int ticks = (int) (60 * pot);
        effect(t, PotionEffectType.SLOWNESS, ticks, 6);
        t.setFreezeTicks(ticks + 40);
        t.getWorld().spawnParticle(Particle.SNOWFLAKE, t.getLocation().add(0, 1, 0), 80, 0.5, 0.9, 0.5, 0.02);
        trail(p.getEyeLocation(), t.getLocation().add(0, 1, 0), Particle.SNOWFLAKE);
        p.getWorld().playSound(t.getLocation(), Sound.BLOCK_GLASS_PLACE, 1f, 0.5f);
        return true;
    }
}
