package net.network.gemssmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Player gem + energy (stored on the player), gem items (soulbound), cooldowns. */
public final class GemManager {

    public enum Slot { ABILITY1, ABILITY2 }

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final GemsSMP plugin;
    private final NamespacedKey playerGem, playerEnergy, itemOwner, itemGem, tokenKey;
    private final Map<UUID, Map<Slot, Long>> cooldowns = new HashMap<>();

    public GemManager(GemsSMP plugin) {
        this.plugin = plugin;
        this.playerGem = new NamespacedKey(plugin, "gem");
        this.playerEnergy = new NamespacedKey(plugin, "energy");
        this.itemOwner = new NamespacedKey(plugin, "owner");
        this.itemGem = new NamespacedKey(plugin, "gem_item");
        this.tokenKey = new NamespacedKey(plugin, "reroll_token");
    }

    // ------------------------------------------------------------------ player data

    public GemType gemOf(Player p) {
        return GemType.byId(p.getPersistentDataContainer().get(playerGem, PersistentDataType.STRING));
    }

    public void setGem(Player p, GemType g) {
        p.getPersistentDataContainer().set(playerGem, PersistentDataType.STRING, g.id());
    }

    public int energyOf(Player p) {
        Integer e = p.getPersistentDataContainer().get(playerEnergy, PersistentDataType.INTEGER);
        return e == null ? plugin.getConfig().getInt("start-energy", 1) : e;
    }

    public void setEnergy(Player p, int energy) {
        int max = plugin.getConfig().getInt("max-energy", 5);
        p.getPersistentDataContainer().set(playerEnergy, PersistentDataType.INTEGER, Math.max(1, Math.min(max, energy)));
    }

    public double potency(Player p) {
        return 1.0 + plugin.getConfig().getDouble("potency-per-tier", 0.25) * (energyOf(p) - 1);
    }

    public GemType randomGem() {
        GemType[] all = GemType.values();
        return all[ThreadLocalRandom.current().nextInt(all.length)];
    }

    // ------------------------------------------------------------------ gem items

    public ItemStack createItem(Player p, GemType g) {
        ItemStack it = new ItemStack(g.icon);
        ItemMeta m = it.getItemMeta();
        m.displayName(MM.deserialize(g.display).decoration(TextDecoration.ITALIC, false)
                .decoration(TextDecoration.BOLD, true));
        m.lore(lore(g, energyOf(p)));
        PersistentDataContainer pdc = m.getPersistentDataContainer();
        pdc.set(itemOwner, PersistentDataType.STRING, p.getUniqueId().toString());
        pdc.set(itemGem, PersistentDataType.STRING, g.id());
        m.setEnchantmentGlintOverride(true);
        it.setItemMeta(m);
        return it;
    }

    private List<Component> lore(GemType g, int energy) {
        int max = plugin.getConfig().getInt("max-energy", 5);
        int u1 = plugin.getConfig().getInt("unlock.ability1", 1);
        int u2 = plugin.getConfig().getInt("unlock.ability2", 3);
        List<Component> l = new ArrayList<>();
        l.add(line("<gray>Energy: <white>" + "◆".repeat(energy) + "<dark_gray>" + "◇".repeat(Math.max(0, max - energy))));
        l.add(line(""));
        l.add(line("<gray>Passive: <white>" + g.passiveName));
        l.add(line("<dark_gray>" + g.passiveDesc));
        l.add(line((energy >= u1 ? "<green>" : "<red>") + "Right-click: <white>" + g.a1Name));
        l.add(line("<dark_gray>" + g.a1Desc));
        l.add(line((energy >= u2 ? "<green>" : "<red>") + "Sneak + right-click: <white>" + g.a2Name
                + (energy >= u2 ? "" : " <red>(energy " + u2 + ")")));
        l.add(line("<dark_gray>" + g.a2Desc));
        l.add(line(""));
        l.add(line("<dark_purple>Soulbound"));
        return l;
    }

    private static Component line(String s) {
        return MM.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public boolean isGemItem(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(itemGem, PersistentDataType.STRING);
    }

    public UUID ownerOf(ItemStack it) {
        if (!isGemItem(it)) return null;
        String s = it.getItemMeta().getPersistentDataContainer().get(itemOwner, PersistentDataType.STRING);
        try {
            return s == null ? null : UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** True if the player carries their own gem item. */
    public boolean holdsOwnGem(Player p) {
        PlayerInventory inv = p.getInventory();
        for (ItemStack it : inv.getContents()) {
            if (it != null && p.getUniqueId().equals(ownerOf(it))) return true;
        }
        return false;
    }

    /** Re-gives the gem if missing, or refreshes lore/energy on the existing one. */
    public void syncItem(Player p) {
        GemType g = gemOf(p);
        if (g == null) return;
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (it != null && isGemItem(it)) {
                if (p.getUniqueId().equals(ownerOf(it))) {
                    inv.setItem(i, createItem(p, g));
                } else {
                    inv.setItem(i, null);       // somebody else's gem, or an outdated one
                }
            }
        }
        if (!holdsOwnGem(p)) plugin.giveItem(p, createItem(p, g));
    }

    // ------------------------------------------------------------------ reroll token

    public ItemStack createToken() {
        ItemStack it = new ItemStack(Material.NETHER_STAR);
        ItemMeta m = it.getItemMeta();
        m.displayName(MM.deserialize("<light_purple>Gem Reroll Token").decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(line("<gray>Right-click to reroll your gem."), line("<gray>Your energy is kept.")));
        m.getPersistentDataContainer().set(tokenKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public boolean isToken(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(tokenKey, PersistentDataType.BYTE);
    }

    // ------------------------------------------------------------------ cooldowns

    public long remainingMs(Player p, Slot s) {
        Long until = cooldowns.getOrDefault(p.getUniqueId(), Map.of()).get(s);
        return until == null ? 0 : Math.max(0, until - System.currentTimeMillis());
    }

    public void startCooldown(Player p, Slot s, int seconds) {
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(Slot.class))
                .put(s, System.currentTimeMillis() + seconds * 1000L);
    }

    public void clearCooldowns(UUID id) {
        cooldowns.remove(id);
    }
}
