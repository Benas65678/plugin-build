package net.network.gemssmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

public final class GemsSMP extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private GemManager gems;
    private Abilities abilities;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        gems = new GemManager(this);
        abilities = new Abilities(this);
        getServer().getPluginManager().registerEvents(new GemListener(this), this);

        GemCommand cmd = new GemCommand(this);
        PluginCommand pc = getCommand("gems");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        // passives every 2 seconds, only while the owner actually holds their gem
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                GemType g = gems.gemOf(p);
                if (g != null && !p.isDead() && gems.holdsOwnGem(p)) abilities.passive(p, g);
            }
        }, 40L, 40L);
    }

    public GemManager gems() {
        return gems;
    }

    public Abilities abilities() {
        return abilities;
    }

    public Component msg(String key, Map<String, String> placeholders) {
        String s = getConfig().getString("messages." + key, key);
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
            s = s.replace("{" + e.getKey() + "}", e.getValue());
        }
        return MM.deserialize(getConfig().getString("messages.prefix", "") + s);
    }

    public void giveItem(Player p, ItemStack it) {
        for (ItemStack rest : p.getInventory().addItem(it).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }
}
