package net.network.gemssmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GemCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final GemsSMP plugin;

    public GemCommand(GemsSMP plugin) {
        this.plugin = plugin;
    }

    private static void say(CommandSender s, String text, NamedTextColor c) {
        s.sendMessage(Component.text(text, c));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        GemManager gems = plugin.gems();
        String sub = args.length == 0 ? "info" : args[0].toLowerCase(Locale.ROOT);
        boolean admin = sender.hasPermission("gems.admin");

        switch (sub) {
            case "info" -> {
                if (!(sender instanceof Player p)) return true;
                GemType g = gems.gemOf(p);
                if (g == null) {
                    say(sender, "You have no gem yet. Rejoin the server.", NamedTextColor.RED);
                    return true;
                }
                sender.sendMessage(MM.deserialize(g.display + " <gray>- energy <white>" + gems.energyOf(p)
                        + "<gray>/" + plugin.getConfig().getInt("max-energy", 5)));
                sender.sendMessage(MM.deserialize("<gray>Passive: <white>" + g.passiveName + " <dark_gray>- " + g.passiveDesc));
                sender.sendMessage(MM.deserialize("<gray>Right-click / F: <white>" + g.a1Name + " <dark_gray>- " + g.a1Desc));
                sender.sendMessage(MM.deserialize("<gray>Sneak + right-click / Shift+F: <white>" + g.a2Name + " <dark_gray>- " + g.a2Desc));
                sender.sendMessage(MM.deserialize("<dark_gray>Tip: keep your gem in the off hand and press F to use it without holding it."));
            }
            case "list" -> {
                for (GemType g : GemType.values()) {
                    sender.sendMessage(MM.deserialize(g.display + " <dark_gray>- <gray>" + g.passiveName + ", " + g.a1Name + ", " + g.a2Name));
                }
            }
            case "give", "reroll", "energy", "token" -> {
                if (!admin) {
                    say(sender, "You do not have permission.", NamedTextColor.RED);
                    return true;
                }
                if (args.length < 2) {
                    say(sender, "/gems " + sub + " <player> " + (sub.equals("give") ? "[gem]" : sub.equals("energy") ? "<1-5>" : ""), NamedTextColor.RED);
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) {
                    say(sender, "Player not found.", NamedTextColor.RED);
                    return true;
                }
                switch (sub) {
                    case "give" -> {
                        GemType g = args.length >= 3 ? GemType.byId(args[2]) : gems.randomGem();
                        if (g == null) {
                            say(sender, "Unknown gem. Use /gems list.", NamedTextColor.RED);
                            return true;
                        }
                        gems.setGem(t, g);
                        gems.syncItem(t);
                        say(sender, t.getName() + " now owns the " + g.id() + " gem.", NamedTextColor.GREEN);
                    }
                    case "reroll" -> {
                        GemType g = gems.randomGem();
                        gems.setGem(t, g);
                        gems.syncItem(t);
                        say(sender, t.getName() + " rerolled into " + g.id() + ".", NamedTextColor.GREEN);
                    }
                    case "energy" -> {
                        if (args.length < 3) {
                            say(sender, "/gems energy <player> <1-5>", NamedTextColor.RED);
                            return true;
                        }
                        try {
                            gems.setEnergy(t, Integer.parseInt(args[2]));
                        } catch (NumberFormatException ex) {
                            say(sender, "Not a number.", NamedTextColor.RED);
                            return true;
                        }
                        gems.syncItem(t);
                        say(sender, t.getName() + " energy is now " + gems.energyOf(t) + ".", NamedTextColor.GREEN);
                    }
                    default -> {
                        plugin.giveItem(t, gems.createToken());
                        say(sender, "Gave a reroll token to " + t.getName() + ".", NamedTextColor.GREEN);
                    }
                }
            }
            default -> say(sender, "/gems <info|list" + (admin ? "|give|reroll|energy|token" : "") + ">", NamedTextColor.GRAY);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("gems.admin");
        if (args.length == 1) {
            out.addAll(List.of("info", "list"));
            if (admin) out.addAll(List.of("give", "reroll", "energy", "token"));
        } else if (args.length == 2 && admin) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (args.length == 3 && admin && args[0].equalsIgnoreCase("give")) {
            for (GemType g : GemType.values()) out.add(g.id());
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }
}
