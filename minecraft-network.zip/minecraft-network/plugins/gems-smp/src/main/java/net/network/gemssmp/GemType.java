package net.network.gemssmp;

import org.bukkit.Material;

import java.util.Locale;

/** The eight gems. Ability logic lives in {@link Abilities}. */
public enum GemType {
    EMBER("<#ff7b00>Ember Gem", Material.BLAZE_POWDER, "#ff7b00",
            "Cinder Skin", "Fire resistance, never burns.",
            "Fire Bolt", "Hurl a fireball.", 12,
            "Inferno Ring", "Blast and ignite everything around you.", 50),
    TIDE("<#00b4d8>Tide Gem", Material.PRISMARINE_CRYSTALS, "#00b4d8",
            "Deep Lungs", "Water breathing and dolphin's grace in water.",
            "Tidal Surge", "Blast a target away with a jet of water.", 15,
            "Riptide", "Launch yourself forward.", 40),
    GALE("<#b8f2e6>Gale Gem", Material.FEATHER, "#b8f2e6",
            "Featherfall", "No fall damage and extra jump height.",
            "Dash", "Burst forward in the direction you look.", 8,
            "Cyclone", "Fling everything near you into the air.", 55),
    TERRA("<#8d6e4a>Terra Gem", Material.CLAY_BALL, "#8d6e4a",
            "Prospector", "Permanent haste.",
            "Quake", "Shockwave that hurts and slows nearby foes.", 18,
            "Bulwark", "Absorption and resistance.", 50),
    VOLT("<#ffd60a>Volt Gem", Material.GLOWSTONE_DUST, "#ffd60a",
            "Static", "Permanent speed.",
            "Smite", "Call lightning on your target.", 15,
            "Chain Lightning", "Lightning that jumps between enemies.", 60),
    SHADE("<#6a4c93>Shade Gem", Material.ECHO_SHARD, "#6a4c93",
            "Nightsight", "Night vision.",
            "Vanish", "Turn invisible and fast.", 25,
            "Blink", "Teleport forward.", 30),
    VITAL("<#ef476f>Vital Gem", Material.GHAST_TEAR, "#ef476f",
            "Resilience", "Regeneration when badly hurt.",
            "Mend", "Heal yourself.", 30,
            "Siphon", "Drain nearby enemies to heal.", 60),
    FROST("<#a2d2ff>Frost Gem", Material.HEART_OF_THE_SEA, "#a2d2ff",
            "Glacial Skin", "Immune to freezing and slowness.",
            "Frost Nova", "Slow and chill everything around you.", 22,
            "Glacial Prison", "Lock a target in place.", 55);

    public final String display;       // MiniMessage
    public final Material icon;
    public final String hex;
    public final String passiveName, passiveDesc;
    public final String a1Name, a1Desc;
    public final int a1Cooldown;
    public final String a2Name, a2Desc;
    public final int a2Cooldown;

    GemType(String display, Material icon, String hex,
            String passiveName, String passiveDesc,
            String a1Name, String a1Desc, int a1Cooldown,
            String a2Name, String a2Desc, int a2Cooldown) {
        this.display = display;
        this.icon = icon;
        this.hex = hex;
        this.passiveName = passiveName;
        this.passiveDesc = passiveDesc;
        this.a1Name = a1Name;
        this.a1Desc = a1Desc;
        this.a1Cooldown = a1Cooldown;
        this.a2Name = a2Name;
        this.a2Desc = a2Desc;
        this.a2Cooldown = a2Cooldown;
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static GemType byId(String id) {
        if (id == null) return null;
        try {
            return valueOf(id.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
