package net.network.lifesteal;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LifestealListener implements Listener {

    private record Tag(long until, UUID attacker) {
    }

    private final LifestealPlugin plugin;
    private final Map<UUID, Tag> combat = new HashMap<>();

    public LifestealListener(LifestealPlugin plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ eliminated players cannot log in

    @EventHandler(priority = EventPriority.HIGH)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (plugin.store().isEliminated(e.getUniqueId())) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    plugin.msg("eliminated", Map.of()));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.store().sessionStart(e.getPlayer().getUniqueId());
        plugin.ensurePlayer(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.applyHearts(p), 1L);
    }

    // ------------------------------------------------------------------ newbie shield + combat tag

    public boolean shielded(Player p) {
        int minutes = plugin.getConfig().getInt("newbie-shield-minutes", 30);
        if (minutes <= 0 || plugin.store().shieldOff(p.getUniqueId())) return false;
        return plugin.store().playedMs(p.getUniqueId()) < minutes * 60_000L;
    }

    private static Player attackerOf(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Player p) return p;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = attackerOf(e.getDamager());
        if (attacker == null || attacker.equals(victim)) return;

        if (shielded(victim)) {
            e.setCancelled(true);
            attacker.sendActionBar(plugin.msg("shield-attacker", Map.of("player", victim.getName())));
            return;
        }
        if (shielded(attacker)) {
            e.setCancelled(true);
            attacker.sendActionBar(plugin.msg("shield-self", Map.of()));
            return;
        }
        int secs = plugin.getConfig().getInt("combat-tag-seconds", 15);
        if (secs > 0) {
            long until = System.currentTimeMillis() + secs * 1000L;
            tag(victim, until, attacker.getUniqueId(), secs);
            tag(attacker, until, victim.getUniqueId(), secs);
        }
    }

    private void tag(Player p, long until, UUID other, int secs) {
        boolean wasTagged = combat.containsKey(p.getUniqueId()) && combat.get(p.getUniqueId()).until() > System.currentTimeMillis();
        combat.put(p.getUniqueId(), new Tag(until, other));
        if (!wasTagged) p.sendActionBar(plugin.msg("tagged", Map.of("seconds", String.valueOf(secs))));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Tag t = combat.remove(p.getUniqueId());
        if (t != null && t.until() > System.currentTimeMillis()
                && plugin.getConfig().getBoolean("combat-log-kill", true) && !p.isDead()) {
            Player attacker = Bukkit.getPlayer(t.attacker());
            if (attacker != null) p.damage(1000.0, attacker);
            else p.setHealth(0.0);
        }
        plugin.store().sessionEnd(p.getUniqueId());
    }

    // ------------------------------------------------------------------ the heart exchange

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getPlayer();
        Player killer = victim.getKiller();
        if (killer != null && killer.equals(victim)) killer = null;
        combat.remove(victim.getUniqueId());

        if (killer == null) {
            if (!plugin.getConfig().getBoolean("lose-heart-on-pve-death", true)) return;
            if (plugin.getConfig().getBoolean("shield-protects-pve-heart-loss", true) && shielded(victim)) return;
        }

        int max = plugin.getConfig().getInt("max-hearts", 20);
        int before = plugin.hearts(victim);
        int after = Math.max(0, before - 1);
        plugin.setHearts(victim, after);

        if (killer != null) {
            if (plugin.hearts(killer) < max) {
                plugin.setHearts(killer, plugin.hearts(killer) + 1);
                killer.sendMessage(plugin.msg("gained", Map.of("hearts", String.valueOf(plugin.hearts(killer)))));
            } else {
                Location at = victim.getLocation();
                at.getWorld().dropItemNaturally(at, plugin.items().heart(1));
                killer.sendMessage(plugin.msg("max", Map.of()));
            }
        }

        if (after <= 0) {
            plugin.store().eliminate(victim.getUniqueId(), victim.getName());
            Bukkit.broadcast(plugin.msg("eliminated-broadcast", Map.of("player", victim.getName())));
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!victim.isOnline()) return;
                plugin.sendToHub(victim);
                Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (victim.isOnline()) victim.kick(plugin.msg("eliminated", Map.of()));
                }, 40L);
            }, 30L);
        } else {
            victim.sendMessage(plugin.msg("lost", Map.of("hearts", String.valueOf(after))));
        }
    }

    // ------------------------------------------------------------------ using a heart item

    @EventHandler(priority = EventPriority.HIGH)
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (plugin.items().isRevival(item)) {
            e.setCancelled(true);
            e.getPlayer().sendActionBar(Component.text("Use /revive <player> while holding this."));
            return;
        }
        if (!plugin.items().isHeart(item)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        int max = plugin.getConfig().getInt("max-hearts", 20);
        if (plugin.hearts(p) >= max) {
            p.sendActionBar(Component.text("You are already at max hearts."));
            return;
        }
        item.setAmount(item.getAmount() - 1);
        plugin.setHearts(p, plugin.hearts(p) + 1);
        p.sendMessage(plugin.msg("gained", Map.of("hearts", String.valueOf(plugin.hearts(p)))));
    }
}
