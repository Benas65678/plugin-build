package net.network.lifesteal;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class LifestealCommands implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final LifestealPlugin plugin;

    public LifestealCommands(LifestealPlugin plugin) {
        this.plugin = plugin;
    }

    private static void say(CommandSender s, String text, NamedTextColor c) {
        s.sendMessage(Component.text(text, c));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "hearts" -> hearts(sender, args);
            case "withdraw" -> withdraw(sender, args);
            case "revive" -> revive(sender, args);
            case "shield" -> shield(sender, args);
            case "lifesteal" -> admin(sender, args);
            default -> {
            }
        }
        return true;
    }

    private void hearts(CommandSender sender, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("top")) {
            sender.sendMessage(MM.deserialize("<red><bold>Top hearts"));
            int i = 1;
            for (UUID id : plugin.store().top(10)) {
                sender.sendMessage(MM.deserialize("<gray>" + i++ + ". <white>" + plugin.store().name(id)
                        + " <red>" + plugin.store().hearts(id) + " ❤"));
            }
            return;
        }
        if (args.length >= 1) {
            OfflinePlayer t = Bukkit.getOfflinePlayerIfCached(args[0]);
            if (t == null || !plugin.store().known(t.getUniqueId())) {
                say(sender, "Unknown player.", NamedTextColor.RED);
                return;
            }
            sender.sendMessage(MM.deserialize("<white>" + args[0] + " <gray>has <red>"
                    + plugin.store().hearts(t.getUniqueId()) + " ❤"));
            return;
        }
        if (sender instanceof Player p) {
            sender.sendMessage(MM.deserialize("<gray>You have <red>" + plugin.hearts(p) + " ❤ <gray>(max "
                    + plugin.getConfig().getInt("max-hearts", 20) + ")"));
        }
    }

    private void withdraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) return;
        int n = 1;
        if (args.length >= 1) {
            try {
                n = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex) {
                say(sender, "Usage: /withdraw [amount]", NamedTextColor.RED);
                return;
            }
        }
        if (n < 1 || n > 10) {
            say(sender, "Pick an amount between 1 and 10.", NamedTextColor.RED);
            return;
        }
        if (plugin.hearts(p) - n < 1) {
            say(sender, "You need to keep at least 1 heart.", NamedTextColor.RED);
            return;
        }
        plugin.setHearts(p, plugin.hearts(p) - n);
        plugin.giveOrDrop(p, plugin.items().heart(n));
        sender.sendMessage(plugin.msg("lost", Map.of("hearts", String.valueOf(plugin.hearts(p)))));
    }

    private void revive(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) return;
        if (args.length < 1) {
            say(sender, "Usage: /revive <player>", NamedTextColor.RED);
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!plugin.items().isRevival(hand)) {
            say(sender, "Hold a Revival Compass in your main hand.", NamedTextColor.RED);
            return;
        }
        UUID id = plugin.store().uncheckedFindEliminated(args[0]);
        if (id == null) {
            say(sender, "No eliminated player with that name.", NamedTextColor.RED);
            return;
        }
        hand.setAmount(hand.getAmount() - 1);
        doRevive(id, p.getName());
    }

    private void doRevive(UUID id, String reviver) {
        String name = plugin.store().name(id);
        plugin.store().revive(id, plugin.getConfig().getInt("revive-hearts", 4));
        Bukkit.broadcast(plugin.msg("revived-broadcast", Map.of("player", name, "reviver", reviver)));
    }

    private void shield(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) return;
        if (args.length >= 1 && args[0].equalsIgnoreCase("off")) {
            plugin.store().setShieldOff(p.getUniqueId());
            say(sender, "Newbie protection disabled. You can fight now, and be fought.", NamedTextColor.YELLOW);
            return;
        }
        int minutes = plugin.getConfig().getInt("newbie-shield-minutes", 30);
        long left = minutes * 60_000L - plugin.store().playedMs(p.getUniqueId());
        if (plugin.store().shieldOff(p.getUniqueId()) || left <= 0) {
            say(sender, "You have no newbie protection.", NamedTextColor.GRAY);
        } else {
            say(sender, "Newbie protection: " + (left / 60_000L + 1) + " min of playtime left. /shield off to disable.", NamedTextColor.GREEN);
        }
    }

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lifesteal.admin")) {
            say(sender, "You do not have permission.", NamedTextColor.RED);
            return;
        }
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                plugin.reloadConfig();
                plugin.items().registerRecipes();
                say(sender, "Reloaded.", NamedTextColor.GREEN);
            }
            case "set" -> {
                if (args.length < 3) { say(sender, "/lifesteal set <player> <hearts>", NamedTextColor.RED); return; }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { say(sender, "Player must be online.", NamedTextColor.RED); return; }
                try {
                    plugin.setHearts(t, Integer.parseInt(args[2]));
                } catch (NumberFormatException ex) {
                    say(sender, "Not a number.", NamedTextColor.RED);
                    return;
                }
                say(sender, t.getName() + " now has " + plugin.hearts(t) + " hearts.", NamedTextColor.GREEN);
            }
            case "give" -> {
                if (args.length < 3) { say(sender, "/lifesteal give <heart|revival> <player> [amount]", NamedTextColor.RED); return; }
                Player t = Bukkit.getPlayerExact(args[2]);
                if (t == null) { say(sender, "Player must be online.", NamedTextColor.RED); return; }
                int n = 1;
                if (args.length >= 4) {
                    try {
                        n = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
                    } catch (NumberFormatException ignored) {
                        n = 1;
                    }
                }
                if (args[1].equalsIgnoreCase("heart")) plugin.giveOrDrop(t, plugin.items().heart(n));
                else plugin.giveOrDrop(t, plugin.items().revival());
                say(sender, "Given.", NamedTextColor.GREEN);
            }
            case "eliminate" -> {
                if (args.length < 2) { say(sender, "/lifesteal eliminate <player>", NamedTextColor.RED); return; }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) { say(sender, "Player must be online.", NamedTextColor.RED); return; }
                plugin.store().eliminate(t.getUniqueId(), t.getName());
                t.kick(plugin.msg("eliminated", Map.of()));
                say(sender, t.getName() + " eliminated.", NamedTextColor.YELLOW);
            }
            case "revive" -> {
                if (args.length < 2) { say(sender, "/lifesteal revive <name>", NamedTextColor.RED); return; }
                UUID id = plugin.store().uncheckedFindEliminated(args[1]);
                if (id == null) { say(sender, "No eliminated player with that name.", NamedTextColor.RED); return; }
                doRevive(id, sender.getName());
            }
            default -> say(sender, "/lifesteal <reload|set|give|eliminate|revive>", NamedTextColor.GRAY);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("hearts") && args.length == 1) {
            out.add("top");
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (name.equals("revive") && args.length == 1) {
            out.addAll(plugin.store().eliminatedNames());
        } else if (name.equals("shield") && args.length == 1) {
            out.add("off");
        } else if (name.equals("lifesteal") && sender.hasPermission("lifesteal.admin")) {
            if (args.length == 1) out.addAll(List.of("reload", "set", "give", "eliminate", "revive"));
            else if (args.length == 2 && args[0].equalsIgnoreCase("give")) out.addAll(List.of("heart", "revival"));
            else if (args.length == 2 && args[0].equalsIgnoreCase("revive")) out.addAll(plugin.store().eliminatedNames());
            else if (args.length >= 2) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String prefix = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(prefix));
        return out;
    }
}
