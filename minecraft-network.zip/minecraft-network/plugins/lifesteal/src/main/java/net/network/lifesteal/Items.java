package net.network.lifesteal;

import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/** Heart and Revival Compass items plus their crafting recipes. */
public final class Items {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final LifestealPlugin plugin;
    private final NamespacedKey heartKey, revivalKey;

    public Items(LifestealPlugin plugin) {
        this.plugin = plugin;
        this.heartKey = new NamespacedKey(plugin, "heart");
        this.revivalKey = new NamespacedKey(plugin, "revival");
    }

    public ItemStack heart(int amount) {
        ItemStack it = new ItemStack(Material.NETHER_STAR, amount);
        ItemMeta m = it.getItemMeta();
        m.displayName(MM.deserialize("<red><bold>Heart").decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                MM.deserialize("<gray>Right-click to gain a heart.").decoration(TextDecoration.ITALIC, false),
                MM.deserialize("<dark_gray>Stolen life, bottled.").decoration(TextDecoration.ITALIC, false)));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(heartKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public ItemStack revival() {
        ItemStack it = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta m = it.getItemMeta();
        m.displayName(MM.deserialize("<green><bold>Revival Compass").decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                MM.deserialize("<gray>Hold it and use <white>/revive <name>").decoration(TextDecoration.ITALIC, false),
                MM.deserialize("<gray>to bring back an eliminated player.").decoration(TextDecoration.ITALIC, false)));
        m.setEnchantmentGlintOverride(true);
        m.getPersistentDataContainer().set(revivalKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    public boolean isHeart(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(heartKey, PersistentDataType.BYTE);
    }

    public boolean isRevival(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(revivalKey, PersistentDataType.BYTE);
    }

    public void registerRecipes() {
        add("heart", new NamespacedKey(plugin, "heart_recipe"), heart(1));
        add("revival", new NamespacedKey(plugin, "revival_recipe"), revival());
    }

    public void unregisterRecipes() {
        Bukkit.removeRecipe(new NamespacedKey(plugin, "heart_recipe"));
        Bukkit.removeRecipe(new NamespacedKey(plugin, "revival_recipe"));
    }

    private void add(String name, NamespacedKey key, ItemStack result) {
        Bukkit.removeRecipe(key);
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("recipes." + name);
        if (sec == null || !sec.getBoolean("enabled", true)) return;
        try {
            ShapedRecipe r = new ShapedRecipe(key, result);
            List<String> shape = sec.getStringList("shape");
            r.shape(shape.toArray(new String[0]));
            ConfigurationSection ing = sec.getConfigurationSection("ingredients");
            if (ing == null) return;
            for (String k : ing.getKeys(false)) {
                String v = ing.getString(k, "");
                if (v.equalsIgnoreCase("HEART")) {
                    r.setIngredient(k.charAt(0), new RecipeChoice.ExactChoice(heart(1)));
                } else {
                    Material mat = Material.matchMaterial(v);
                    if (mat == null) throw new IllegalArgumentException("unknown material " + v);
                    r.setIngredient(k.charAt(0), mat);
                }
            }
            Bukkit.addRecipe(r);
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Could not register the " + name + " recipe: " + ex.getMessage());
        }
    }
}
