package net.network.lifesteal;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Hearts, names, playtime, shield opt-out and eliminated players. Saved to data.yml. */
public final class DataStore {

    private final LifestealPlugin plugin;
    private final File file;
    private final Map<UUID, Integer> hearts = new ConcurrentHashMap<>();
    private final Map<UUID, String> names = new ConcurrentHashMap<>();
    private final Map<UUID, Long> playedMs = new ConcurrentHashMap<>();
    private final Map<UUID, Long> sessionStart = new ConcurrentHashMap<>();
    private final Set<UUID> shieldOff = ConcurrentHashMap.newKeySet();
    private final Map<UUID, String> eliminated = new ConcurrentHashMap<>();
    private volatile boolean dirty;

    public DataStore(LifestealPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection ps = yml.getConfigurationSection("players");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    ConfigurationSection s = ps.getConfigurationSection(k);
                    hearts.put(id, s.getInt("hearts", plugin.getConfig().getInt("start-hearts", 10)));
                    names.put(id, s.getString("name", "?"));
                    playedMs.put(id, s.getLong("played-ms", 0));
                    if (s.getBoolean("shield-off")) shieldOff.add(id);
                } catch (IllegalArgumentException ignored) {
                    // bad uuid key
                }
            }
        }
        ConfigurationSection es = yml.getConfigurationSection("eliminated");
        if (es != null) {
            for (String k : es.getKeys(false)) {
                try {
                    eliminated.put(UUID.fromString(k), es.getString(k, "?"));
                } catch (IllegalArgumentException ignored) {
                    // bad uuid key
                }
            }
        }
    }

    public synchronized void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Integer> e : hearts.entrySet()) {
            String p = "players." + e.getKey() + ".";
            yml.set(p + "hearts", e.getValue());
            yml.set(p + "name", names.getOrDefault(e.getKey(), "?"));
            yml.set(p + "played-ms", playedMs(e.getKey()));
            if (shieldOff.contains(e.getKey())) yml.set(p + "shield-off", true);
        }
        for (Map.Entry<UUID, String> e : eliminated.entrySet()) yml.set("eliminated." + e.getKey(), e.getValue());
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
            dirty = false;
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    // ------------------------------------------------------------------ hearts

    public int hearts(UUID id) {
        return hearts.getOrDefault(id, plugin.getConfig().getInt("start-hearts", 10));
    }

    public boolean known(UUID id) {
        return hearts.containsKey(id);
    }

    public void setHearts(UUID id, String name, int value) {
        hearts.put(id, value);
        names.put(id, name);
        dirty = true;
    }

    public String name(UUID id) {
        return names.getOrDefault(id, "?");
    }

    /** Players sorted by hearts, highest first (eliminated players are excluded). */
    public List<UUID> top(int limit) {
        List<UUID> ids = new ArrayList<>(hearts.keySet());
        ids.removeIf(eliminated::containsKey);
        ids.sort((a, b) -> Integer.compare(hearts(b), hearts(a)));
        return ids.size() > limit ? ids.subList(0, limit) : ids;
    }

    // ------------------------------------------------------------------ elimination

    public boolean isEliminated(UUID id) {
        return eliminated.containsKey(id);
    }

    public void eliminate(UUID id, String name) {
        eliminated.put(id, name);
        names.put(id, name);
        hearts.put(id, 0);
        dirty = true;
    }

    public UUID uncheckedFindEliminated(String name) {
        for (Map.Entry<UUID, String> e : eliminated.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    public List<String> eliminatedNames() {
        return new ArrayList<>(eliminated.values());
    }

    public void revive(UUID id, int hearts) {
        eliminated.remove(id);
        this.hearts.put(id, hearts);
        dirty = true;
    }

    // ------------------------------------------------------------------ shield / playtime

    public boolean shieldOff(UUID id) {
        return shieldOff.contains(id);
    }

    public void setShieldOff(UUID id) {
        shieldOff.add(id);
        dirty = true;
    }

    public void sessionStart(UUID id) {
        sessionStart.put(id, System.currentTimeMillis());
    }

    public void sessionEnd(UUID id) {
        Long start = sessionStart.remove(id);
        if (start != null) {
            playedMs.merge(id, System.currentTimeMillis() - start, Long::sum);
            dirty = true;
        }
    }

    public long playedMs(UUID id) {
        long base = playedMs.getOrDefault(id, 0L);
        Long start = sessionStart.get(id);
        return start == null ? base : base + (System.currentTimeMillis() - start);
    }
}
