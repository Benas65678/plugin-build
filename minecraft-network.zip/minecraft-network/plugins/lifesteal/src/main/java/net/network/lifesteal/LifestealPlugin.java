package net.network.lifesteal;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;

public final class LifestealPlugin extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final String CHANNEL = "BungeeCord";

    private DataStore store;
    private Items items;
    private Attribute maxHealth;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxHealth = resolveMaxHealth();
        store = new DataStore(this);
        store.load();
        items = new Items(this);
        items.registerRecipes();

        getServer().getMessenger().registerOutgoingPluginChannel(this, CHANNEL);
        LifestealListener listener = new LifestealListener(this);
        getServer().getPluginManager().registerEvents(listener, this);

        LifestealCommands cmds = new LifestealCommands(this);
        for (String name : new String[]{"hearts", "withdraw", "revive", "shield", "lifesteal"}) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        Bukkit.getScheduler().runTaskTimer(this, store::saveIfDirty, 1200L, 1200L);
        long leader = getConfig().getLong("leader-announce-minutes", 30);
        if (leader > 0) {
            Bukkit.getScheduler().runTaskTimer(this, this::announceLeader, leader * 1200L, leader * 1200L);
        }
        // players already online after a /reload
        for (Player p : Bukkit.getOnlinePlayers()) {
            store.sessionStart(p.getUniqueId());
            ensurePlayer(p);
        }
    }

    @Override
    public void onDisable() {
        if (store != null) {
            for (Player p : Bukkit.getOnlinePlayers()) store.sessionEnd(p.getUniqueId());
            store.save();
        }
        if (items != null) items.unregisterRecipes();
    }

    public DataStore store() { return store; }
    public Items items() { return items; }

    /** MAX_HEALTH was renamed between versions; try both keys. */
    private static Attribute resolveMaxHealth() {
        Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("max_health"));
        if (a == null) a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("generic.max_health"));
        return a;
    }

    public void ensurePlayer(Player p) {
        UUID id = p.getUniqueId();
        if (!store.known(id)) store.setHearts(id, p.getName(), getConfig().getInt("start-hearts", 10));
        applyHearts(p);
    }

    public int hearts(Player p) {
        return store.hearts(p.getUniqueId());
    }

    public void setHearts(Player p, int value) {
        int max = getConfig().getInt("max-hearts", 20);
        store.setHearts(p.getUniqueId(), p.getName(), Math.max(0, Math.min(max, value)));
        applyHearts(p);
    }

    public void applyHearts(Player p) {
        AttributeInstance inst = maxHealth == null ? null : p.getAttribute(maxHealth);
        if (inst == null) return;
        double max = Math.max(2.0, store.hearts(p.getUniqueId()) * 2.0);
        inst.setBaseValue(max);
        if (p.getHealth() > max) p.setHealth(max);
    }

    public Component msg(String key, Map<String, String> placeholders) {
        String s = getConfig().getString("messages." + key, key);
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
            s = s.replace("{" + e.getKey() + "}", e.getValue());
        }
        return MM.deserialize(getConfig().getString("messages.prefix", "") + s);
    }

    public void giveOrDrop(Player p, ItemStack it) {
        for (ItemStack rest : p.getInventory().addItem(it).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }

    public void sendToHub(Player p) {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("Connect");
        out.writeUTF(getConfig().getString("hub-server", "hub"));
        p.sendPluginMessage(this, CHANNEL, out.toByteArray());
    }

    private void announceLeader() {
        var top = store.top(1);
        if (top.isEmpty()) return;
        UUID id = top.get(0);
        Bukkit.broadcast(MM.deserialize(getConfig().getString("messages.prefix", "")
                + "<gray>Most hearts: <white>" + store.name(id) + "</white> <red>" + store.hearts(id) + " ❤"));
    }
}
