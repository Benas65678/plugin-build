package net.network.minigames;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;

import net.network.minigames.games.LavaGame;
import net.network.minigames.games.SpleefGame;
import net.network.minigames.games.SumoGame;
import net.network.minigames.games.TntRunGame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Owns the arena world, the 16 arena slots and every running game. */
public final class GameManager {

    private static final int SLOTS = 16;
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final MinigamesPlugin plugin;
    private final List<Game> games = new ArrayList<>();
    private final Map<UUID, Game> byPlayer = new HashMap<>();
    private final boolean[] used = new boolean[SLOTS];
    private World arena;

    public GameManager(MinigamesPlugin plugin) {
        this.plugin = plugin;
    }

    public World arenaWorld() {
        if (arena != null) return arena;
        String name = plugin.getConfig().getString("arena-world", "mg_arenas");
        World w = Bukkit.getWorld(name);
        if (w == null) {
            WorldCreator wc = new WorldCreator(name);
            wc.generator(new VoidGenerator());
            w = wc.createWorld();
        }
        if (w == null) throw new IllegalStateException("Could not create the arena world " + name);
        rule(w, "doDaylightCycle", false);
        rule(w, "doWeatherCycle", false);
        rule(w, "doMobSpawning", false);
        rule(w, "announceAdvancements", false);
        w.setTime(6000);
        w.setStorm(false);
        arena = w;
        return w;
    }

    @SuppressWarnings("unchecked")
    private static void rule(World w, String name, Object value) {
        try {
            GameRule<Object> gr = (GameRule<Object>) GameRule.getByName(name);
            if (gr != null) w.setGameRule(gr, value);
        } catch (RuntimeException ignored) {
            // game rule renamed in this version
        }
    }

    public Game gameOf(UUID id) {
        return byPlayer.get(id);
    }

    public List<Game> all() {
        return new ArrayList<>(games);
    }

    public void unregister(UUID id) {
        byPlayer.remove(id);
    }

    public void remove(Game g) {
        games.remove(g);
    }

    public void release(int slot) {
        used[slot] = false;
    }

    private int freeSlot() {
        for (int i = 0; i < SLOTS; i++) {
            if (!used[i]) return i;
        }
        return -1;
    }

    /** Puts the player in an open game of that type, creating one when needed. */
    public boolean join(Player p, GameType type) {
        if (byPlayer.containsKey(p.getUniqueId())) {
            p.sendMessage(MM.deserialize("<red>You are already in a game. Use /mg leave first."));
            return false;
        }
        Game target = null;
        for (Game g : games) {
            if (g.type == type && g.open() && (target == null || g.playerCount() > target.playerCount())) target = g;
        }
        if (target == null) {
            int max = plugin.getConfig().getInt("max-games", 12);
            int slot = freeSlot();
            if (games.size() >= max || slot < 0) {
                p.sendMessage(MM.deserialize("<red>All arenas are busy right now. Try again in a minute."));
                return false;
            }
            used[slot] = true;
            Location origin = new Location(arenaWorld(), (slot % 4) * 300, 100, (slot / 4) * 300);
            target = create(type, slot, origin);
            games.add(target);
            target.init();
        }
        if (!target.join(p)) {
            p.sendMessage(MM.deserialize("<red>That game just started. Try again."));
            return false;
        }
        byPlayer.put(p.getUniqueId(), target);
        return true;
    }

    private Game create(GameType type, int slot, Location origin) {
        return switch (type) {
            case TNT_RUN -> new TntRunGame(plugin, slot, origin);
            case SPLEEF -> new SpleefGame(plugin, slot, origin);
            case SUMO -> new SumoGame(plugin, slot, origin);
            case LAVA -> new LavaGame(plugin, slot, origin);
        };
    }

    public void shutdown() {
        for (Game g : new ArrayList<>(games)) g.destroy();
    }
}
