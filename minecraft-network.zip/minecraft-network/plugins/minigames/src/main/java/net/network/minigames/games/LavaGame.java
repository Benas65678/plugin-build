package net.network.minigames.games;

import net.network.minigames.Game;
import net.network.minigames.GameType;
import net.network.minigames.MinigamesPlugin;
import net.network.minigames.Util;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Random;

/** Random terrain inside a barrier box. Lava rises one block at a time. Last one alive wins. */
public final class LavaGame extends Game {

    private static final int W = 19;            // half width of the arena box
    private static final int HEIGHT = 50;
    private static final int START_LAVA = 2;    // lava level relative to oy at the start
    private static final int MAX_LAVA = 44;

    private final int[][] heights = new int[2 * W + 1][2 * W + 1];
    private int lavaY;

    public LavaGame(MinigamesPlugin plugin, int slot, Location origin) {
        super(plugin, GameType.LAVA, slot, origin);
    }

    private int ox() { return origin.getBlockX(); }
    private int oy() { return origin.getBlockY(); }
    private int oz() { return origin.getBlockZ(); }

    @Override
    protected void buildArena() {
        Random rnd = new Random(System.nanoTime());
        double phaseX = rnd.nextDouble() * 6, phaseZ = rnd.nextDouble() * 6;
        for (int dx = -W + 1; dx <= W - 1; dx++) {
            for (int dz = -W + 1; dz <= W - 1; dz++) {
                int h = 4 + (int) (Math.abs(Math.sin(dx * 0.22 + phaseX) * Math.cos(dz * 0.18 + phaseZ)) * 9) + rnd.nextInt(3);
                if (rnd.nextInt(55) == 0) h += 10 + rnd.nextInt(9);          // towers
                heights[dx + W][dz + W] = h;
                for (int y = 0; y <= h; y++) {
                    Material m = y == h ? Material.GRASS_BLOCK : (y >= h - 2 ? Material.DIRT : Material.STONE);
                    Util.set(world, ox() + dx, oy() + y, oz() + dz, m);
                }
            }
        }
        // floating wooden platforms
        for (int i = 0; i < 14; i++) {
            int cx = rnd.nextInt(2 * W - 7) - W + 4;
            int cz = rnd.nextInt(2 * W - 7) - W + 4;
            int cy = oy() + 14 + rnd.nextInt(24);
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
                Util.set(world, ox() + cx + dx, cy, oz() + cz + dz, Material.OAK_PLANKS);
            }
        }
        // invisible walls so lava and players stay inside
        for (int y = oy() - 6; y <= oy() + HEIGHT; y++) {
            for (int d = -W; d <= W; d++) {
                Util.set(world, ox() + d, y, oz() - W, Material.BARRIER);
                Util.set(world, ox() + d, y, oz() + W, Material.BARRIER);
                Util.set(world, ox() - W, y, oz() + d, Material.BARRIER);
                Util.set(world, ox() + W, y, oz() + d, Material.BARRIER);
            }
        }
        // waiting platform
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) {
            Util.set(world, ox() + dx, oy() + 28 - 1, oz() + dz, Material.WHITE_STAINED_GLASS);
        }
        lavaY = oy() + START_LAVA;
    }

    @Override
    protected Location waitingSpawn() {
        return new Location(world, ox() + 0.5, oy() + 28, oz() + 0.5);
    }

    @Override
    protected Location spawnFor(int index, int total) {
        double a = 2 * Math.PI * index / Math.max(1, total);
        int dx = (int) Math.round(Math.cos(a) * 12);
        int dz = (int) Math.round(Math.sin(a) * 12);
        int h = heights[dx + W][dz + W];
        Location l = new Location(world, ox() + dx + 0.5, oy() + h + 1, oz() + dz + 0.5);
        l.setDirection(waitingSpawn().toVector().subtract(l.toVector()).setY(0));
        return l;
    }

    @Override
    protected GameMode playMode() {
        return GameMode.SURVIVAL;
    }

    @Override
    protected void giveKit(Player p) {
        p.getInventory().addItem(new ItemStack(Material.COBBLESTONE, 64), new ItemStack(Material.COBBLESTONE, 64));
    }

    @Override
    public boolean allowBreak(Block b) {
        return b.getType() != Material.BARRIER && b.getType() != Material.LAVA;
    }

    @Override
    public boolean allowPlace(Block b) {
        return b.getY() < oy() + HEIGHT && Math.abs(b.getX() - ox()) < W && Math.abs(b.getZ() - oz()) < W;
    }

    @Override
    protected void onStart() {
        lavaY = oy() + START_LAVA;
        broadcast("<red>The lava will start rising soon. Climb!");
    }

    @Override
    protected void onTick(int ticks) {
        int every = Math.max(3, plugin.getConfig().getInt("games.lava.rise-seconds", 10)) * 20;
        if (ticks % every != 0 || lavaY >= oy() + MAX_LAVA) return;
        lavaY++;
        for (int dx = -W + 1; dx <= W - 1; dx++) {
            for (int dz = -W + 1; dz <= W - 1; dz++) {
                Block b = world.getBlockAt(ox() + dx, lavaY, oz() + dz);
                if (b.getType().isAir()) b.setType(Material.LAVA, false);
            }
        }
    }

    @Override
    protected boolean outOfPlay(Player p) {
        Location l = p.getLocation();
        if (l.getY() < oy() - 5) return true;
        return l.getBlock().getType() == Material.LAVA || p.getEyeLocation().getBlock().getType() == Material.LAVA;
    }

    @Override
    protected String outReason() {
        return "burned in the lava";
    }

    @Override
    protected String runningBarText() {
        return "Rising Lava - alive: " + alive.size() + " | lava at height " + Math.max(0, lavaY - oy());
    }

    @Override
    protected void clearArena(Runnable done) {
        Util.fillLayered(plugin, world, ox() - W - 1, oy() - 7, oz() - W - 1, ox() + W + 1, oy() + HEIGHT + 2,
                oz() + W + 1, Material.AIR, 4, done);
    }

    @Override
    protected int configMin() { return plugin.getConfig().getInt("games.lava.min", 2); }

    @Override
    protected int configMax() { return plugin.getConfig().getInt("games.lava.max", 16); }

    @Override
    protected int configCountdown() { return plugin.getConfig().getInt("games.lava.countdown", 25); }
}
