package net.network.minigames;

import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

/** Block helpers. Big clears are spread over several ticks so the server never stalls. */
public final class Util {

    private Util() {
    }

    public static void set(World w, int x, int y, int z, Material m) {
        w.getBlockAt(x, y, z).setType(m, false);
    }

    /** Fills a box one horizontal layer at a time, {@code layersPerTick} layers each tick. */
    public static void fillLayered(Plugin plugin, World w, int x1, int y1, int z1, int x2, int y2, int z2,
                                   Material m, int layersPerTick, Runnable done) {
        new BukkitRunnable() {
            int y = y1;

            @Override
            public void run() {
                for (int i = 0; i < layersPerTick && y <= y2; i++, y++) {
                    for (int x = x1; x <= x2; x++) {
                        for (int z = z1; z <= z2; z++) {
                            w.getBlockAt(x, y, z).setType(m, false);
                        }
                    }
                }
                if (y > y2) {
                    cancel();
                    if (done != null) done.run();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
