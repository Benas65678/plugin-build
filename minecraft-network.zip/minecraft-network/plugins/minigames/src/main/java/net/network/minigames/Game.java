package net.network.minigames;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * One round of one minigame in one arena slot.
 * Lifecycle: WAITING (players gather) -> COUNTDOWN -> RUNNING -> ENDING -> arena cleared.
 */
public abstract class Game {

    public enum State { WAITING, COUNTDOWN, RUNNING, ENDING }

    protected static final MiniMessage MM = MiniMessage.miniMessage();

    protected final MinigamesPlugin plugin;
    public final GameType type;
    public final int slot;
    protected final World world;
    protected final Location origin;
    protected final Set<UUID> players = new LinkedHashSet<>();
    protected final Set<UUID> alive = new LinkedHashSet<>();
    private final Map<UUID, Snapshot> snapshots = new HashMap<>();
    private final BossBar bar = BossBar.bossBar(Component.text(" "), 1f, BossBar.Color.BLUE, BossBar.Overlay.PROGRESS);

    private State state = State.WAITING;
    private int countdown;
    private int tickCounter;
    protected int runTicks;
    private int endTicks;
    private BukkitTask loop;
    private boolean destroyed;

    protected Game(MinigamesPlugin plugin, GameType type, int slot, Location origin) {
        this.plugin = plugin;
        this.type = type;
        this.slot = slot;
        this.origin = origin;
        this.world = origin.getWorld();
    }

    // ------------------------------------------------------------------ to implement

    protected abstract void buildArena();

    protected abstract Location waitingSpawn();

    protected abstract Location spawnFor(int index, int total);

    protected abstract void onStart();

    protected abstract void onTick(int ticks);

    protected abstract boolean outOfPlay(Player p);

    protected abstract void clearArena(Runnable done);

    protected abstract int configMin();

    protected abstract int configMax();

    protected abstract int configCountdown();

    // ------------------------------------------------------------------ overridable rules

    protected GameMode playMode() {
        return GameMode.ADVENTURE;
    }

    protected void giveKit(Player p) {
    }

    public boolean allowBreak(Block b) {
        return false;
    }

    public boolean allowPlace(Block b) {
        return false;
    }

    /** PvP while running. Default: no damage at all. Sumo lets the hit through with 0 damage. */
    public void onPvp(EntityDamageByEntityEvent e) {
        e.setCancelled(true);
    }

    protected String outReason() {
        return "fell out";
    }

    protected String runningBarText() {
        return type.display + " - alive: " + alive.size();
    }

    protected Location spectatorSpawn() {
        return waitingSpawn().clone().add(0, 6, 0);
    }

    // ------------------------------------------------------------------ queries

    public State state() {
        return state;
    }

    public int playerCount() {
        return players.size();
    }

    public int min() {
        return Math.max(2, configMin());
    }

    public int max() {
        return Math.max(min(), configMax());
    }

    public boolean open() {
        return !destroyed && (state == State.WAITING || state == State.COUNTDOWN) && players.size() < max();
    }

    public boolean contains(UUID id) {
        return players.contains(id);
    }

    public boolean isAlive(UUID id) {
        return alive.contains(id);
    }

    // ------------------------------------------------------------------ lifecycle

    public void init() {
        buildArena();
        loop = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
        updateBar();
    }

    public boolean join(Player p) {
        if (!open()) return false;
        UUID id = p.getUniqueId();
        snapshots.put(id, Snapshot.capture(p));
        players.add(id);
        reset(p, GameMode.ADVENTURE);
        p.teleport(waitingSpawn());
        p.showBossBar(bar);
        p.showTitle(Title.title(MM.deserialize("<aqua><bold>" + type.display), MM.deserialize("<gray>" + type.blurb),
                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(400))));
        broadcast("<yellow>" + p.getName() + "</yellow> <gray>joined (" + players.size() + "/" + max() + ")");
        if (state == State.WAITING && players.size() >= min()) startCountdown();
        else if (state == State.COUNTDOWN && players.size() >= max()) countdown = Math.min(countdown, 5);
        updateBar();
        return true;
    }

    public void leave(Player p) {
        UUID id = p.getUniqueId();
        if (!players.remove(id)) return;
        boolean wasAlive = alive.remove(id);
        p.hideBossBar(bar);
        Snapshot s = snapshots.remove(id);
        if (s != null) s.restore(p);
        plugin.games().unregister(id);
        p.teleport(plugin.lobby());
        if (state == State.COUNTDOWN && players.size() < min()) {
            state = State.WAITING;
            broadcast("<red>Not enough players. Countdown cancelled.");
        }
        if (state == State.RUNNING) {
            broadcast("<yellow>" + p.getName() + "</yellow> <gray>left the game.");
            if (wasAlive) checkEnd();
        }
        if (players.isEmpty() && state != State.ENDING) destroy();
        updateBar();
    }

    private void startCountdown() {
        state = State.COUNTDOWN;
        countdown = Math.max(5, configCountdown());
        tickCounter = 0;
    }

    private void countdownStep() {
        countdown--;
        if (countdown <= 0) {
            start();
            return;
        }
        if (countdown <= 5) {
            for (Player p : online()) {
                p.showTitle(Title.title(MM.deserialize("<yellow><bold>" + countdown), Component.empty(),
                        Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ZERO)));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
            }
        }
        updateBar();
    }

    private void start() {
        state = State.RUNNING;
        runTicks = 0;
        alive.clear();
        alive.addAll(players);
        List<Player> list = online();
        int i = 0;
        for (Player p : list) {
            reset(p, playMode());
            p.teleport(spawnFor(i++, list.size()));
            giveKit(p);
            plugin.stats().addPlay(p.getUniqueId(), p.getName(), type);
            p.showTitle(Title.title(MM.deserialize("<green><bold>GO!"), MM.deserialize("<gray>" + type.blurb),
                    Title.Times.times(Duration.ZERO, Duration.ofSeconds(2), Duration.ofMillis(400))));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5f, 1.4f);
        }
        bar.color(BossBar.Color.GREEN);
        onStart();
        updateBar();
    }

    protected void eliminate(Player p) {
        if (!alive.remove(p.getUniqueId())) return;
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(spectatorSpawn());
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, 1f, 0.7f);
        broadcast("<red>" + p.getName() + "</red> <gray>" + outReason() + ". <white>" + alive.size() + "</white> left.");
        checkEnd();
    }

    protected void checkEnd() {
        if (state != State.RUNNING || alive.size() > 1) return;
        Player winner = null;
        for (UUID id : alive) winner = Bukkit.getPlayer(id);
        end(winner);
    }

    private void end(Player winner) {
        state = State.ENDING;
        endTicks = 160;
        bar.color(BossBar.Color.YELLOW);
        if (winner != null) {
            broadcast("<gold><bold>" + winner.getName() + " won " + type.display + "!");
            plugin.stats().addWin(winner.getUniqueId(), winner.getName(), type);
            winner.setGameMode(GameMode.ADVENTURE);
            winner.setAllowFlight(true);
            runRewards("rewards.win-commands", winner);
        } else {
            broadcast("<gray>Nobody won this round.");
        }
        for (Player p : online()) {
            runRewards("rewards.play-commands", p);
            p.getInventory().clear();
        }
        plugin.stats().save();
        updateBar();
    }

    private void runRewards(String path, Player p) {
        for (String cmd : plugin.getConfig().getStringList(path)) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    cmd.replace("{player}", p.getName()).replace("{game}", type.id));
        }
    }

    private void finish() {
        for (Player p : online()) leave(p);
        destroy();
    }

    public void destroy() {
        if (destroyed) return;
        destroyed = true;
        if (loop != null) loop.cancel();
        for (Player p : online()) leave(p);
        players.clear();
        plugin.games().remove(this);
        clearArena(() -> plugin.games().release(slot));
    }

    /** Admin: skip the countdown. */
    public boolean forceStart() {
        if (state != State.WAITING && state != State.COUNTDOWN) return false;
        if (players.size() < 2) return false;
        start();
        return true;
    }

    // ------------------------------------------------------------------ tick loop

    private void tick() {
        switch (state) {
            case WAITING -> {
                if (++tickCounter % 20 == 0) updateBar();
            }
            case COUNTDOWN -> {
                if (++tickCounter % 20 == 0) countdownStep();
            }
            case RUNNING -> {
                runTicks++;
                onTick(runTicks);
                if (runTicks % 2 == 0) {
                    for (UUID id : new ArrayList<>(alive)) {
                        Player p = Bukkit.getPlayer(id);
                        if (p == null) {
                            alive.remove(id);
                            continue;
                        }
                        if (outOfPlay(p)) eliminate(p);
                    }
                }
                if (runTicks % 20 == 0) updateBar();
            }
            case ENDING -> {
                endTicks--;
                if (endTicks % 30 == 0) fireworks();
                if (endTicks <= 0) finish();
            }
        }
    }

    private void fireworks() {
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.getWorld().spawn(p.getLocation(), Firework.class, fw -> {
                FireworkMeta m = fw.getFireworkMeta();
                m.addEffect(FireworkEffect.builder().withColor(Color.AQUA, Color.YELLOW)
                        .with(FireworkEffect.Type.BALL_LARGE).build());
                m.setPower(1);
                fw.setFireworkMeta(m);
            });
        }
    }

    // ------------------------------------------------------------------ helpers

    protected List<Player> online() {
        List<Player> out = new ArrayList<>();
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) out.add(p);
        }
        return out;
    }

    protected void broadcast(String mini) {
        Component c = MM.deserialize(plugin.getConfig().getString("messages.prefix", "") + mini);
        for (Player p : online()) p.sendMessage(c);
    }

    private void reset(Player p, GameMode mode) {
        p.getInventory().clear();
        p.setGameMode(mode);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0);
        p.setExp(0f);
        p.setLevel(0);
        p.setAllowFlight(false);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
    }

    private void updateBar() {
        switch (state) {
            case WAITING -> {
                bar.name(MM.deserialize("<aqua>" + type.display + " <gray>- waiting for players <white>"
                        + players.size() + "/" + min()));
                bar.progress(Math.min(1f, players.size() / (float) min()));
                bar.color(BossBar.Color.BLUE);
            }
            case COUNTDOWN -> {
                bar.name(MM.deserialize("<aqua>" + type.display + " <gray>- starting in <white>" + countdown + "s"));
                bar.progress(Math.max(0f, Math.min(1f, countdown / (float) Math.max(5, configCountdown()))));
                bar.color(BossBar.Color.YELLOW);
            }
            case RUNNING -> {
                bar.name(MM.deserialize("<green>" + runningBarText()));
                bar.progress(players.isEmpty() ? 0f : Math.min(1f, alive.size() / (float) players.size()));
            }
            case ENDING -> bar.name(MM.deserialize("<gold>Round over"));
        }
    }
}
