package net.network.minigames;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Rules inside games and the arena world. */
public final class MinigameListener implements Listener {

    private final MinigamesPlugin plugin;

    public MinigameListener(MinigamesPlugin plugin) {
        this.plugin = plugin;
    }

    private Game gameOf(Entity e) {
        return e instanceof Player p ? plugin.games().gameOf(p.getUniqueId()) : null;
    }

    private boolean inArenaWorld(org.bukkit.World w) {
        return w.getName().equals(plugin.getConfig().getString("arena-world", "mg_arenas"));
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Game g = plugin.games().gameOf(e.getPlayer().getUniqueId());
        if (g != null) {
            if (g.state() == Game.State.RUNNING && g.allowBreak(e.getBlock())) {
                e.setCancelled(false);
                e.setDropItems(false);
            } else {
                e.setCancelled(true);
            }
        } else if (inArenaWorld(e.getBlock().getWorld()) && !e.getPlayer().hasPermission("minigames.admin")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlace(BlockPlaceEvent e) {
        Game g = plugin.games().gameOf(e.getPlayer().getUniqueId());
        if (g != null) {
            if (g.state() == Game.State.RUNNING && g.allowPlace(e.getBlock())) e.setCancelled(false);
            else e.setCancelled(true);
        } else if (inArenaWorld(e.getBlock().getWorld()) && !e.getPlayer().hasPermission("minigames.admin")) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        Game g = gameOf(e.getEntity());
        if (g == null) return;
        if (g.state() != Game.State.RUNNING) {
            e.setCancelled(true);
            return;
        }
        if (e instanceof EntityDamageByEntityEvent byEntity) {
            Entity damager = byEntity.getDamager();
            if (damager instanceof Projectile pr && pr.getShooter() instanceof Entity shooter) damager = shooter;
            Game other = gameOf(damager);
            if (other == g) {
                g.onPvp(byEntity);
                return;
            }
        }
        e.setCancelled(true);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (gameOf(e.getEntity()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (plugin.games().gameOf(e.getPlayer().getUniqueId()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (inArenaWorld(e.getLocation().getWorld())
                && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Game g = plugin.games().gameOf(e.getPlayer().getUniqueId());
        if (g != null) g.leave(e.getPlayer());
    }
}
