package net.network.minigames;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Wins and games played per player and game, stored in stats.yml. */
public final class Stats {

    private final MinigamesPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;

    public Stats(MinigamesPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
    }

    public void addPlay(UUID id, String name, GameType t) {
        yml.set("players." + id + ".name", name);
        yml.set("players." + id + ".plays." + t.id, yml.getInt("players." + id + ".plays." + t.id) + 1);
    }

    public void addWin(UUID id, String name, GameType t) {
        yml.set("players." + id + ".name", name);
        yml.set("players." + id + ".wins." + t.id, yml.getInt("players." + id + ".wins." + t.id) + 1);
        save();
    }

    public int wins(UUID id, GameType t) {
        return yml.getInt("players." + id + ".wins." + t.id);
    }

    public int plays(UUID id, GameType t) {
        return yml.getInt("players." + id + ".plays." + t.id);
    }

    public synchronized void save() {
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save stats.yml: " + e.getMessage());
        }
    }
}
