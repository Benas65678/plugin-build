package net.network.minigames;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MgCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final MinigamesPlugin plugin;

    public MgCommand(MinigamesPlugin plugin) {
        this.plugin = plugin;
    }

    private static void say(CommandSender s, String mini) {
        s.sendMessage(MM.deserialize(mini));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "list" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "join" -> {
                if (!(sender instanceof Player p)) return true;
                GameType t = args.length >= 2 ? GameType.byId(args[1]) : null;
                if (t == null) {
                    say(sender, "<red>Usage: /mg join <tntrun|spleef|sumo|lava>");
                    return true;
                }
                plugin.games().join(p, t);
            }
            case "leave" -> {
                if (!(sender instanceof Player p)) return true;
                Game g = plugin.games().gameOf(p.getUniqueId());
                if (g == null) say(sender, "<gray>You are not in a game.");
                else g.leave(p);
            }
            case "list" -> {
                say(sender, "<aqua><bold>Minigames");
                for (GameType t : GameType.values()) {
                    int playing = 0;
                    int rounds = 0;
                    for (Game g : plugin.games().all()) {
                        if (g.type == t) {
                            rounds++;
                            playing += g.playerCount();
                        }
                    }
                    say(sender, "<white>" + t.display + " <dark_gray>- <gray>" + t.blurb + " <yellow>(" + playing
                            + " playing, " + rounds + " rounds)");
                }
                say(sender, "<gray>Join with <white>/mg join <game>");
            }
            case "stats" -> {
                OfflinePlayer target = null;
                if (args.length >= 2) target = Bukkit.getOfflinePlayerIfCached(args[1]);
                else if (sender instanceof Player p) target = p;
                if (target == null) {
                    say(sender, "<red>Unknown player.");
                    return true;
                }
                say(sender, "<aqua><bold>Stats for " + target.getName());
                for (GameType t : GameType.values()) {
                    say(sender, "<white>" + t.display + " <dark_gray>- <gray>wins <yellow>"
                            + plugin.stats().wins(target.getUniqueId(), t) + " <gray>of <yellow>"
                            + plugin.stats().plays(target.getUniqueId(), t));
                }
            }
            case "forcestart" -> {
                if (!sender.hasPermission("minigames.admin")) {
                    say(sender, "<red>You do not have permission.");
                    return true;
                }
                if (!(sender instanceof Player p)) return true;
                Game g = plugin.games().gameOf(p.getUniqueId());
                if (g == null || !g.forceStart()) say(sender, "<red>Join a waiting game with 2+ players first.");
            }
            default -> say(sender, "<gray>/mg <join|leave|list|stats>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(List.of("join", "leave", "list", "stats"));
            if (sender.hasPermission("minigames.admin")) out.add("forcestart");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            for (GameType t : GameType.values()) out.add(t.id);
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.startsWith(prefix));
        return out;
    }
}
