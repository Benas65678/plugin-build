package net.network.minigames.games;

import net.kyori.adventure.text.Component;
import net.network.minigames.Game;
import net.network.minigames.GameType;
import net.network.minigames.MinigamesPlugin;
import net.network.minigames.Util;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** A small round platform that shrinks. Hits do no damage, only knockback. */
public final class SumoGame extends Game {

    private static final int START_R = 7;
    private static final int FLOOR = 10;

    private int radius = START_R;

    public SumoGame(MinigamesPlugin plugin, int slot, Location origin) {
        super(plugin, GameType.SUMO, slot, origin);
    }

    private int ox() { return origin.getBlockX(); }
    private int oy() { return origin.getBlockY(); }
    private int oz() { return origin.getBlockZ(); }

    @Override
    protected void buildArena() {
        for (int dx = -START_R; dx <= START_R; dx++) {
            for (int dz = -START_R; dz <= START_R; dz++) {
                double d = Math.hypot(dx, dz);
                if (d > START_R) continue;
                Material top = d <= 2.5 ? Material.RED_TERRACOTTA : (d <= 5 ? Material.WHITE_TERRACOTTA : Material.ORANGE_TERRACOTTA);
                Util.set(world, ox() + dx, oy() + FLOOR, oz() + dz, top);
                Util.set(world, ox() + dx, oy() + FLOOR - 1, oz() + dz, Material.SMOOTH_STONE);
            }
        }
    }

    @Override
    protected Location waitingSpawn() {
        return new Location(world, ox() + 0.5, oy() + FLOOR + 1, oz() + 0.5);
    }

    @Override
    protected Location spawnFor(int index, int total) {
        double a = 2 * Math.PI * index / Math.max(1, total);
        Location l = new Location(world, ox() + 0.5 + Math.cos(a) * 5, oy() + FLOOR + 1, oz() + 0.5 + Math.sin(a) * 5);
        l.setDirection(waitingSpawn().toVector().subtract(l.toVector()));
        return l;
    }

    @Override
    protected void giveKit(Player p) {
        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta m = stick.getItemMeta();
        Enchantment kb = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("knockback"));
        if (kb != null) m.addEnchant(kb, 2, true);
        m.displayName(Component.text("Shove Stick"));
        stick.setItemMeta(m);
        p.getInventory().setItem(0, stick);
        p.getInventory().setHeldItemSlot(0);
    }

    @Override
    public void onPvp(EntityDamageByEntityEvent e) {
        e.setCancelled(false);
        e.setDamage(0);
    }

    @Override
    protected void onStart() {
        radius = START_R;
    }

    @Override
    protected void onTick(int ticks) {
        int every = Math.max(5, plugin.getConfig().getInt("games.sumo.shrink-seconds", 20)) * 20;
        if (ticks % every != 0 || radius <= 3) return;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double d = Math.hypot(dx, dz);
                if (d > radius - 1 && d <= radius) {
                    Util.set(world, ox() + dx, oy() + FLOOR, oz() + dz, Material.AIR);
                    Util.set(world, ox() + dx, oy() + FLOOR - 1, oz() + dz, Material.AIR);
                }
            }
        }
        radius--;
        broadcast("<yellow>The platform shrinks!");
    }

    @Override
    protected boolean outOfPlay(Player p) {
        return p.getLocation().getY() < oy() + FLOOR - 2;
    }

    @Override
    protected String outReason() {
        return "was knocked off";
    }

    @Override
    protected void clearArena(Runnable done) {
        Util.fillLayered(plugin, world, ox() - START_R - 1, oy() + FLOOR - 2, oz() - START_R - 1,
                ox() + START_R + 1, oy() + FLOOR + 2, oz() + START_R + 1, Material.AIR, 5, done);
    }

    @Override
    protected int configMin() { return plugin.getConfig().getInt("games.sumo.min", 2); }

    @Override
    protected int configMax() { return plugin.getConfig().getInt("games.sumo.max", 12); }

    @Override
    protected int configCountdown() { return plugin.getConfig().getInt("games.sumo.countdown", 20); }
}
