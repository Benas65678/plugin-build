package net.network.minigames.games;

import net.kyori.adventure.text.Component;
import net.network.minigames.Game;
import net.network.minigames.GameType;
import net.network.minigames.MinigamesPlugin;
import net.network.minigames.Util;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** One big snow floor over the void and a shovel that digs instantly. */
public final class SpleefGame extends Game {

    private static final int R = 13;
    private static final int FLOOR = 10;

    public SpleefGame(MinigamesPlugin plugin, int slot, Location origin) {
        super(plugin, GameType.SPLEEF, slot, origin);
    }

    private int ox() { return origin.getBlockX(); }
    private int oy() { return origin.getBlockY(); }
    private int oz() { return origin.getBlockZ(); }

    @Override
    protected void buildArena() {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if (Math.hypot(dx, dz) > R) continue;
                Util.set(world, ox() + dx, oy() + FLOOR - 1, oz() + dz, Material.SNOW_BLOCK);
                Util.set(world, ox() + dx, oy() + FLOOR, oz() + dz, Material.SNOW_BLOCK);
            }
        }
    }

    @Override
    protected Location waitingSpawn() {
        return new Location(world, ox() + 0.5, oy() + FLOOR + 1, oz() + 0.5);
    }

    @Override
    protected Location spawnFor(int index, int total) {
        double a = 2 * Math.PI * index / Math.max(1, total);
        Location l = new Location(world, ox() + 0.5 + Math.cos(a) * 10, oy() + FLOOR + 1, oz() + 0.5 + Math.sin(a) * 10);
        l.setDirection(waitingSpawn().toVector().subtract(l.toVector()));
        return l;
    }

    @Override
    protected GameMode playMode() {
        return GameMode.SURVIVAL;
    }

    @Override
    protected void giveKit(Player p) {
        ItemStack shovel = new ItemStack(Material.DIAMOND_SHOVEL);
        ItemMeta m = shovel.getItemMeta();
        Enchantment eff = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("efficiency"));
        if (eff != null) m.addEnchant(eff, 5, true);
        m.setUnbreakable(true);
        m.displayName(Component.text("Spleef Shovel"));
        shovel.setItemMeta(m);
        p.getInventory().setItem(0, shovel);
        p.getInventory().setHeldItemSlot(0);
    }

    @Override
    public boolean allowBreak(Block b) {
        return b.getType() == Material.SNOW_BLOCK;
    }

    @Override
    protected void onStart() {
    }

    @Override
    protected void onTick(int ticks) {
    }

    @Override
    protected boolean outOfPlay(Player p) {
        return p.getLocation().getY() < oy() + FLOOR - 4;
    }

    @Override
    protected String outReason() {
        return "fell through the floor";
    }

    @Override
    protected void clearArena(Runnable done) {
        Util.fillLayered(plugin, world, ox() - R - 1, oy() + FLOOR - 2, oz() - R - 1, ox() + R + 1, oy() + FLOOR + 2,
                oz() + R + 1, Material.AIR, 5, done);
    }

    @Override
    protected int configMin() { return plugin.getConfig().getInt("games.spleef.min", 2); }

    @Override
    protected int configMax() { return plugin.getConfig().getInt("games.spleef.max", 16); }

    @Override
    protected int configCountdown() { return plugin.getConfig().getInt("games.spleef.countdown", 20); }
}
