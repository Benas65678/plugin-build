package net.network.minigames;

import java.util.Locale;

public enum GameType {
    TNT_RUN("tntrun", "TNT Run", "Keep running. The floor falls away under your feet."),
    SPLEEF("spleef", "Spleef", "Dig the snow out from under everyone else."),
    SUMO("sumo", "Sumo", "Knock everyone off the shrinking platform."),
    LAVA("lava", "Rising Lava", "Climb. The lava is coming.");

    public final String id;
    public final String display;
    public final String blurb;

    GameType(String id, String display, String blurb) {
        this.id = id;
        this.display = display;
        this.blurb = blurb;
    }

    public static GameType byId(String s) {
        if (s == null) return null;
        String k = s.toLowerCase(Locale.ROOT).replace("_", "").replace("-", "");
        for (GameType t : values()) {
            if (t.id.equals(k)) return t;
        }
        return null;
    }
}
