package net.network.minigames;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

/** The player's state before joining a game, restored afterwards (so the hub compass comes back). */
public final class Snapshot {

    private final ItemStack[] contents;
    private final GameMode mode;
    private final double health;
    private final int food;
    private final float exp;
    private final int level;

    private Snapshot(ItemStack[] contents, GameMode mode, double health, int food, float exp, int level) {
        this.contents = contents;
        this.mode = mode;
        this.health = health;
        this.food = food;
        this.exp = exp;
        this.level = level;
    }

    public static Snapshot capture(Player p) {
        ItemStack[] copy = p.getInventory().getContents().clone();
        for (int i = 0; i < copy.length; i++) {
            if (copy[i] != null) copy[i] = copy[i].clone();
        }
        return new Snapshot(copy, p.getGameMode(), p.getHealth(), p.getFoodLevel(), p.getExp(), p.getLevel());
    }

    public void restore(Player p) {
        p.getInventory().clear();
        p.getInventory().setContents(contents);
        p.setGameMode(mode);
        p.setHealth(Math.min(health, p.getMaxHealth()));
        p.setFoodLevel(food);
        p.setExp(exp);
        p.setLevel(level);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.setAllowFlight(mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR);
        p.setFlying(false);
        p.setFireTicks(0);
        p.setFallDistance(0);
    }
}
