package net.network.minigames.games;

import net.network.minigames.Game;
import net.network.minigames.GameType;
import net.network.minigames.MinigamesPlugin;
import net.network.minigames.Util;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Three circular floors. The block under your feet disappears a moment after you step on it. */
public final class TntRunGame extends Game {

    private static final int R = 12;
    private static final int[] LAYERS = {0, 7, 14};   // TNT at oy+layer, walkable top at oy+layer+1

    private final Map<Block, Integer> pending = new HashMap<>();

    public TntRunGame(MinigamesPlugin plugin, int slot, Location origin) {
        super(plugin, GameType.TNT_RUN, slot, origin);
    }

    private int ox() { return origin.getBlockX(); }
    private int oy() { return origin.getBlockY(); }
    private int oz() { return origin.getBlockZ(); }

    @Override
    protected void buildArena() {
        for (int layer : LAYERS) {
            for (int dx = -R; dx <= R; dx++) {
                for (int dz = -R; dz <= R; dz++) {
                    if (Math.hypot(dx, dz) > R) continue;
                    boolean alt = (Math.floorDiv(dx, 3) + Math.floorDiv(dz, 3) & 1) == 0;
                    Util.set(world, ox() + dx, oy() + layer, oz() + dz, Material.TNT);
                    Util.set(world, ox() + dx, oy() + layer + 1, oz() + dz,
                            alt ? Material.SANDSTONE : Material.CUT_SANDSTONE);
                }
            }
        }
    }

    @Override
    protected Location waitingSpawn() {
        return new Location(world, ox() + 0.5, oy() + 16, oz() + 0.5);
    }

    @Override
    protected Location spawnFor(int index, int total) {
        double a = 2 * Math.PI * index / Math.max(1, total);
        Location l = new Location(world, ox() + 0.5 + Math.cos(a) * 9, oy() + 16, oz() + 0.5 + Math.sin(a) * 9);
        l.setDirection(waitingSpawn().toVector().subtract(l.toVector()));
        return l;
    }

    @Override
    protected void onStart() {
        pending.clear();
    }

    @Override
    protected void onTick(int ticks) {
        int decay = plugin.getConfig().getInt("games.tntrun.decay-ticks", 8);
        for (UUID id : alive) {
            Player p = org.bukkit.Bukkit.getPlayer(id);
            if (p == null) continue;
            Location l = p.getLocation();
            int by = (int) Math.floor(l.getY() - 0.1);
            for (double dx : new double[]{-0.3, 0.3}) {
                for (double dz : new double[]{-0.3, 0.3}) {
                    Block b = world.getBlockAt((int) Math.floor(l.getX() + dx), by, (int) Math.floor(l.getZ() + dz));
                    Material t = b.getType();
                    if (t == Material.SANDSTONE || t == Material.CUT_SANDSTONE) pending.putIfAbsent(b, ticks + decay);
                }
            }
        }
        Iterator<Map.Entry<Block, Integer>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Block, Integer> e = it.next();
            if (e.getValue() > ticks) continue;
            Block b = e.getKey();
            b.setType(Material.AIR, false);
            Block below = b.getRelative(0, -1, 0);
            if (below.getType() == Material.TNT) below.setType(Material.AIR, false);
            it.remove();
        }
    }

    @Override
    protected boolean outOfPlay(Player p) {
        return p.getLocation().getY() < oy() - 3;
    }

    @Override
    protected String outReason() {
        return "fell into the void";
    }

    @Override
    protected void clearArena(Runnable done) {
        Util.fillLayered(plugin, world, ox() - R - 1, oy() - 1, oz() - R - 1, ox() + R + 1, oy() + 17, oz() + R + 1,
                Material.AIR, 6, done);
    }

    @Override
    protected int configMin() { return plugin.getConfig().getInt("games.tntrun.min", 2); }

    @Override
    protected int configMax() { return plugin.getConfig().getInt("games.tntrun.max", 16); }

    @Override
    protected int configCountdown() { return plugin.getConfig().getInt("games.tntrun.countdown", 20); }
}
