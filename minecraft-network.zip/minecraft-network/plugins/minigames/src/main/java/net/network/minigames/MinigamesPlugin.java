package net.network.minigames;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class MinigamesPlugin extends JavaPlugin {

    private GameManager games;
    private Stats stats;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        stats = new Stats(this);
        games = new GameManager(this);
        getServer().getPluginManager().registerEvents(new MinigameListener(this), this);
        MgCommand cmd = new MgCommand(this);
        PluginCommand pc = getCommand("mg");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        // create the arena world once the server is fully started
        Bukkit.getScheduler().runTask(this, () -> games.arenaWorld());
    }

    @Override
    public void onDisable() {
        if (games != null) games.shutdown();
        if (stats != null) stats.save();
    }

    public GameManager games() {
        return games;
    }

    public Stats stats() {
        return stats;
    }

    /** Where players go when a round ends: the spawn of the lobby world. */
    public Location lobby() {
        World w = Bukkit.getWorld(getConfig().getString("lobby-world", "world"));
        if (w == null) w = Bukkit.getWorlds().get(0);
        Location l = w.getSpawnLocation().add(0.5, 0, 0.5);
        l.setYaw(180f);
        return l;
    }
}
