package net.network.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Config-driven chest menus (no extra plugin needed).
 * Item actions: open:&lt;menu&gt;, connect:&lt;server&gt;, command:&lt;command&gt;, close.
 * Lore placeholders: {count:a,b,c} = players on those servers, {online} = whole network.
 */
public final class MenuService implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Pattern COUNT = Pattern.compile("\\{count:([^}]+)}");

    private record Item(int slot, Material material, String name, List<String> lore, String action, boolean glow) {
    }

    private record Menu(String id, String title, int rows, Material fill, List<Item> items) {
    }

    private static final class Holder implements InventoryHolder {
        final Menu menu;
        Inventory inv;

        Holder(Menu menu) {
            this.menu = menu;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final NetworkCore plugin;
    private final ProxyBridge bridge;
    private final Map<String, Menu> menus = new LinkedHashMap<>();

    public MenuService(NetworkCore plugin, ProxyBridge bridge) {
        this.plugin = plugin;
        this.bridge = bridge;
        load();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void load() {
        menus.clear();
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("menus");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            int rows = Math.max(1, Math.min(6, s.getInt("rows", 3)));
            Material fill = mat(s.getString("fill"), null);
            List<Item> items = new ArrayList<>();
            for (Map<?, ?> m : s.getMapList("items")) {
                int slot = m.get("slot") instanceof Number n ? n.intValue() : 0;
                List<String> lore = new ArrayList<>();
                if (m.get("lore") instanceof List<?> l) for (Object o : l) lore.add(String.valueOf(o));
                items.add(new Item(slot,
                        mat(String.valueOf(m.get("material")), Material.STONE),
                        m.get("name") == null ? " " : String.valueOf(m.get("name")),
                        lore,
                        m.get("action") == null ? "" : String.valueOf(m.get("action")),
                        Boolean.TRUE.equals(m.get("glow"))));
            }
            menus.put(id.toLowerCase(), new Menu(id.toLowerCase(), s.getString("title", id), rows, fill, items));
        }
    }

    private static Material mat(String name, Material def) {
        if (name == null) return def;
        Material m = Material.matchMaterial(name);
        return m == null ? def : m;
    }

    public boolean has(String id) {
        return menus.containsKey(id.toLowerCase());
    }

    public Set<String> ids() {
        return menus.keySet();
    }

    public void open(Player p, String id) {
        Menu menu = menus.get(id.toLowerCase());
        if (menu == null) {
            p.sendMessage(Component.text("Unknown menu: " + id));
            return;
        }
        requestCounts(p, menu);
        Holder holder = new Holder(menu);
        Inventory inv = Bukkit.createInventory(holder, menu.rows() * 9, MM.deserialize(menu.title()));
        holder.inv = inv;
        render(inv, menu);
        p.openInventory(inv);
        // refresh once the proxy has answered the count request
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.getOpenInventory().getTopInventory().getHolder() == holder) render(inv, menu);
        }, 12L);
    }

    private void requestCounts(Player p, Menu menu) {
        Set<String> servers = new HashSet<>();
        for (Item it : menu.items()) {
            for (String line : it.lore()) {
                Matcher m = COUNT.matcher(line);
                while (m.find()) for (String s : m.group(1).split(",")) servers.add(s.trim());
            }
        }
        servers.add("ALL");
        for (String s : servers) bridge.requestCount(p, s);
    }

    private String fill(String line) {
        Matcher m = COUNT.matcher(line);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            int total = 0;
            for (String s : m.group(1).split(",")) {
                int c = bridge.count(s.trim());
                if (c > 0) total += c;
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(String.valueOf(total)));
        }
        m.appendTail(sb);
        int online = bridge.count("ALL");
        if (online < 0) online = Bukkit.getOnlinePlayers().size();
        return sb.toString().replace("{online}", String.valueOf(online));
    }

    private void render(Inventory inv, Menu menu) {
        inv.clear();
        if (menu.fill() != null) {
            ItemStack pane = new ItemStack(menu.fill());
            ItemMeta pm = pane.getItemMeta();
            pm.displayName(Component.space());
            pane.setItemMeta(pm);
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
        }
        for (Item it : menu.items()) {
            if (it.slot() < 0 || it.slot() >= inv.getSize()) continue;
            ItemStack stack = new ItemStack(it.material());
            ItemMeta m = stack.getItemMeta();
            m.displayName(MM.deserialize(it.name()).decoration(TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            for (String l : it.lore()) lore.add(MM.deserialize(fill(l)).decoration(TextDecoration.ITALIC, false));
            m.lore(lore);
            if (it.glow()) m.setEnchantmentGlintOverride(true);
            stack.setItemMeta(m);
            inv.setItem(it.slot(), stack);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        for (Item it : holder.menu.items()) {
            if (it.slot() != e.getSlot() || it.action().isEmpty()) continue;
            run(p, it.action());
            return;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    private void run(Player p, String action) {
        int colon = action.indexOf(':');
        String kind = colon < 0 ? action : action.substring(0, colon);
        String arg = colon < 0 ? "" : action.substring(colon + 1);
        switch (kind) {
            case "open" -> Bukkit.getScheduler().runTask(plugin, () -> open(p, arg));
            case "connect" -> {
                p.closeInventory();
                p.sendActionBar(MM.deserialize("<gray>Connecting to <white>" + arg + "</white>..."));
                bridge.connect(p, arg);
            }
            case "command" -> {
                p.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> p.performCommand(arg));
            }
            case "close" -> p.closeInventory();
            default -> {
            }
        }
    }
}
