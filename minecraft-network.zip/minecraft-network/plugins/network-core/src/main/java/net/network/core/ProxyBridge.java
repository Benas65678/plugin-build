package net.network.core;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Talks to Velocity through the BungeeCord plugin-message channel (enabled in velocity.toml). */
public final class ProxyBridge implements PluginMessageListener {

    private static final String CHANNEL = "BungeeCord";

    private final NetworkCore plugin;
    private final Map<String, Integer> counts = new ConcurrentHashMap<>();

    public ProxyBridge(NetworkCore plugin) {
        this.plugin = plugin;
        plugin.getServer().getMessenger().registerOutgoingPluginChannel(plugin, CHANNEL);
        plugin.getServer().getMessenger().registerIncomingPluginChannel(plugin, CHANNEL, this);
    }

    public void connect(Player player, String server) {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("Connect");
        out.writeUTF(server);
        player.sendPluginMessage(plugin, CHANNEL, out.toByteArray());
    }

    /** Ask the proxy for a player count. Use "ALL" for the whole network. Needs a carrier player. */
    public void requestCount(Player carrier, String server) {
        ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("PlayerCount");
        out.writeUTF(server);
        carrier.sendPluginMessage(plugin, CHANNEL, out.toByteArray());
    }

    /** Last known count, or -1 when unknown. */
    public int count(String server) {
        return counts.getOrDefault(server, -1);
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!CHANNEL.equals(channel)) return;
        try {
            ByteArrayDataInput in = ByteStreams.newDataInput(message);
            String sub = in.readUTF();
            if (sub.equals("PlayerCount")) {
                String server = in.readUTF();
                int count = in.readInt();
                counts.put(server, count);
            }
        } catch (RuntimeException ignored) {
            // malformed or unrelated message
        }
    }
}
