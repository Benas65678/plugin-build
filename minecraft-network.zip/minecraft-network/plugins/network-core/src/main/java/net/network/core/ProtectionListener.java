package net.network.core;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.block.Action;
import org.bukkit.Material;

/** Hub: nothing can be changed. SMP: the spawn plaza is protected (build, explosions, mobs, optional PvP). */
public final class ProtectionListener implements Listener {

    private final NetworkCore plugin;

    public ProtectionListener(NetworkCore plugin) {
        this.plugin = plugin;
    }

    private boolean hub() {
        return plugin.isHub();
    }

    /** Hub rules only apply inside the hub world (the minigames server also has an arena world). */
    private boolean hubWorld(World w) {
        return plugin.isHub() && w != null && w.equals(plugin.world());
    }

    private boolean inRegion(Location l) {
        World w = l.getWorld();
        if (w == null || !w.equals(plugin.world())) return false;
        if (hub()) return true;
        Location s = w.getSpawnLocation();
        double r = plugin.getConfig().getDouble("smp.protect-radius", 16);
        double dx = l.getX() - s.getX(), dz = l.getZ() - s.getZ();
        return dx * dx + dz * dz <= r * r;
    }

    private boolean denied(Player p, Location l) {
        return inRegion(l) && !p.hasPermission("netcore.build");
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (denied(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (denied(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (denied(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (denied(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (hubWorld(e.getLocation().getWorld())) {
            e.blockList().clear();
            return;
        }
        e.blockList().removeIf(b -> inRegion(b.getLocation()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (hubWorld(e.getBlock().getWorld())) {
            e.blockList().clear();
            return;
        }
        e.blockList().removeIf(b -> inRegion(b.getLocation()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        CreatureSpawnEvent.SpawnReason r = e.getSpawnReason();
        if (r == CreatureSpawnEvent.SpawnReason.CUSTOM || r == CreatureSpawnEvent.SpawnReason.COMMAND
                || r == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG || r == CreatureSpawnEvent.SpawnReason.DISPENSE_EGG) {
            return;
        }
        if (inRegion(e.getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (hubWorld(e.getEntity().getWorld()) && e.getEntity() instanceof Player) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (hub() || plugin.getConfig().getBoolean("smp.spawn-pvp", false)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        Entity d = e.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Entity shooter) d = shooter;
        if (d instanceof Player && inRegion(victim.getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent e) {
        if (hubWorld(e.getEntity().getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onWeather(WeatherChangeEvent e) {
        if (hubWorld(e.getWorld()) && e.toWeatherState()) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (hubWorld(e.getPlayer().getWorld()) && !e.getPlayer().hasPermission("netcore.build")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (hubWorld(e.getEntity().getWorld()) && e.getEntity() instanceof Player p
                && !p.hasPermission("netcore.build")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPhysical(PlayerInteractEvent e) {
        if (e.getAction() != Action.PHYSICAL || e.getClickedBlock() == null
                || !hubWorld(e.getClickedBlock().getWorld())) return;
        Material t = e.getClickedBlock().getType();
        if (t == Material.FARMLAND || t == Material.TURTLE_EGG) e.setCancelled(true);
    }
}
