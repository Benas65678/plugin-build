package net.network.core;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class NetworkCore extends JavaPlugin {

    private ProxyBridge bridge;
    private SpawnBuilder spawnBuilder;
    private HubService hub;
    private MenuService menus;
    private NamespacedKey builtKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        builtKey = new NamespacedKey(this, "spawn_built");
        bridge = new ProxyBridge(this);
        spawnBuilder = new SpawnBuilder(this);
        menus = new MenuService(this, bridge);

        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        if (isHub()) {
            hub = new HubService(this, bridge);
            hub.start();
        }

        CoreCommands commands = new CoreCommands(this);
        for (String name : List.of("hub", "spawn", "spawnbuild", "netcore", "menu", "modes", "smp", "minigames")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(commands);
                pc.setTabCompleter(commands);
            }
        }
        getServer().getScheduler().runTaskLater(this, this::autoBuild, 20L);
    }

    public boolean isHub() {
        return getConfig().getString("role", "smp").equalsIgnoreCase("hub");
    }

    public World world() {
        World w = Bukkit.getWorld(getConfig().getString("world", "world"));
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    public MenuService menus() {
        return menus;
    }

    public ProxyBridge bridge() {
        return bridge;
    }

    public SpawnBuilder spawnBuilder() {
        return spawnBuilder;
    }

    public Location spawnLocation() {
        World w = world();
        if (isHub()) return spawnBuilder.hubSpawn(w);
        Location s = w.getSpawnLocation();
        s.setYaw(180f);
        return s.add(0.5, 0, 0.5);
    }

    private void autoBuild() {
        if (!getConfig().getBoolean("auto-build", true)) return;
        if (world().getPersistentDataContainer().has(builtKey, PersistentDataType.BYTE)) return;
        getLogger().info("Building spawn for the first time...");
        rebuild(null);
    }

    /** Rebuilds the spawn. {@code themeOverride} only applies to SMP servers. */
    public Location rebuild(String themeOverride) {
        World w = world();
        Location s;
        if (isHub()) {
            s = spawnBuilder.buildHub(w);
        } else {
            String theme = themeOverride != null ? themeOverride : getConfig().getString("theme", "classic");
            s = spawnBuilder.buildSmp(w, theme);
        }
        w.getPersistentDataContainer().set(builtKey, PersistentDataType.BYTE, (byte) 1);
        return s;
    }
}
