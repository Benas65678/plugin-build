package net.network.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public final class CoreCommands implements CommandExecutor, TabCompleter {

    private final NetworkCore plugin;

    public CoreCommands(NetworkCore plugin) {
        this.plugin = plugin;
    }

    private static Component msg(String s, NamedTextColor c) {
        return Component.text(s, c);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "menu", "modes", "smp", "minigames" -> {
                if (!(sender instanceof Player p)) return true;
                String id = cmd.getName().equalsIgnoreCase("menu") ? (args.length > 0 ? args[0] : "modes") : cmd.getName();
                plugin.menus().open(p, id);
            }
            case "hub" -> {
                if (!(sender instanceof Player p)) return true;
                if (plugin.isHub() && plugin.getConfig().getBoolean("main-hub", true)) {
                    p.teleport(plugin.spawnLocation());
                } else {
                    p.sendActionBar(msg("Connecting to the hub...", NamedTextColor.GRAY));
                    plugin.bridge().connect(p, plugin.getConfig().getString("hub-server", "hub"));
                }
            }
            case "spawn" -> {
                if (!(sender instanceof Player p)) return true;
                p.teleport(plugin.spawnLocation());
                p.sendActionBar(msg("Teleported to spawn.", NamedTextColor.GRAY));
            }
            case "spawnbuild" -> {
                if (args.length >= 1 && (args[0].equalsIgnoreCase("hub") || args[0].equalsIgnoreCase("smp"))) {
                    boolean wantHub = args[0].equalsIgnoreCase("hub");
                    if (wantHub != plugin.isHub()) {
                        sender.sendMessage(msg("This server's role is '" + (plugin.isHub() ? "hub" : "smp")
                                + "'. Change role in config.yml and restart first.", NamedTextColor.RED));
                        return true;
                    }
                }
                String theme = args.length >= 2 ? args[1] : null;
                sender.sendMessage(msg("Rebuilding spawn... (the server may lag for a moment)", NamedTextColor.YELLOW));
                Location s = plugin.rebuild(theme);
                if (sender instanceof Player p) p.teleport(s);
                sender.sendMessage(msg("Spawn rebuilt.", NamedTextColor.GREEN));
            }
            case "netcore" -> {
                String sub = args.length > 0 ? args[0].toLowerCase() : "info";
                switch (sub) {
                    case "reload" -> {
                        plugin.reloadConfig();
                        plugin.menus().load();
                        sender.sendMessage(msg("Config and menus reloaded. Restart to apply gate changes.", NamedTextColor.GREEN));
                    }
                    case "rebuild" -> {
                        Location s = plugin.rebuild(null);
                        if (sender instanceof Player p) p.teleport(s);
                        sender.sendMessage(msg("Spawn rebuilt.", NamedTextColor.GREEN));
                    }
                    default -> sender.sendMessage(msg("NetworkCore - role: "
                            + (plugin.isHub() ? "hub" : "smp") + ", world: " + plugin.world().getName(), NamedTextColor.AQUA));
                }
            }
            default -> {
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();
        if (name.equals("menu") && args.length == 1) return List.copyOf(plugin.menus().ids());
        if (name.equals("netcore") && args.length == 1) return List.of("reload", "rebuild", "info");
        if (name.equals("spawnbuild")) {
            if (args.length == 1) return List.of("hub", "smp");
            if (args.length == 2) return List.of("gems", "enchant", "lifesteal", "classic");
        }
        return List.of();
    }
}
