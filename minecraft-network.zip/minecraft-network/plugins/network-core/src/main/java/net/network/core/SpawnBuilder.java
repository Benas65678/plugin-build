package net.network.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.List;
import java.util.Random;

/**
 * Generates the spawns procedurally so the server has a proper spawn on day one.
 * Hub: a floating island with a sunburst plaza, a beacon fountain, one arch per gate,
 * lantern posts, launch pads and holograms.
 * SMP: a themed plaza flattened into the world spawn (gems / enchant / lifesteal / classic).
 */
public final class SpawnBuilder {

    public static final String TAG = "netcore-build";
    public static final int HUB_RADIUS = 30;
    public static final int PLAZA_RADIUS = 24;
    public static final int GATE_RING = 18;
    public static final int SMP_RADIUS = 14;

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final NetworkCore plugin;

    public SpawnBuilder(NetworkCore plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ shared helpers

    private static void set(World w, int x, int y, int z, Material m) {
        w.getBlockAt(x, y, z).setType(m, false);
    }

    private Material cfgMat(String path, Material def) {
        String name = plugin.getConfig().getString(path);
        if (name == null) return def;
        Material m = Material.matchMaterial(name);
        return m == null ? def : m;
    }

    private void clearOld(World w) {
        for (Entity e : w.getEntitiesByClass(TextDisplay.class)) {
            if (e.getScoreboardTags().contains(TAG)) e.remove();
        }
    }

    private void text(World w, double x, double y, double z, String mini, float scale, String extraTag) {
        Component c = MM.deserialize(mini);
        Location loc = new Location(w, x, y, z);
        w.spawn(loc, TextDisplay.class, t -> {
            t.text(c);
            t.setBillboard(Display.Billboard.CENTER);
            t.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            t.setShadowed(true);
            t.setSeeThrough(false);
            t.setPersistent(true);
            t.setViewRange(2.0f);
            t.setLineWidth(600);
            t.addScoreboardTag(TAG);
            if (extraTag != null) t.addScoreboardTag(extraTag);
            t.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(),
                    new Vector3f(scale, scale, scale), new AxisAngle4f()));
        });
    }

    @SuppressWarnings("unchecked")
    private static void rule(World w, String name, Object value) {
        try {
            org.bukkit.GameRule<Object> gr = (org.bukkit.GameRule<Object>) org.bukkit.GameRule.getByName(name);
            if (gr != null) w.setGameRule(gr, value);
        } catch (RuntimeException ignored) {
            // game rule renamed in this version
        }
    }

    // ------------------------------------------------------------------ HUB

    public Location hubSpawn(World w) {
        FileConfiguration c = plugin.getConfig();
        int cx = c.getInt("hub.center.x"), cy = c.getInt("hub.center.y"), cz = c.getInt("hub.center.z");
        return new Location(w, cx + 0.5, cy + 1, cz + 10.5, (float) c.getDouble("hub.spawn-yaw", 180), 0f);
    }

    public Location buildHub(World w) {
        FileConfiguration c = plugin.getConfig();
        clearOld(w);
        final int cx = c.getInt("hub.center.x"), cy = c.getInt("hub.center.y"), cz = c.getInt("hub.center.z");
        final Material primary = cfgMat("hub.palette.primary", Material.STONE_BRICKS);
        final Material secondary = cfgMat("hub.palette.secondary", Material.POLISHED_ANDESITE);
        final Material accent = cfgMat("hub.palette.accent", Material.POLISHED_BLACKSTONE_BRICKS);
        final Material accent2 = cfgMat("hub.palette.accent2", Material.DEEPSLATE_TILES);
        final Material gold = cfgMat("hub.palette.gold", Material.GOLD_BLOCK);
        final Material[] flora = {Material.POPPY, Material.DANDELION, Material.AZURE_BLUET,
                Material.CORNFLOWER, Material.SHORT_GRASS, Material.OXEYE_DAISY};
        final Material[] filler = {Material.ANDESITE, Material.TUFF, Material.COBBLESTONE, Material.STONE};
        Random rnd = new Random(w.getSeed() ^ 0xB10CL);

        // island body: paved plaza + grass fringe + tapering rock underside
        for (int dx = -HUB_RADIUS; dx <= HUB_RADIUS; dx++) {
            for (int dz = -HUB_RADIUS; dz <= HUB_RADIUS; dz++) {
                double d = Math.hypot(dx, dz);
                if (d > HUB_RADIUS) continue;
                int x = cx + dx, z = cz + dz;

                Material top;
                if (d > PLAZA_RADIUS) {
                    top = Material.GRASS_BLOCK;
                } else if (d <= 1.6) {
                    top = Material.IRON_BLOCK;
                } else if (d >= 2.2 && d <= 3.6) {
                    top = Material.WATER;
                } else if (d > 3.6 && d <= 4.6) {
                    top = Material.SMOOTH_QUARTZ;
                } else if (d >= 23 && d <= PLAZA_RADIUS) {
                    top = accent2;
                } else if ((d >= 11.5 && d <= 12.5) || (d >= 17.5 && d <= 18.5)) {
                    top = accent;
                } else if (d <= 9) {
                    top = ((dx + dz) & 1) == 0 ? primary : secondary;
                } else {
                    int sector = (int) ((Math.atan2(dz, dx) + Math.PI) / (Math.PI / 8));
                    top = (sector & 1) == 0 ? primary : secondary;
                }
                set(w, x, cy, z, top);
                for (int h = 1; h <= 14; h++) set(w, x, cy + h, z, Material.AIR);
                if (top == Material.WATER) set(w, x, cy - 1, z, Material.PRISMARINE_BRICKS);

                if (d > PLAZA_RADIUS + 1 && d < HUB_RADIUS - 1 && rnd.nextInt(6) == 0) {
                    set(w, x, cy + 1, z, flora[rnd.nextInt(flora.length)]);
                }

                double depth = 24 * Math.pow(1 - d / (HUB_RADIUS + 1.0), 0.9) + 2
                        + Math.sin(dx * 0.5) * Math.cos(dz * 0.45) * 2;
                int start = top == Material.WATER ? 2 : 1;
                for (int h = start; h <= depth; h++) {
                    Material m;
                    if (h <= 2) m = d > PLAZA_RADIUS ? Material.DIRT : Material.STONE_BRICKS;
                    else if (h > 14) m = Material.DEEPSLATE;
                    else m = Material.STONE;
                    if (h > 2 && rnd.nextInt(16) == 0) m = filler[rnd.nextInt(filler.length)];
                    if (h > 4 && rnd.nextInt(70) == 0) m = h > 14 ? Material.DEEPSLATE_DIAMOND_ORE : Material.IRON_ORE;
                    set(w, x, cy - h, z, m);
                }
            }
        }

        // beacon fountain
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) set(w, cx + dx, cy, cz + dz, Material.IRON_BLOCK);
        set(w, cx, cy + 1, cz, Material.BEACON);
        set(w, cx, cy + 2, cz, Material.CYAN_STAINED_GLASS);

        // spawn dais (south of the fountain)
        int sz = cz + 10;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                double d = Math.hypot(dx, dz);
                if (d > 3.8) continue;
                set(w, cx + dx, cy, sz + dz, d >= 2.6 ? gold : accent2);
            }
        }

        // gates
        List<Gate> gates = Gate.load(c);
        for (Gate g : gates) buildGate(w, cx, cy, cz, g, accent);

        // lantern posts around the rim (skip near gates)
        for (int i = 0; i < 24; i++) {
            double a = Math.toRadians(i * 15.0);
            int px = cx + (int) Math.round(23.5 * Math.cos(a));
            int pz = cz + (int) Math.round(23.5 * Math.sin(a));
            boolean nearGate = false;
            for (Gate g : gates) {
                double gx = g.blockX(cx, GATE_RING), gz = g.blockZ(cz, GATE_RING);
                if (Math.hypot(px - gx, pz - gz) < 9) nearGate = true;
            }
            if (nearGate) continue;
            for (int h = 1; h <= 3; h++) set(w, px, cy + h, pz, Material.POLISHED_BLACKSTONE_BRICK_WALL);
            set(w, px, cy + 4, pz, Material.LANTERN);
        }

        // launch pads on the diagonals
        if (c.getBoolean("hub.launchpads", true)) {
            for (int k = 0; k < 4; k++) {
                double a = Math.toRadians(45 + 90 * k);
                int px = cx + (int) Math.round(13 * Math.cos(a));
                int pz = cz + (int) Math.round(13 * Math.sin(a));
                set(w, px, cy, pz, Material.GOLD_BLOCK);
                set(w, px, cy + 1, pz, Material.LIGHT_WEIGHTED_PRESSURE_PLATE);
                text(w, px + 0.5, cy + 2.6, pz + 0.5, "<yellow><bold>JUMP", 1.0f, null);
            }
        }

        // holograms
        text(w, cx + 0.5, cy + 13, cz + 0.5, c.getString("hub.title", "<bold>HUB"), 5.0f, null);
        text(w, cx + 0.5, cy + 10.6, cz + 0.5, c.getString("hub.subtitle", ""), 1.6f, null);
        text(w, cx + 0.5, cy + 3.2, sz + 0.5,
                "<gold><bold>SPAWN</bold>\n<gray>Walk into a gate or use your compass", 1.1f, null);

        rule(w, "doDaylightCycle", false);
        rule(w, "doWeatherCycle", false);
        rule(w, "doMobSpawning", false);
        rule(w, "spawnRadius", 0);
        rule(w, "announceAdvancements", false);
        w.setTime(c.getLong("hub.fixed-time", 6000));
        Location spawn = hubSpawn(w);
        w.setSpawnLocation(spawn.getBlockX(), spawn.getBlockY(), spawn.getBlockZ());
        return spawn;
    }

    private void buildGate(World w, int cx, int cy, int cz, Gate g, Material accent) {
        final int gx = g.blockX(cx, GATE_RING), gz = g.blockZ(cz, GATE_RING);
        final double rad = Math.toRadians(g.angle());
        final double rx = Math.cos(rad), rz = Math.sin(rad);   // radial (outward)
        final double tx = -Math.sin(rad), tz = Math.cos(rad);  // tangent

        for (double u = -5; u <= 5; u += 0.5) {
            for (double v = -1.5; v <= 1.5; v += 0.5) {
                int x = (int) Math.round(gx + v * rx + u * tx);
                int z = (int) Math.round(gz + v * rz + u * tz);
                double au = Math.abs(u);

                // floor of the opening: checkerboard of the gate colour and glow
                if (au <= 2.5) {
                    boolean glowTile = ((int) Math.floor(u * 2) + (int) Math.floor(v * 2) & 1) == 0;
                    set(w, x, cy, z, glowTile ? g.glow() : g.block());
                }
                // pillars
                if (au >= 3 && au <= 4.5) {
                    for (int h = 1; h <= 7; h++) {
                        Material m = h % 4 == 0 ? accent : g.block();
                        if (h == 3 && Math.abs(v) <= 0.5 && au <= 3.5) m = g.glow();
                        set(w, x, cy + h, z, m);
                    }
                }
                // lintel
                if (au <= 4.5) {
                    set(w, x, cy + 8, z, g.block());
                    set(w, x, cy + 9, z, accent);
                }
            }
        }
        double centreX = gx + 0.5, centreZ = gz + 0.5;
        text(w, centreX, cy + 11.4, centreZ, g.label(), 3.2f, null);
        text(w, centreX, cy + 10.0, centreZ, g.subtitle(), 1.4f, null);
        text(w, centreX, cy + 5.4, centreZ, "<gray>…", 1.3f, "netcore-count-" + g.id());
    }

    // ------------------------------------------------------------------ SMP

    private record Theme(Material floorA, Material floorB, Material ring, Material pillar,
                         Material glow, Material base) {
    }

    private static Theme theme(String name) {
        return switch (name.toLowerCase()) {
            case "gems", "bliss" -> new Theme(Material.POLISHED_DEEPSLATE, Material.DEEPSLATE_TILES,
                    Material.AMETHYST_BLOCK, Material.PURPUR_PILLAR, Material.SEA_LANTERN, Material.DEEPSLATE);
            case "enchant" -> new Theme(Material.POLISHED_BLACKSTONE_BRICKS, Material.DEEPSLATE_BRICKS,
                    Material.LAPIS_BLOCK, Material.QUARTZ_PILLAR, Material.SEA_LANTERN, Material.DEEPSLATE);
            case "lifesteal" -> new Theme(Material.NETHER_BRICKS, Material.RED_NETHER_BRICKS,
                    Material.CRYING_OBSIDIAN, Material.CRYING_OBSIDIAN, Material.SHROOMLIGHT, Material.NETHERRACK);
            default -> new Theme(Material.STONE_BRICKS, Material.MOSSY_STONE_BRICKS,
                    Material.SPRUCE_PLANKS, Material.OAK_LOG, Material.SHROOMLIGHT, Material.STONE);
        };
    }

    private static int groundY(World w, int x, int z) {
        int y = w.getHighestBlockYAt(x, z);
        while (y > w.getMinHeight() + 5) {
            Block b = w.getBlockAt(x, y, z);
            Material t = b.getType();
            if (t.isAir() || b.isLiquid() || Tag.LEAVES.isTagged(t) || Tag.LOGS.isTagged(t)
                    || !t.isSolid()) {
                y--;
            } else {
                break;
            }
        }
        return Math.max(y, w.getSeaLevel());
    }

    private static final String[] HEART = {
            "..XX...XX..",
            ".XXXX.XXXX.",
            "XXXXXXXXXXX",
            "XXXXXXXXXXX",
            ".XXXXXXXXX.",
            "..XXXXXXX..",
            "...XXXXX...",
            "....XXX....",
            ".....X....."
    };

    public Location buildSmp(World w, String themeName) {
        clearOld(w);
        Theme t = theme(themeName);
        Location sp = w.getSpawnLocation();
        final int cx = sp.getBlockX(), cz = sp.getBlockZ();
        final int gy = groundY(w, cx, cz);
        final int R = SMP_RADIUS;

        for (int dx = -R - 2; dx <= R + 2; dx++) {
            for (int dz = -R - 2; dz <= R + 2; dz++) {
                double d = Math.hypot(dx, dz);
                if (d > R + 2) continue;
                int x = cx + dx, z = cz + dz;
                // fill downwards until we hit solid ground
                for (int y = gy - 1; y > gy - 40; y--) {
                    Block b = w.getBlockAt(x, y, z);
                    Material bt = b.getType();
                    if (bt.isSolid() && !Tag.LEAVES.isTagged(bt) && !Tag.LOGS.isTagged(bt)) break;
                    set(w, x, y, z, d <= R ? t.base() : Material.DIRT);
                }
                // clear everything above (trees, hills, water)
                for (int y = gy + 1; y <= gy + 18; y++) {
                    if (!w.getBlockAt(x, y, z).getType().isAir()) set(w, x, y, z, Material.AIR);
                }
                Material top;
                if (d > R) top = Material.GRASS_BLOCK;
                else if (d >= R - 1) top = t.ring();
                else if (d >= 6.5 && d <= 7.5) top = t.ring();
                else top = ((dx + dz) & 1) == 0 ? t.floorA() : t.floorB();
                set(w, x, gy, z, top);
            }
        }

        // lamp pillars
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(k * 45.0 + 22.5);
            int px = cx + (int) Math.round((R - 2) * Math.cos(a));
            int pz = cz + (int) Math.round((R - 2) * Math.sin(a));
            for (int h = 1; h <= 3; h++) set(w, px, gy + h, pz, t.pillar());
            set(w, px, gy + 4, pz, t.glow());
        }

        switch (themeName.toLowerCase()) {
            case "gems", "bliss" -> {
                for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) set(w, cx + dx, gy, cz + dz, Material.POLISHED_DEEPSLATE);
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) set(w, cx + dx, gy + 1, cz + dz, Material.AMETHYST_BLOCK);
                set(w, cx, gy + 2, cz, Material.BUDDING_AMETHYST);
                set(w, cx, gy + 3, cz, Material.AMETHYST_CLUSTER);
                set(w, cx + 1, gy + 2, cz + 1, Material.LARGE_AMETHYST_BUD);
                set(w, cx - 1, gy + 2, cz + 1, Material.MEDIUM_AMETHYST_BUD);
                set(w, cx + 1, gy + 2, cz - 1, Material.MEDIUM_AMETHYST_BUD);
                set(w, cx - 1, gy + 2, cz - 1, Material.LARGE_AMETHYST_BUD);
                for (int h = 4; h <= 9; h++) set(w, cx, gy + h, cz, Material.END_ROD);
                for (int sx : new int[]{-9, 9}) for (int sz2 : new int[]{-9, 9}) {
                    for (int h = 1; h <= 5; h++) set(w, cx + sx, gy + h, cz + sz2, Material.AMETHYST_BLOCK);
                    set(w, cx + sx, gy + 6, cz + sz2, Material.AMETHYST_CLUSTER);
                }
            }
            case "enchant" -> {
                for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) set(w, cx + dx, gy, cz + dz, Material.OBSIDIAN);
                set(w, cx, gy + 1, cz, Material.ENCHANTING_TABLE);
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != 2) continue;
                        if (dz == 2 && Math.abs(dx) <= 1) continue; // open side to the south
                        set(w, cx + dx, gy + 1, cz + dz, Material.BOOKSHELF);
                        set(w, cx + dx, gy + 2, cz + dz, Material.BOOKSHELF);
                    }
                }
                for (int sx : new int[]{-9, 9}) for (int sz2 : new int[]{-9, 9}) {
                    for (int h = 1; h <= 6; h++) set(w, cx + sx, gy + h, cz + sz2, Material.QUARTZ_PILLAR);
                    set(w, cx + sx, gy + 7, cz + sz2, Material.SEA_LANTERN);
                }
            }
            case "lifesteal" -> {
                for (int row = 0; row < HEART.length; row++) {
                    for (int col = 0; col < HEART[row].length(); col++) {
                        if (HEART[row].charAt(col) != 'X') continue;
                        boolean shine = row == 1 && (col == 2 || col == 3);
                        set(w, cx - 5 + col, gy, cz - 4 + row, shine ? Material.PINK_CONCRETE : Material.RED_CONCRETE);
                    }
                }
                for (int sx : new int[]{-9, 9}) for (int sz2 : new int[]{-9, 9}) {
                    for (int h = 1; h <= 5; h++) set(w, cx + sx, gy + h, cz + sz2, Material.CRYING_OBSIDIAN);
                    set(w, cx + sx, gy + 6, cz + sz2, Material.SHROOMLIGHT);
                }
                text(w, cx + 0.5, gy + 6.5, cz + 0.5, "<red>❤", 6.0f, null);
            }
            default -> {
                for (int dx = -3; dx <= 3; dx++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        int m = Math.max(Math.abs(dx), Math.abs(dz));
                        if (m == 3) {
                            set(w, cx + dx, gy, cz + dz, Material.STONE_BRICKS);
                            set(w, cx + dx, gy + 1, cz + dz, Material.STONE_BRICK_SLAB);
                        } else {
                            set(w, cx + dx, gy, cz + dz, Material.WATER);
                            set(w, cx + dx, gy - 1, cz + dz, Material.STONE_BRICKS);
                        }
                    }
                }
                for (int h = 1; h <= 3; h++) set(w, cx, gy + h, cz, Material.STONE_BRICKS);
                set(w, cx, gy + 4, cz, Material.SHROOMLIGHT);
            }
        }

        FileConfiguration c = plugin.getConfig();
        String base = "smp.themes." + themeName.toLowerCase() + ".";
        String title = c.getString(base + "title", "<bold>" + themeName.toUpperCase());
        List<String> tips = c.getStringList(base + "tips");
        double hy = themeName.equalsIgnoreCase("lifesteal") ? gy + 9.5 : gy + 10;
        text(w, cx + 0.5, hy, cz + 0.5, title, 5.0f, null);
        Location spawn = new Location(w, cx + 0.5, gy + 1, cz + R - 3 + 0.5, 180f, 0f);
        if (!tips.isEmpty()) {
            text(w, cx + 0.5, gy + 3.4, cz + R - 4 + 0.5, String.join("\n", tips), 1.0f, null);
        }
        w.setSpawnLocation(spawn.getBlockX(), spawn.getBlockY(), spawn.getBlockZ());
        rule(w, "spawnRadius", 0);
        return spawn;
    }
}
