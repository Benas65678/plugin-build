package net.network.core;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Everything that only exists on the hub: join flow, selector, gates, launch pads, sidebar. */
public final class HubService implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final NetworkCore plugin;
    private final ProxyBridge bridge;
    private final NamespacedKey selectorKey;
    private final Map<UUID, Long> gateCooldown = new HashMap<>();
    private final Map<UUID, Long> padCooldown = new HashMap<>();
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    private List<Gate> gates = new ArrayList<>();

    public HubService(NetworkCore plugin, ProxyBridge bridge) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.selectorKey = new NamespacedKey(plugin, "selector");
    }

    public void start() {
        gates = Gate.load(plugin.getConfig());
        Bukkit.getPluginManager().registerEvents(this, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, this::particles, 20L, 4L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::updateSidebars, 40L, 40L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::refreshCounts, 60L, 100L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::updateGateTexts, 80L, 100L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::keepTime, 100L, 600L);
    }

    private int ringCx() { return plugin.getConfig().getInt("hub.center.x"); }
    private int ringCy() { return plugin.getConfig().getInt("hub.center.y"); }
    private int ringCz() { return plugin.getConfig().getInt("hub.center.z"); }

    // ------------------------------------------------------------------ join flow

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        FileConfiguration c = plugin.getConfig();
        p.teleport(plugin.spawnLocation());
        try {
            p.setGameMode(GameMode.valueOf(c.getString("hub.gamemode", "ADVENTURE")));
        } catch (IllegalArgumentException ex) {
            p.setGameMode(GameMode.ADVENTURE);
        }
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setFireTicks(0);
        if (c.getBoolean("hub.clear-inventory", true)) {
            p.getInventory().clear();
            p.getInventory().setItem(4, selectorItem());
            p.getInventory().setHeldItemSlot(4);
        }
        createSidebar(p);
        p.sendPlayerListHeaderAndFooter(MM.deserialize(fill(c.getString("hub.tab.header", ""), p)),
                MM.deserialize(fill(c.getString("hub.tab.footer", ""), p)));
        p.showTitle(Title.title(MM.deserialize(c.getString("hub.title", "")),
                MM.deserialize(c.getString("hub.subtitle", "")),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(600))));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 1.2f);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        boards.remove(id);
        gateCooldown.remove(id);
        padCooldown.remove(id);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        e.setRespawnLocation(plugin.spawnLocation());
    }

    private ItemStack selectorItem() {
        FileConfiguration c = plugin.getConfig();
        ItemStack it = new ItemStack(Material.COMPASS);
        ItemMeta m = it.getItemMeta();
        m.displayName(MM.deserialize(c.getString("hub.selector-item.name", "<green>Server Selector"))
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String s : c.getStringList("hub.selector-item.lore")) {
            lore.add(MM.deserialize(s).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        }
        m.lore(lore);
        m.getPersistentDataContainer().set(selectorKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    private boolean isSelector(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(selectorKey, PersistentDataType.BYTE);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isSelector(e.getItem())) return;
        e.setCancelled(true);
        e.getPlayer().performCommand(plugin.getConfig().getString("hub.selector-command", "modes"));
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (p.hasPermission("netcore.build")) return;
        if (isSelector(e.getCurrentItem()) || isSelector(e.getCursor())) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ movement: gates, pads, void

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        Location from = e.getFrom();
        Player p = e.getPlayer();
        if (to.getWorld() == null || !to.getWorld().equals(plugin.world())) return;   // arena worlds are not ours

        if (to.getY() < plugin.getConfig().getInt("hub.void-y", 20)) {
            p.teleport(plugin.spawnLocation());
            p.setFallDistance(0);
            return;
        }
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) return;

        // launch pad
        if (plugin.getConfig().getBoolean("hub.launchpads", true)
                && to.getBlock().getType() == Material.LIGHT_WEIGHTED_PRESSURE_PLATE) {
            long now = System.currentTimeMillis();
            if (now - padCooldown.getOrDefault(p.getUniqueId(), 0L) > 1500) {
                padCooldown.put(p.getUniqueId(), now);
                Location centre = new Location(to.getWorld(), ringCx() + 0.5, to.getY(), ringCz() + 0.5);
                Vector dir = centre.toVector().subtract(to.toVector()).setY(0).normalize().multiply(1.25);
                dir.setY(1.05);
                p.setVelocity(dir);
                p.playSound(to, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 1.0f);
                p.getWorld().spawnParticle(Particle.FIREWORK, to, 20, 0.3, 0.1, 0.3, 0.05);
            }
        }

        // gates
        int cx = ringCx(), cy = ringCy(), cz = ringCz();
        for (Gate g : gates) {
            double gx = g.blockX(cx, SpawnBuilder.GATE_RING) + 0.5;
            double gz = g.blockZ(cz, SpawnBuilder.GATE_RING) + 0.5;
            double dx = to.getX() - gx, dz = to.getZ() - gz;
            if (dx * dx + dz * dz > 2.2 * 2.2) continue;
            if (to.getY() < cy + 1 || to.getY() > cy + 5) continue;
            long now = System.currentTimeMillis();
            if (now - gateCooldown.getOrDefault(p.getUniqueId(), 0L) < 3000) return;
            gateCooldown.put(p.getUniqueId(), now);
            enterGate(p, g);
            return;
        }
    }

    private void enterGate(Player p, Gate g) {
        p.playSound(p.getLocation(), Sound.BLOCK_PORTAL_TRAVEL, 0.4f, 1.6f);
        if (!g.server().isEmpty()) {
            String msg = plugin.getConfig().getString("hub.messages.connecting", "<gray>Connecting to {target}...")
                    .replace("{target}", g.label());
            p.sendActionBar(MM.deserialize(msg));
            bridge.connect(p, g.server());
        } else if (!g.command().isEmpty()) {
            p.performCommand(g.command());
        }
    }

    // ------------------------------------------------------------------ visuals

    private void particles() {
        World w = plugin.world();
        if (w.getPlayers().isEmpty()) return;
        int cx = ringCx(), cy = ringCy(), cz = ringCz();
        for (Gate g : gates) {
            double gx = g.blockX(cx, SpawnBuilder.GATE_RING) + 0.5;
            double gz = g.blockZ(cz, SpawnBuilder.GATE_RING) + 0.5;
            w.spawnParticle(Particle.DUST, gx, cy + 3, gz, 6, 1.6, 1.8, 0.4,
                    new Particle.DustOptions(g.color(), 1.6f));
            w.spawnParticle(Particle.END_ROD, gx, cy + 3, gz, 1, 1.6, 1.8, 0.4, 0.01);
        }
        w.spawnParticle(Particle.END_ROD, cx + 0.5, cy + 3, cz + 0.5, 2, 0.4, 1.5, 0.4, 0.02);
    }

    private void keepTime() {
        plugin.world().setTime(plugin.getConfig().getLong("hub.fixed-time", 6000));
    }

    private void refreshCounts() {
        Player carrier = Bukkit.getOnlinePlayers().stream().findFirst().orElse(null);
        if (carrier == null) return;
        bridge.requestCount(carrier, "ALL");
        for (Gate g : gates) for (String s : g.countServers()) bridge.requestCount(carrier, s);
    }

    private void updateGateTexts() {
        World w = plugin.world();
        for (Gate g : gates) {
            int total = 0;
            boolean known = false;
            for (String s : g.countServers()) {
                int c = bridge.count(s);
                if (c >= 0) { total += c; known = true; }
            }
            Component text = known
                    ? MM.deserialize("<green>●</green> <white>" + total + "</white> <gray>playing")
                    : MM.deserialize("<gray>…");
            String tag = "netcore-count-" + g.id();
            for (Entity en : w.getEntitiesByClass(TextDisplay.class)) {
                if (en.getScoreboardTags().contains(tag)) ((TextDisplay) en).text(text);
            }
        }
    }

    // ------------------------------------------------------------------ sidebar

    private String fill(String s, Player p) {
        FileConfiguration c = plugin.getConfig();
        int online = bridge.count("ALL");
        if (online < 0) online = Bukkit.getOnlinePlayers().size();
        return s.replace("{player}", p.getName())
                .replace("{online}", String.valueOf(online))
                .replace("{server}", c.getString("server-label", "Hub"))
                .replace("{ip}", c.getString("ip", ""))
                .replace("{network}", c.getString("network-name", ""));
    }

    private void createSidebar(Player p) {
        FileConfiguration c = plugin.getConfig();
        List<String> lines = c.getStringList("hub.sidebar.lines");
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("hub", Criteria.DUMMY,
                MM.deserialize(c.getString("hub.sidebar.title", "Hub")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat.blank());
        for (int i = 0; i < lines.size(); i++) {
            String entry = "§" + (char) ('a' + i) + "§r";
            Team t = sb.registerNewTeam("l" + i);
            t.addEntry(entry);
            obj.getScore(entry).setScore(lines.size() - i);
        }
        boards.put(p.getUniqueId(), sb);
        p.setScoreboard(sb);
        updateSidebar(p);
    }

    private void updateSidebars() {
        for (Player p : Bukkit.getOnlinePlayers()) updateSidebar(p);
    }

    private void updateSidebar(Player p) {
        Scoreboard sb = boards.get(p.getUniqueId());
        if (sb == null) return;
        List<String> lines = plugin.getConfig().getStringList("hub.sidebar.lines");
        for (int i = 0; i < lines.size(); i++) {
            Team t = sb.getTeam("l" + i);
            if (t != null) t.prefix(MM.deserialize(fill(lines.get(i), p)));
        }
    }
}
