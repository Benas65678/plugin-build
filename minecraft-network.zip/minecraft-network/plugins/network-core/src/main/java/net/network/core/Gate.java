package net.network.core;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** A walk-through gate on the hub island. Either connects to a server or runs a (menu) command. */
public record Gate(String id, String label, String subtitle, String server, String command,
                   List<String> countServers, Material block, Material glow, double angle, Color color) {

    public static List<Gate> load(FileConfiguration cfg) {
        List<Gate> out = new ArrayList<>();
        for (Map<?, ?> m : cfg.getMapList("hub.gates")) {
            String server = str(m, "server", "");
            List<String> counts = new ArrayList<>();
            if (m.get("count-servers") instanceof List<?> l) {
                for (Object o : l) counts.add(String.valueOf(o));
            }
            if (counts.isEmpty() && !server.isEmpty()) counts.add(server);
            double angle = m.get("angle") instanceof Number n ? n.doubleValue() : 0.0;
            out.add(new Gate(
                    str(m, "id", "gate" + out.size()),
                    str(m, "label", "<white>Gate"),
                    str(m, "subtitle", ""),
                    server,
                    str(m, "command", ""),
                    counts,
                    mat(str(m, "block", "STONE_BRICKS"), Material.STONE_BRICKS),
                    mat(str(m, "glow", "SEA_LANTERN"), Material.SEA_LANTERN),
                    angle,
                    color(str(m, "color", "#ffffff"))));
        }
        return out;
    }

    /** Block coordinates of the gate centre on the plaza ring. */
    public int blockX(int cx, int radius) {
        return cx + (int) Math.round(radius * Math.cos(Math.toRadians(angle)));
    }

    public int blockZ(int cz, int radius) {
        return cz + (int) Math.round(radius * Math.sin(Math.toRadians(angle)));
    }

    private static String str(Map<?, ?> m, String key, String def) {
        Object o = m.get(key);
        return o == null ? def : String.valueOf(o);
    }

    private static Material mat(String name, Material def) {
        Material m = Material.matchMaterial(name);
        return m == null ? def : m;
    }

    private static Color color(String hex) {
        try {
            return Color.fromRGB(Integer.parseInt(hex.replace("#", ""), 16));
        } catch (NumberFormatException e) {
            return Color.WHITE;
        }
    }
}
