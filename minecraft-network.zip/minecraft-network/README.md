# Minecraft Network Starter Kit

A complete, self-hosted Minecraft network you can bring up with Docker:

```
players -> play.yournetwork.com (Velocity proxy)
              |
   +----------+-----------+-------------+------------+-----------+
  Hub      Gems SMP   Enchant SMP   Lifesteal    Classic SMP   Minigames
 (island)  (gems)     (1-of-1 books) (hearts)    (vanilla+)   (TNT Run, Spleef,
                                                                Sumo, Rising Lava)
  + MariaDB (shared ranks) + Redis + BlueMap live maps + website + backups
```

## What is in the box

| Part | What it does |
|---|---|
| `plugins/network-core` | **Generates the spawn.** A floating hub island (sunburst plaza, beacon fountain, one arch per game mode, lantern posts, launch pads, holograms with live player counts) and a themed spawn plaza for every SMP. Also: selector compass, config-driven menus, scoreboard, tab list, spawn protection, `/hub`. |
| `plugins/gems-smp` | 8 original soulbound gems, each with a passive and two abilities, powered by an energy system. |
| `plugins/enchant-smp` | One book per enchantment, hidden in the world. Any enchant on any item at an anvil. Pick up a used book and the ground explodes. |
| `plugins/lifesteal` | Hearts, `/withdraw`, craftable Heart and Revival Compass, elimination, newbie shield, combat tag. |
| `plugins/minigames` | Game engine and four games: TNT Run, Spleef, Sumo, Rising Lava. Arenas are built and removed automatically. |
| `docker-compose.yml` | Proxy, 6 backends, database, Redis, website and maps (Caddy), 6-hourly backups. |
| `web/site` | Landing page with server IP, modes and live map links. |

## Quick start

```bash
cp .env.example .env          # fill in the secrets (openssl rand -hex 24)
./scripts/assemble.sh         # builds the plugins, prepares ./build
docker compose up -d          # start everything
```

Then read **[docs/SETUP.md](docs/SETUP.md)**. It covers the server, firewall, ops, ranks, maps, backups and troubleshooting.

## Docs

- [docs/QUICKTEST-WINDOWS.md](docs/QUICKTEST-WINDOWS.md): try the plugins on a normal Windows Paper server first
- [docs/SETUP.md](docs/SETUP.md): install and run the full network
- [docs/PLUGINS.md](docs/PLUGINS.md): every command, permission and config option
- [docs/SPAWN.md](docs/SPAWN.md): how the spawn is generated and how to customise or replace it
- [docs/LAUNCH-PLAN.md](docs/LAUNCH-PLAN.md): going viral, rules and Discord template

## Honest status

- The plugins were written without access to the Paper API in the authoring environment, so they were **not compiled or run on a live server**. A partial compile check found no syntax or structure errors, and the only errors left were the unavailable Paper classes. Expect to fix a few small API-version mismatches on first build. `.github/workflows/build.yml` builds them on GitHub for you, and the poms have a single `paper.version` line to adjust.
- Third-party plugin names (`luckperms`, `bluemap`, `grimac`, `chunky`) are downloaded from Modrinth by name. If one fails, see the troubleshooting section in SETUP.md.
- Test everything on a private server before you announce it.
