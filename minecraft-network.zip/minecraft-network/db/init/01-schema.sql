-- Shared network database. LuckPerms creates its own tables (luckperms_*).
-- Add shared network-wide tables here. Per-mode plugins keep their own data in their folders.
CREATE TABLE IF NOT EXISTS network_players (
  uuid        CHAR(36)     PRIMARY KEY,
  name        VARCHAR(16)  NOT NULL,
  first_join  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  coins       BIGINT       NOT NULL DEFAULT 0,
  referred_by CHAR(36)     NULL
);
